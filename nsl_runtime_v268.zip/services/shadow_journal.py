from __future__ import annotations

import json
import os
from contextlib import contextmanager
from dataclasses import replace
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Iterator

from analysis.position_guardian import create_trade_record, calculate_position_guardian
from analysis.execution_guard import calculate_execution_guard
from analysis.decision import _entry_alignment_blocker
from config import CONFIG
from models import DisciplineState, MarketSnapshot
from services.github_journal import GitHubJsonJournal

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None


class ShadowJournalStore:
    """Atomic read-only-market paper journal; never places a broker order."""

    SCHEMA_VERSION = 1

    def __init__(
        self,
        path: str | Path | None = None,
        cloud_backend: GitHubJsonJournal | None = None,
    ) -> None:
        self.path = Path(path or CONFIG.shadow_journal_path)
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self.cloud = cloud_backend
        self.last_error = ""
        self.last_blocker = "Not checked"
        self.last_checked = ""
        self.last_saved = ""
        self.local_read_failed = False

    @contextmanager
    def _locked(self) -> Iterator[None]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.lock_path.open("a+", encoding="utf-8") as handle:
            if fcntl is not None:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    @classmethod
    def _empty(cls) -> dict[str, Any]:
        return {"schema_version": cls.SCHEMA_VERSION, "entries": []}

    def _read_local(self) -> dict[str, Any]:
        if not self.path.exists():
            return self._empty()
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            self.local_read_failed = True
            self.last_error = f"Journal read failed: {type(exc).__name__}; original file preserved"
            return self._empty()
        if not isinstance(data, dict) or not isinstance(data.get("entries"), list):
            self.local_read_failed = True
            self.last_error = "Journal format invalid; original file preserved"
            return self._empty()
        return data

    def _write_local(self, data: dict[str, Any]) -> None:
        if self.local_read_failed:
            raise ValueError("Refusing to overwrite unreadable journal")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(data, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )
        os.replace(temporary, self.path)

    def load(self, *, refresh_cloud: bool = False) -> list[dict[str, Any]]:
        with self._locked():
            if refresh_cloud and self.cloud is not None and self.cloud.enabled:
                try:
                    remote = self.cloud.read().data
                    if isinstance(remote.get("entries"), list):
                        local = self._read_local()
                        merged = {str(x.get("trade_id")): x for x in remote["entries"] if isinstance(x, dict)}
                        merged.update({str(x.get("trade_id")): x for x in local["entries"] if isinstance(x, dict)})
                        self._write_local({"schema_version": self.SCHEMA_VERSION, "entries": list(merged.values())})
                except Exception as exc:
                    self.last_error = f"Cloud read failed: {type(exc).__name__}; local history retained"
            data = self._read_local()
            return [dict(item) for item in data["entries"] if isinstance(item, dict)]

    def load_decisions(self) -> list[dict[str, Any]]:
        path = self.path.with_suffix(".decisions.json")
        try:
            data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
        except (OSError, json.JSONDecodeError):
            return []
        return [dict(item) for item in data if isinstance(item, dict)] if isinstance(data, list) else []

    def _save_decisions(self, rows: list[dict[str, Any]]) -> None:
        path = self.path.with_suffix(".decisions.json")
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(rows[-2500:], sort_keys=True, separators=(",", ":")), encoding="utf-8")
        os.replace(temporary, path)

    def save(self, entries: list[dict[str, Any]], *, sync_cloud: bool = True) -> None:
        data = {"schema_version": self.SCHEMA_VERSION, "entries": entries[-500:]}
        with self._locked():
            self._write_local(data)
            self.last_saved = datetime.now().isoformat()
            if sync_cloud and self.cloud is not None and self.cloud.enabled:
                try:
                    remote = self.cloud.read()
                    self.cloud.write(data, sha=remote.sha)
                except Exception as exc:
                    # Local journal remains authoritative until cloud recovers.
                    self.last_error = f"Cloud save failed: {type(exc).__name__}; saved locally"

    def record_check(self, snapshot, reason):
        """Record every meaningful One-Brain observation, including WAIT outcomes.

        Trade P&L remains in ``shadow_journal.json``.  This decision journal is the
        missing learning lane: it records WAIT/READY/TTAKE observations and backfills
        5m/15m/30m spot outcomes as later snapshots arrive.
        """
        self.last_checked = snapshot.created_at.isoformat()
        self.last_blocker = reason
        simple = snapshot.metadata.get("simple_brain") or {}
        common = snapshot.metadata.get("common_decision") or {}
        spot = snapshot.levels.current_price
        if spot is None:
            spot = snapshot.nifty_quote.get("last_price")
        try:
            spot = float(spot) if spot is not None else None
        except (TypeError, ValueError):
            spot = None
        local_clock = snapshot.created_at.timetz().replace(tzinfo=None)
        journal_open = bool(
            snapshot.created_at.weekday() < 5
            and CONFIG.simple_decision_journal_start <= local_clock <= CONFIG.simple_decision_journal_end
        )

        # Decision reasons are stored only in the bounded Decision Journal below.
        # The old parallel *.signals.json file duplicated the same WAIT/READY state,
        # added extra disk I/O, and could disagree with Railway-persistent decisions.

        # Full decision journal: bounded, one row/minute or immediately on a state
        # change.  Later snapshots backfill missed-move outcomes.
        try:
            decisions = self.load_decisions()
            now = snapshot.created_at
            market_session = getattr(snapshot, "market_session", None)
            session_live = bool(getattr(market_session, "is_live", True))
            if spot is not None and session_live:
                for row in decisions:
                    try:
                        opened = datetime.fromisoformat(str(row.get("at")))
                        if opened.tzinfo is None and now.tzinfo is not None:
                            opened = opened.replace(tzinfo=now.tzinfo)
                        age_min = (now - opened).total_seconds() / 60.0
                        base = float(row.get("spot"))
                    except (TypeError, ValueError):
                        continue
                    for horizon in (5, 15, 30):
                        key = f"outcome_{horizon}m_points"
                        if row.get(key) is None and age_min >= horizon:
                            row[key] = round(spot - base, 2)
                            row[f"outcome_{horizon}m_label"] = (
                                "UP" if spot - base >= 5 else "DOWN" if spot - base <= -5 else "RANGE"
                            )

            current = {
                "at": now.isoformat(),
                "session_date": now.date().isoformat(),
                "session_live": session_live,
                "spot": spot,
                "regime": str(simple.get("regime") or ""),
                "direction": str(simple.get("direction") or snapshot.decision.market_direction),
                "direction_strength": round(float(simple.get("direction_strength") or 0.0), 1),
                "entry_readiness": round(float(simple.get("entry_readiness") or 0.0), 1),
                "entry_state": str(simple.get("entry_state") or ""),
                "candidate_action": str(simple.get("candidate_action") or snapshot.trade_plan.selected_setup),
                "final_action": str(common.get("final_action") or simple.get("final_action") or "WAIT"),
                "trigger": str(simple.get("trigger") or ""),
                "reason": reason,
                "option_bias": snapshot.option_intelligence.market_bias,
                "option_confidence": snapshot.option_intelligence.confidence,
                "big_player": f"{snapshot.big_player_activity.direction} {snapshot.big_player_activity.score:.0f}",
                "barrier_state": str(((simple.get("blocks") or {}).get("barrier_entry") or {}).get("state") or ""),
                "outcome_5m_points": None,
                "outcome_15m_points": None,
                "outcome_30m_points": None,
            }
            last = decisions[-1] if decisions else None
            append = last is None
            if last is not None:
                try:
                    previous_at = datetime.fromisoformat(str(last.get("at")))
                    if previous_at.tzinfo is None and now.tzinfo is not None:
                        previous_at = previous_at.replace(tzinfo=now.tzinfo)
                    elapsed = (now - previous_at).total_seconds()
                except (TypeError, ValueError):
                    elapsed = CONFIG.simple_decision_journal_interval_seconds
                changed = any(
                    str(last.get(key) or "") != str(current.get(key) or "")
                    for key in ("regime", "direction", "entry_state", "candidate_action", "final_action", "barrier_state")
                )
                append = changed or elapsed >= CONFIG.simple_decision_journal_interval_seconds
            if journal_open and append:
                decisions.append(current)
            self._save_decisions(decisions)
        except (OSError, ValueError, TypeError) as exc:
            self.last_error = f"Decision journal failed: {type(exc).__name__}"


def _strategy_score(snapshot: MarketSnapshot, action: str) -> float:
    evaluation = {
        "CE BUY": snapshot.decision.ce_buy,
        "PE BUY": snapshot.decision.pe_buy,
        "CE SELL": snapshot.decision.ce_sell,
        "PE SELL": snapshot.decision.pe_sell,
        "IRON CONDOR": snapshot.decision.iron_condor,
    }.get(action)
    return float(evaluation.score) if evaluation is not None else 0.0


def _close_open_entries(
    entries: list[dict[str, Any]], snapshot: MarketSnapshot
) -> tuple[bool, bool]:
    changed = False
    cloud_changed = False
    for entry in entries:
        if str(entry.get("status") or "").upper() != "OPEN":
            continue
        state = DisciplineState(
            session_date=snapshot.created_at.date().isoformat(),
            trades_taken=1,
            day_locked=False,
            last_outcome="OPEN",
            last_action=str(entry.get("action") or ""),
            signal_history=(),
            status="READY",
            trade_record=entry,
        )
        guardian = calculate_position_guardian(
            discipline_state=state,
            option_chain=snapshot.option_chain,
            current_expiry=snapshot.expiry,
            current_spot=float(snapshot.levels.current_price)
            if snapshot.levels.current_price is not None
            else None,
            market_session=snapshot.market_session,
            option_chain_live=(
                snapshot.feed_status.get("option_chain") is not None
                and snapshot.feed_status["option_chain"].use_state == "LIVE"
            ),
            as_of=snapshot.created_at,
        )
        pnl = guardian.unrealized_pnl_rupees
        entry["last_guardian_check_at"] = snapshot.created_at.isoformat()
        entry["guardian_status"] = guardian.status
        changed = True
        if guardian.status == "EXIT DUE":
            entry["exit_due_at"] = entry.get("exit_due_at") or snapshot.created_at.isoformat()
        if pnl is not None:
            next_mfe = round(max(float(entry.get("mfe_rupees") or 0.0), pnl), 2)
            next_mae = round(min(float(entry.get("mae_rupees") or 0.0), pnl), 2)
            next_pnl = round(pnl, 2)
            if (
                next_mfe != entry.get("mfe_rupees")
                or next_mae != entry.get("mae_rupees")
                or next_pnl != entry.get("last_pnl_rupees")
            ):
                entry["mfe_rupees"] = next_mfe
                entry["mae_rupees"] = next_mae
                entry["last_pnl_rupees"] = next_pnl
                changed = True
        if guardian.status in {"TARGET ALERT", "EXIT ALERT"} and pnl is not None:
            gross = float(pnl)
            charges = float(CONFIG.shadow_journal_estimated_charges_per_trade)
            entry["status"] = "CLOSED"
            entry["outcome"] = guardian.instruction
            entry["closed_at"] = snapshot.created_at.isoformat()
            entry["fill_basis"] = "First observed executable quote, not a guaranteed deadline fill"
            entry["exit_debit_points"] = guardian.current_debit_points
            entry["gross_pnl_rupees"] = round(gross, 2)
            entry["estimated_charges_rupees"] = round(charges, 2)
            entry["net_pnl_rupees"] = round(gross - charges, 2)
            changed = True
            cloud_changed = True
    return changed, cloud_changed


def _eligible(entries: list[dict[str, Any]], snapshot: MarketSnapshot) -> tuple[bool, str]:
    action = snapshot.trade_plan.selected_setup
    common = snapshot.metadata.get("common_decision") or {}
    if not common.get("entry_allowed") or common.get("final_action") != action:
        reasons = common.get("blockers") or ["Common Current/Future gate is not ready"]
        return False, "Common Gate: " + str(reasons[0])
    today = snapshot.created_at.date().isoformat()
    today_entries = [item for item in entries if str(item.get("session_date")) == today]
    if len(today_entries) >= CONFIG.shadow_journal_max_trades_per_day:
        return False, "Daily 5-trade paper cap reached"
    if not snapshot.market_session.is_live:
        return False, "Market is not live"
    if action not in {"CE BUY", "PE BUY", "CE SELL", "PE SELL", "IRON CONDOR"}:
        return False, "No concrete One-Brain strategy"
    simple = snapshot.metadata.get("simple_brain") or {}
    if simple:
        if float(simple.get("direction_strength") or 0) < CONFIG.simple_direction_min_strength:
            return False, "Simple Brain direction below minimum strength"
        if float(simple.get("entry_readiness") or 0) < CONFIG.simple_entry_ready_score:
            return False, "Simple Brain entry trigger not ready"
    else:
        if float(common.get("trade_confidence") or 0) < CONFIG.shadow_journal_min_confidence:
            return False, "Common trade confidence below threshold"
        if _strategy_score(snapshot, action) < CONFIG.shadow_journal_min_strategy_score:
            return False, "Strategy score below threshold"
    selected_plan = {
        "CE BUY": snapshot.trade_plan.ce_buy,
        "PE BUY": snapshot.trade_plan.pe_buy,
        "CE SELL": snapshot.trade_plan.ce_sell,
        "PE SELL": snapshot.trade_plan.pe_sell,
        "IRON CONDOR": snapshot.trade_plan.iron_condor,
    }.get(action)
    if selected_plan is None or not selected_plan.available:
        return False, "Protected paper plan is unavailable"
    if simple:
        if str(simple.get("final_action") or "WAIT") != action:
            return False, str(simple.get("instruction") or "Simple Brain trigger pending")
    else:
        alignment_blocker = _entry_alignment_blocker(
            setup=action, price_action=snapshot.price_action, levels=snapshot.levels,
            volume=snapshot.volume, patterns=snapshot.patterns,
        )
        if alignment_blocker:
            return False, alignment_blocker
    if (
        action in {"CE SELL", "PE SELL", "IRON CONDOR"}
        and float(selected_plan.estimated_credit_points or 0.0)
        < CONFIG.shadow_journal_min_sell_credit_points
    ):
        return False, (
            "Protected credit below experimental journal minimum "
            f"{CONFIG.shadow_journal_min_sell_credit_points:.1f} pts"
        )
    if snapshot.execution_guard.allowed_lots < 1:
        return False, "One-lot defined risk exceeds configured paper risk budget"
    now_time = snapshot.created_at.timetz().replace(tzinfo=None)
    if not snapshot.risk_profile.entry_start <= now_time <= snapshot.risk_profile.entry_end:
        return False, "Outside configured paper entry window"
    for feed_name in ("quotes", "candles", "option_chain"):
        feed = snapshot.feed_status.get(feed_name)
        if feed is None or feed.use_state != "LIVE":
            return False, f"{feed_name} is not confirmed live"
    progression = snapshot.feed_status.get("price_progression")
    if progression is not None and not progression.ok:
        return False, "NIFTY price series is flatlined / not progressing"
    ready_windows = sum(
        item.status == "READY" for item in snapshot.option_intelligence.windows
    )
    if snapshot.option_intelligence.status == "UNAVAILABLE" or ready_windows < 1:
        return False, "Option flow unavailable"
    if any(
        str(item.get("status") or "").upper() == "OPEN"
        and str(item.get("setup") or "").upper() == action
        for item in today_entries
    ):
        return False, "Same strategy already open"
    if today_entries:
        try:
            latest = max(datetime.fromisoformat(str(item["opened_at"])) for item in today_entries)
            if snapshot.created_at - latest < timedelta(minutes=CONFIG.shadow_journal_cooldown_minutes):
                return False, "Shadow cooldown active"
        except (KeyError, TypeError, ValueError):
            pass
    return True, "READY"


def _paper_snapshot(snapshot):
    """Select a test candidate on a copy; never mutate the real AI/position."""
    common = snapshot.metadata.get("common_decision") or {}
    action = str(common.get("final_action") or "WAIT")
    if action not in {"CE BUY", "PE BUY", "CE SELL", "PE SELL", "IRON CONDOR"}:
        return snapshot
    plan = replace(snapshot.trade_plan, selected_setup=action)
    guard = calculate_execution_guard(
        decision=snapshot.decision, trade_plan=plan, market_session=snapshot.market_session,
        option_intelligence=snapshot.option_intelligence, price_action=snapshot.price_action,
        risk_profile=snapshot.risk_profile, discipline_state=snapshot.discipline_state,
        feed_status=snapshot.feed_status, as_of=snapshot.created_at,
        big_player=snapshot.big_player_activity,
        selected_setup_override=action,
        final_action_override=action,
        simple_brain=snapshot.metadata.get("simple_brain") or None,
    )
    return replace(snapshot, trade_plan=plan, execution_guard=guard)


def process_auto_shadow_journal(
    snapshot: MarketSnapshot,
    store: ShadowJournalStore,
    *,
    enabled: bool,
) -> list[dict[str, Any]]:
    entries = store.load(refresh_cloud=False)
    if store.local_read_failed:
        return entries
    changed, cloud_changed = _close_open_entries(entries, snapshot)
    snapshot = _paper_snapshot(snapshot)
    eligible, reason = _eligible(entries, snapshot)
    store.record_check(snapshot, reason if enabled else "Auto paper journal OFF")
    if enabled and eligible:
        record = create_trade_record(
            captured_at=snapshot.created_at,
            decision=snapshot.decision,
            trade_plan=snapshot.trade_plan,
            execution_guard=snapshot.execution_guard,
            lots=1,
            lot_size=snapshot.risk_profile.lot_size,
            spot=snapshot.levels.current_price,
            allow_paper_candidate=(
                snapshot.execution_guard.readiness != "ENTRY READY"
            ),
        )
        action = snapshot.trade_plan.selected_setup
        simple = snapshot.metadata.get("simple_brain") or {}
        alignment_warning = None if simple else _entry_alignment_blocker(
            setup=action, price_action=snapshot.price_action, levels=snapshot.levels,
            volume=snapshot.volume, patterns=snapshot.patterns,
        )
        qualified = bool(
            (float(simple.get("direction_strength") or snapshot.decision.decision_confidence) >= 60)
            and (float(simple.get("entry_readiness") or _strategy_score(snapshot, action)) >= 60)
            and not alignment_warning
            and snapshot.option_intelligence.status != "UNAVAILABLE"
        )
        record.update(
            {
                "journal_type": "AUTO SHADOW",
                "real_ai_action": snapshot.decision.final_action,
                "qualification": (
                    "QUALIFIED SIMPLE-BRAIN PAPER"
                    if qualified
                    else "EXPERIMENTAL SIMPLE-BRAIN"
                ),
                "counts_for_ai_accuracy": qualified,
                "candidate_warning": alignment_warning or "None",
                "trade_id": f"SH-{snapshot.created_at:%Y%m%d-%H%M%S}-{len(entries)+1}",
                "session_date": snapshot.created_at.date().isoformat(),
                "setup": action,
                "action": action,
                "decision_confidence": snapshot.decision.decision_confidence,
                "strategy_score": _strategy_score(snapshot, action),
                "score_band": "45–49" if _strategy_score(snapshot, action) < 50 else "50–54" if _strategy_score(snapshot, action) < 55 else "55–59" if _strategy_score(snapshot, action) < 60 else "60+",
                "big_player_direction": snapshot.big_player_activity.direction,
                "big_player_score": snapshot.big_player_activity.score,
                "big_player_confirmations": snapshot.big_player_activity.confirmation_count,
                "oi_basis": snapshot.option_intelligence.basis,
                "oi_bias": snapshot.option_intelligence.market_bias,
                "oi_confidence": snapshot.option_intelligence.confidence,
                "oi_persistence": snapshot.option_intelligence.persistence,
                "entry_reasons": list(snapshot.decision.reasons)
                + list(snapshot.big_player_activity.reasons)
                + list(snapshot.option_intelligence.reasons),
                "mfe_rupees": 0.0,
                "mae_rupees": 0.0,
                "last_pnl_rupees": 0.0,
            }
        )
        entries.append(record)
        changed = True
        cloud_changed = True
    if changed:
        # Intraday mark-to-market remains local to avoid a GitHub commit every
        # refresh. New and closed paper trades are mirrored to cloud.
        store.save(entries, sync_cloud=cloud_changed)
    return entries
