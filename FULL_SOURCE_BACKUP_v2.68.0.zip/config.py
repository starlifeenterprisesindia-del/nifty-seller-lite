from __future__ import annotations

from dataclasses import dataclass
from datetime import time

IST_TIMEZONE = "Asia/Kolkata"
DHAN_BASE_URL = "https://api.dhan.co/v2"
INSTRUMENT_MASTER_URL = "https://images.dhan.co/api-data/api-scrip-master-detailed.csv"


@dataclass(frozen=True)
class InstrumentRef:
    name: str
    security_id: str
    exchange_segment: str
    instrument: str
    symbol: str = ""
    weight_pct: float = 0.0


@dataclass(frozen=True)
class AppConfig:
    app_name: str = "Nifty Seller Lite"
    version: str = "2.68.0_SMART_ALERT_COMPACT_UI"
    request_timeout_seconds: int = 12
    snapshot_min_refresh_seconds: int = 5
    fast_monitor_interval_seconds: int = 5
    full_snapshot_default_seconds: int = 30
    quote_max_age_seconds: int = 12
    context_quote_max_age_seconds: int = 60
    candle_max_age_minutes: int = 5
    quote_candle_max_divergence_points: float = 50.0
    quote_candle_max_divergence_pct: float = 0.20
    pre_open_start: time = time(9, 0)
    market_open: time = time(9, 15)
    # NSE cash continuous session remains open through 15:30.  CAS/closing
    # indicative quotes after that point are reference-only and must never make
    # the valid 15:15-15:30 candles disappear from the signal frame.
    cas_start: time = time(15, 30)
    cas_end: time = time(15, 40)
    market_close: time = time(15, 30)
    derivatives_close: time = time(15, 40)
    expiry_close_quality_start: time = time(15, 15)
    # Broker/index charts can stop advancing after ~15:15 even while option
    # quotes continue to change. New entries already end at 15:00, so treat this
    # late window as reference-only instead of declaring the feed broken.
    spot_reference_only_start: time = time(15, 15)
    spot_flatline_min_candles: int = 4
    nifty: InstrumentRef = InstrumentRef(
        name="NIFTY 50",
        security_id="13",
        exchange_segment="IDX_I",
        instrument="INDEX",
        symbol="NIFTY",
    )
    india_vix: InstrumentRef = InstrumentRef(
        name="INDIA VIX",
        security_id="33",
        exchange_segment="IDX_I",
        instrument="INDEX",
        symbol="INDIA VIX",
    )

    # Official NIFTY 50 top-nine weights as at 31-Aug-2026. Security IDs are
    # Dhan/NSE instrument identifiers used by the already grouped quote request.
    top9_weight_date: str = "2026-08-31"
    top9: tuple[InstrumentRef, ...] = (
        InstrumentRef("HDFC Bank", "1333", "NSE_EQ", "EQUITY", "HDFCBANK", 9.85),
        InstrumentRef("ICICI Bank", "4963", "NSE_EQ", "EQUITY", "ICICIBANK", 9.45),
        InstrumentRef(
            "Reliance Industries", "2885", "NSE_EQ", "EQUITY", "RELIANCE", 7.83
        ),
        InstrumentRef("Bharti Airtel", "10604", "NSE_EQ", "EQUITY", "BHARTIARTL", 5.00),
        InstrumentRef("Larsen & Toubro", "11483", "NSE_EQ", "EQUITY", "LT", 4.30),
        InstrumentRef("State Bank of India", "3045", "NSE_EQ", "EQUITY", "SBIN", 3.98),
        InstrumentRef("Infosys", "1594", "NSE_EQ", "EQUITY", "INFY", 3.61),
        InstrumentRef("Axis Bank", "5900", "NSE_EQ", "EQUITY", "AXISBANK", 3.39),
        InstrumentRef("Kotak Mahindra Bank", "1922", "NSE_EQ", "EQUITY", "KOTAKBANK", 2.80),
    )
    option_strikes_each_side: int = 7
    candle_lookback_days: int = 7
    minimum_one_minute_candles: int = 30
    minimum_indicator_candles: int = 50

    # Core-market settings.
    swing_left_bars: int = 2
    swing_right_bars: int = 2
    minimum_structure_swings: int = 2
    atr_period: int = 14
    breakout_atr_tolerance: float = 0.08
    level_zone_atr_fraction: float = 0.20
    minimum_level_zone_points: float = 3.0
    maximum_level_zone_points: float = 15.0
    opening_range_minutes: int = 15
    volume_baseline_sessions: int = 5
    volume_recent_fallback_bars: int = 20
    volume_low_ratio: float = 0.70
    volume_high_ratio: float = 1.20
    volume_surge_ratio: float = 1.80

    # Options-intelligence settings. History is bounded and same-session only.
    option_state_path: str = "data/option_state.json"
    option_state_max_snapshots: int = 180
    option_state_dedupe_seconds: int = 20
    # Phase-8: tiny once-per-session ATM-IV summaries retained inside the same
    # option-state file. This builds true IV Rank/Percentile history over time
    # without any extra broker/API call or extra live-path file.
    iv_history_max_sessions: int = 60
    # Same-session compact activity memory. It stores only direction/score/state,
    # never credentials, orders or trader identity.
    big_player_state_path: str = "data/big_player_state.json"
    big_player_state_max_snapshots: int = 60
    big_player_dedupe_seconds: int = 20
    option_min_price_move_pct: float = 0.50
    option_min_price_move_points: float = 0.25
    option_min_oi_move_pct: float = 0.20
    option_window_tolerance_ratio: float = 0.55
    option_persistence_lookback: int = 5
    option_max_comparison_age_seconds: int = 600
    option_min_integrity_rows: int = 6
    option_spot_max_divergence_pct: float = 0.35
    option_spot_max_divergence_points: float = 50.0

    # Instrument master cache is refreshed daily; a stale cache remains a safe
    # fallback when the remote master is temporarily unavailable.
    instrument_master_cache_max_age_hours: int = 24

    # Durable background context and final one-brain decision settings.
    market_context_path: str = "data/market_context.json"
    market_context_mirror_path: str = "data/market_context_mirror.json"
    market_context_rescue_path: str = "data/market_context_rescue.json"
    market_context_max_entries: int = 15
    # Optional private GitHub JSON journal. Secrets provide owner/repo/token/path;
    # this TTL prevents a cloud API read on every Streamlit rerun.
    market_context_cloud_pull_ttl_seconds: int = 60
    market_context_cloud_timeout_seconds: int = 8

    # Pre-touch support/resistance early warning. This is display/risk context only and
    # never creates a second strategy brain.
    pretouch_warning_distance_points: float = 40.0
    pretouch_watch_distance_points: float = 100.0

    # Public market-news context. A short TTL cache prevents repeated RSS traffic on
    # every 5-second Dhan snapshot. Failure is fail-open to UNAVAILABLE, never stale-as-live.
    news_cache_path: str = "data/news_cache.json"
    news_cache_ttl_seconds: int = 180
    news_request_timeout_seconds: int = 4
    # News freshness is based on the article publication time, not RSS fetch time.
    # READY <= 90m, OLD 90-180m (low weight), >180m gets zero decision weight.
    news_fresh_minutes: int = 30
    news_recent_minutes: int = 90
    news_stale_minutes: int = 180
    # Older same-day headlines may remain as screen-only context. They never receive
    # One-Brain direction weight after news_stale_minutes.
    news_context_minutes: int = 1440
    news_title_date_max_days: int = 2
    news_max_headlines: int = 12

    # Automatic housekeeping. Raw/temporary market state is bounded to 24 hours.
    # FII/DII journal, manual trade records and compact learning summaries are excluded.
    temporary_data_retention_hours: int = 24
    # Expiry recorder storage stays bounded on Railway.  Detailed rows for the
    # active cycle remain in SQLite; eight compact cycle summaries remain in the
    # database, while only the newest full compressed archives are retained.
    day_memory_archive_keep_cycles: int = 2
    day_memory_archive_max_mb: int = 60
    decision_minimum_score: float = 62.0
    decision_minimum_margin: float = 12.0
    execution_minimum_unified_score: float = 75.0
    # v2.48 Simple One-Brain: normalized available-evidence thresholds.  These do
    # not lower data/risk safety; they replace the old mathematically unreachable
    # stack of independent 75%/Future/15m/3m gates.
    simple_direction_min_strength: float = 54.0
    simple_entry_ready_score: float = 62.0
    simple_entry_watch_score: float = 54.0
    simple_execution_required_confirmations: int = 1
    simple_decision_journal_interval_seconds: int = 60
    simple_decision_journal_start: time = time(9, 30)
    simple_decision_journal_end: time = time(15, 0)
    ai_move_tracker_interval_seconds: int = 180
    ai_move_tracker_max_minutes: int = 30
    simple_priority_snapshot_cooldown_seconds: int = 20
    # Keep a support/resistance break trigger armed long enough for the market to
    # actually cross it.  Without this memory the nearest barrier can move with
    # price and the app can keep saying WAIT after the original trigger broke.
    simple_armed_trigger_minutes: int = 20
    # After an armed barrier breaks, require usable room to the newly detected
    # next barrier.  This prevents a valid old-level break from becoming a chase
    # entry directly into fresh support/resistance.  Uses existing snapshot data only.
    simple_break_room_min_points: float = 8.0
    simple_break_room_atr_multiple: float = 0.60
    # A directional entry normally needs Trend plus at least one live confirmation
    # block (Options or Participation).  A completed 3m break of an already armed
    # barrier can release the setup even while one confirmation lane is warming.
    simple_min_confirmation_blocks: int = 1
    decision_wait_block_threshold: float = 60.0
    decision_min_option_confidence: float = 58.0
    decision_min_core_confidence: float = 55.0

    # Same-brain market memory, anti-flip confirmation and fake-move risk.
    # These settings do not create a second strategy engine; they gate the output
    # of calculate_final_decision using bounded same-session evidence memory.
    decision_memory_lookback: int = 5
    decision_memory_max_age_seconds: int = 900
    decision_confirmation_snapshots: int = 3
    decision_flip_confirmations: int = 3
    decision_normal_confirmation_seconds: int = 60
    decision_strong_confirmation_seconds: int = 30
    decision_condor_confirmation_seconds: int = 120
    decision_reversal_confirmation_seconds: int = 180
    decision_strong_min_score: float = 80.0
    decision_flip_margin: float = 15.0
    decision_emergency_flip_margin: float = 35.0
    decision_stability_wait_floor: float = 65.0
    fake_move_medium_threshold: float = 40.0
    fake_move_high_threshold: float = 65.0
    outlook_min_path_pct: float = 5.0
    outlook_current_weight: float = 0.65

    # Completed 3-minute W/M and special-candle evidence. These are bounded
    # confirmations inside the same canonical brain, never separate actions.
    pattern_min_brain_confidence: float = 45.0
    pattern_wm_max_adjustment: float = 8.0
    pattern_candle_max_adjustment: float = 4.0
    pattern_combined_max_adjustment: float = 12.0

    # Read-only strike-planner settings. This planner consumes the final one-brain
    # action and cannot change strategy scores or place orders.
    trade_target_abs_delta: float = 0.20
    trade_min_abs_delta: float = 0.08
    trade_max_abs_delta: float = 0.38
    trade_target_distance_pct: float = 1.0
    trade_distance_tolerance_pct: float = 0.9
    trade_hedge_steps: int = 2
    trade_max_hedge_steps: int = 5
    trade_min_option_premium: float = 3.0
    trade_min_hedge_premium: float = 0.5
    trade_min_credit_points: float = 1.0
    trade_min_plan_quality: float = 60.0
    trade_level_clearance_points: float = 10.0

    # Directional option-buy planner. The same Final One-Brain must first select
    # CE BUY or PE BUY; these settings only choose a liquid ATM/near-ITM leg.
    buy_target_abs_delta: float = 0.50
    buy_min_abs_delta: float = 0.30
    buy_max_abs_delta: float = 0.72
    buy_target_distance_pct: float = 0.15
    buy_distance_tolerance_pct: float = 0.45
    buy_min_option_premium: float = 4.0
    buy_min_plan_quality: float = 60.0
    buy_min_directional_room_points: float = 12.0

    # Read-only execution guard and one-trade discipline. The guard consumes the
    # final decision and protected strike plan; it cannot choose a strategy or place
    # orders. Defaults reflect a conservative seller workflow and stay editable in UI.
    discipline_state_path: str = "data/discipline_state.json"
    discipline_state_max_signals: int = 60
    discipline_signal_dedupe_seconds: int = 20
    discipline_signal_max_gap_seconds: int = 420
    execution_required_confirmations: int = 3
    execution_min_flow_confidence: float = 75.0
    execution_required_flow_windows: int = 3
    risk_default_capital: float = 900000.0
    risk_default_pct: float = 0.5
    risk_default_lot_size: int = 65
    risk_default_max_lots: int = 1
    risk_default_target_capture_pct: float = 35.0
    risk_default_stop_loss_pct: float = 40.0
    risk_default_entry_start: time = time(10, 15)
    risk_default_entry_end: time = time(15, 0)
    risk_default_forced_exit: time = time(15, 15)

    # Manual post-entry position guardian. Alerts are deterministic and read-only.
    position_profit_protect_pct: float = 70.0
    position_risk_warning_pct: float = -70.0

    # One-Brain participation gate. Evidence modules never select a strategy.
    big_player_min_score: float = 60.0
    big_player_min_confirmations: int = 2

    # Automatic read-only forward journal. It never sends broker orders.
    shadow_journal_path: str = "data/shadow_journal.json"
    shadow_journal_max_trades_per_day: int = 5
    shadow_journal_min_confidence: float = 50.0
    shadow_journal_min_strategy_score: float = 55.0
    shadow_journal_min_option_confidence: float = 55.0
    # Experimental paper entries still need enough credit to survive estimated
    # charges and one observed-quote slippage step.  This is not an execution rule.
    shadow_journal_min_sell_credit_points: float = 4.0
    shadow_journal_cooldown_minutes: int = 20
    shadow_journal_estimated_charges_per_trade: float = 40.0

    @property
    def top9_symbols(self) -> tuple[str, ...]:
        return tuple(item.symbol for item in self.top9)

    @property
    def top9_weight_map(self) -> dict[str, float]:
        return {item.symbol: item.weight_pct for item in self.top9}

    # Compatibility aliases for older internal names/support bundles.
    @property
    def top7(self) -> tuple[InstrumentRef, ...]:
        return self.top9

    @property
    def top7_symbols(self) -> tuple[str, ...]:
        return self.top9_symbols

    @property
    def top7_weight_map(self) -> dict[str, float]:
        return self.top9_weight_map

    @property
    def top7_weight_date(self) -> str:
        return self.top9_weight_date


CONFIG = AppConfig()
