from __future__ import annotations

import math
from datetime import datetime
from typing import Iterable
from analysis.activity_gate import activity_gate

from config import CONFIG
from models import (
    BigPlayerActivity,
    DisciplineState,
    ExecutionGuard,
    FeedStatus,
    FinalDecision,
    MarketSession,
    OptionIntelligence,
    PriceActionBundle,
    RiskProfile,
    SetupPlan,
    TradePlanBundle,
)


def _flow_ready(option: OptionIntelligence) -> tuple[int, bool]:
    ready_windows = sum(1 for item in option.windows if item.status == "READY")
    mature = (
        option.status == "READY"
        and option.confidence >= CONFIG.execution_min_flow_confidence
        and ready_windows >= CONFIG.execution_required_flow_windows
        and option.persistence not in {"WARMING UP", "UNAVAILABLE"}
    )
    return ready_windows, mature


def _timeframe_aligned(setup: str, price_action: PriceActionBundle) -> bool:
    three = f"{price_action.three_minute.structure} {price_action.three_minute.event}".upper()
    fifteen = f"{price_action.fifteen_minute.structure} {price_action.fifteen_minute.event}".upper()

    def state(text: str) -> str:
        if "MIXED" in text or "TRANSITION" in text or "RANGE" in text:
            return "RANGE"
        if "BULLISH" in text and "BEARISH" not in text:
            return "BULLISH"
        if "BEARISH" in text and "BULLISH" not in text:
            return "BEARISH"
        return "RANGE"

    three_state = state(three)
    fifteen_state = state(fifteen)
    if setup in {"PE SELL", "CE BUY"}:
        return three_state == fifteen_state == "BULLISH"
    if setup in {"CE SELL", "PE BUY"}:
        return three_state == fifteen_state == "BEARISH"
    if setup == "IRON CONDOR":
        return three_state == fifteen_state == "RANGE"
    return False


def _selected_plan(bundle: TradePlanBundle) -> SetupPlan | None:
    return {
        "CE BUY": bundle.ce_buy,
        "PE BUY": bundle.pe_buy,
        "CE SELL": bundle.ce_sell,
        "PE SELL": bundle.pe_sell,
        "IRON CONDOR": bundle.iron_condor,
    }.get(bundle.selected_setup)


def _fresh_live(feed_status: dict[str, FeedStatus], key: str) -> bool:
    item = feed_status.get(key)
    return bool(item and item.ok and item.use_state == "LIVE")


def _confirmation_count(
    history: Iterable[dict[str, object]], action: str, as_of: datetime
) -> int:
    if action == "WAIT":
        return 0
    samples = list(history)
    count = 0
    next_time = as_of
    for sample in reversed(samples):
        sample_action = str(sample.get("action") or "").upper().replace(" WITH HEDGE", "")
        wanted_action = str(action or "").upper().replace(" WITH HEDGE", "")
        if sample_action != wanted_action:
            break
        if str(sample.get("execution_status") or "").upper() not in {
            "READY",
            "REFERENCE ONLY",
        }:
            break
        try:
            captured_at = datetime.fromisoformat(str(sample.get("captured_at")))
        except Exception:
            break
        gap = max(0.0, (next_time - captured_at).total_seconds())
        if gap > CONFIG.discipline_signal_max_gap_seconds:
            break
        count += 1
        next_time = captured_at
    return count


def _entry_window(profile: RiskProfile, as_of: datetime) -> tuple[str, bool, bool]:
    current = as_of.timetz().replace(tzinfo=None)
    if current < profile.entry_start:
        return (
            f"BEFORE WINDOW ({profile.entry_start.strftime('%H:%M')}–{profile.entry_end.strftime('%H:%M')})",
            False,
            False,
        )
    if current <= profile.entry_end:
        return (
            f"OPEN ({profile.entry_start.strftime('%H:%M')}–{profile.entry_end.strftime('%H:%M')})",
            True,
            False,
        )
    return (
        f"CLOSED AFTER {profile.entry_end.strftime('%H:%M')}",
        False,
        True,
    )


def _spot_invalidations(
    setup: str,
    plan: SetupPlan | None,
    price_action: PriceActionBundle,
) -> tuple[float | None, float | None]:
    three = price_action.three_minute
    fifteen = price_action.fifteen_minute
    if setup in {"PE SELL", "CE BUY"}:
        values = [
            item
            for item in (three.invalidation_level, fifteen.invalidation_level)
            if item is not None
        ]
        return (max(values) if values else None, None)
    if setup in {"CE SELL", "PE BUY"}:
        values = [
            item
            for item in (three.invalidation_level, fifteen.invalidation_level)
            if item is not None
        ]
        return (None, min(values) if values else None)
    if setup == "IRON CONDOR" and plan is not None:
        return plan.lower_breakeven, plan.upper_breakeven
    return None, None


def _risk_math(
    plan: SetupPlan | None, profile: RiskProfile
) -> tuple[
    float | None,
    int,
    int,
    float | None,
    float | None,
    float | None,
    float | None,
    float | None,
    float | None,
]:
    if (
        plan is None
        or not plan.available
        or plan.max_risk_points is None
        or profile.lot_size <= 0
    ):
        return (None, 0, 0, None, None, None, None, None, None)

    risk_per_lot = max(0.0, float(plan.max_risk_points)) * profile.lot_size
    max_by_budget = (
        math.floor(profile.risk_budget_rupees / risk_per_lot) if risk_per_lot > 0 else 0
    )
    allowed_lots = max(0, min(max_by_budget, max(0, profile.max_lots_cap)))

    if plan.is_buy:
        debit = max(0.0, float(plan.estimated_debit_points or 0.0))
        if debit <= 0:
            return (risk_per_lot, max_by_budget, allowed_lots, None, None, None, None, None, None)
        target_capture = debit * max(0.0, profile.target_capture_pct) / 100.0
        target_exit_debit = debit + target_capture
        stop_loss_points = min(
            debit * max(0.0, profile.stop_loss_pct) / 100.0, debit
        )
        stop_exit_debit = max(0.0, debit - stop_loss_points)
    else:
        credit = max(0.0, float(plan.estimated_credit_points or 0.0))
        if credit <= 0:
            return (risk_per_lot, max_by_budget, allowed_lots, None, None, None, None, None, None)
        target_capture = credit * max(0.0, profile.target_capture_pct) / 100.0
        target_exit_debit = max(0.0, credit - target_capture)
        configured_stop = credit * max(0.0, profile.stop_loss_pct) / 100.0
        stop_loss_points = min(configured_stop, max(0.0, float(plan.max_risk_points)))
        stop_exit_debit = credit + stop_loss_points
    target_rupees = target_capture * profile.lot_size * allowed_lots
    stop_rupees = stop_loss_points * profile.lot_size * allowed_lots
    return (
        round(risk_per_lot, 2),
        max_by_budget,
        allowed_lots,
        round(target_capture, 2),
        round(target_exit_debit, 2),
        round(target_rupees, 2),
        round(stop_loss_points, 2),
        round(stop_exit_debit, 2),
        round(stop_rupees, 2),
    )


def _calculate_execution_guard_legacy(
    *,
    decision: FinalDecision,
    trade_plan: TradePlanBundle,
    market_session: MarketSession,
    option_intelligence: OptionIntelligence,
    price_action: PriceActionBundle,
    risk_profile: RiskProfile,
    discipline_state: DisciplineState,
    feed_status: dict[str, FeedStatus],
    as_of: datetime,
    big_player: BigPlayerActivity | None = None,
    selected_setup_override: str | None = None,
    final_action_override: str | None = None,
) -> ExecutionGuard:
    """Convert the chosen setup into a read-only entry/risk gate.

    This module cannot select a strategy, change One-Brain scores or place orders.
    It only applies freshness, persistence, timing, risk-budget and one-trade rules
    to the already-selected final action and protected plan.
    """

    setup = str(selected_setup_override or trade_plan.selected_setup or "WAIT").upper()
    plan = {
        "CE BUY": trade_plan.ce_buy,
        "PE BUY": trade_plan.pe_buy,
        "CE SELL": trade_plan.ce_sell,
        "PE SELL": trade_plan.pe_sell,
        "IRON CONDOR": trade_plan.iron_condor,
    }.get(setup)
    effective_action = str(final_action_override or decision.final_action or "WAIT").upper()
    confirmations = _confirmation_count(
        discipline_state.signal_history, effective_action, as_of
    )
    if confirmations >= CONFIG.execution_required_confirmations:
        signal_state = f"CONFIRMED ×{confirmations}"
    elif confirmations > 0:
        signal_state = (
            f"WARMING UP {confirmations}/{CONFIG.execution_required_confirmations}"
        )
    else:
        signal_state = "NOT CONFIRMED"

    entry_window, within_window, after_window = _entry_window(risk_profile, as_of)
    (
        risk_per_lot,
        max_lots_by_budget,
        allowed_lots,
        target_capture_points,
        target_exit_debit_points,
        target_profit_rupees,
        stop_loss_points,
        stop_exit_debit_points,
        stop_loss_rupees,
    ) = _risk_math(plan, risk_profile)
    invalidation_low, invalidation_high = _spot_invalidations(setup, plan, price_action)

    blockers: list[str] = []
    reasons: list[str] = []

    if not market_session.is_live:
        readiness = "REFERENCE ONLY"
        blockers.append("Market session is reference-only")
    else:
        if effective_action == "WAIT":
            blockers.append(f"Final one-brain action is WAIT: {decision.blocker}")
        evaluation = {
            "CE BUY": decision.ce_buy,
            "PE BUY": decision.pe_buy,
            "CE SELL": decision.ce_sell,
            "PE SELL": decision.pe_sell,
            "IRON CONDOR": decision.iron_condor,
        }.get(setup)
        if evaluation is not None and evaluation.score < CONFIG.execution_minimum_unified_score:
            blockers.append(
                f"Strategy score {evaluation.score:.1f}% is below "
                f"entry-ready {CONFIG.execution_minimum_unified_score:.0f}%"
            )
        if decision.decision_confidence < CONFIG.decision_min_core_confidence:
            blockers.append(
                f"Entry confidence {decision.decision_confidence:.1f}% is below "
                f"{CONFIG.decision_min_core_confidence:.0f}%"
            )
        activity_blocked, activity_note = activity_gate(setup, big_player)
        if activity_note:
            (blockers if activity_blocked else reasons).append(activity_note)
        if setup == "WAIT" or plan is None:
            blockers.append("No protected setup is selected")
        elif plan.status != "READY":
            blockers.append(f"Protected setup is not READY: {plan.blocker}")
        elif (
            setup in {"CE SELL", "PE SELL", "IRON CONDOR"}
            and float(plan.estimated_credit_points or 0.0)
            < CONFIG.shadow_journal_min_sell_credit_points
        ):
            blockers.append(
                "Seller spread credit "
                f"{float(plan.estimated_credit_points or 0.0):.2f} pts is below "
                f"minimum value {CONFIG.shadow_journal_min_sell_credit_points:.1f} pts"
            )
        if not _fresh_live(feed_status, "quotes"):
            blockers.append("NIFTY quote is not confirmed live")
        if not _fresh_live(feed_status, "candles"):
            blockers.append("Completed candles are not confirmed live")
        if not _fresh_live(feed_status, "option_chain"):
            blockers.append("Option chain is not confirmed live")
        progression = feed_status.get("price_progression")
        if progression is not None and not progression.ok:
            blockers.append("NIFTY price series is flatlined / not progressing")
        expiry_quality = feed_status.get("expiry_close_quality")
        if expiry_quality is not None and not expiry_quality.ok:
            blockers.append("Expiry-close broker data is limited after 15:15")
        ready_windows, flow_mature = _flow_ready(option_intelligence)
        if option_intelligence.status != "READY":
            blockers.append("Options intelligence is not READY")
        if option_intelligence.confidence < CONFIG.execution_min_flow_confidence:
            blockers.append(
                f"Flow confidence {option_intelligence.confidence:.1f}% is below "
                f"{CONFIG.execution_min_flow_confidence:.0f}%"
            )
        if ready_windows < CONFIG.execution_required_flow_windows:
            blockers.append(
                f"Option-flow windows ready {ready_windows}/"
                f"{CONFIG.execution_required_flow_windows}"
            )
        if not flow_mature and option_intelligence.persistence in {
            "WARMING UP",
            "UNAVAILABLE",
        }:
            blockers.append("Option-flow persistence is still warming up")
        if setup != "WAIT" and not _timeframe_aligned(setup, price_action):
            blockers.append("3m and 15m trend coherence is not aligned")
        if confirmations < CONFIG.execution_required_confirmations:
            blockers.append("Final action needs consecutive fresh confirmations")
        if discipline_state.trades_taken >= 1 or discipline_state.day_locked:
            outcome = discipline_state.last_outcome or "ONE TRADE USED"
            blockers.append(f"One-trade day is locked: {outcome}")
        if after_window:
            blockers.append("New-entry window has closed")
        elif not within_window:
            reasons.append("Wait for the configured entry window")
        concrete_setup_selected = setup in {
            "CE BUY", "PE BUY", "CE SELL", "PE SELL", "IRON CONDOR"
        }
        if concrete_setup_selected and plan is not None and plan.available:
            if risk_per_lot is None:
                blockers.append("Selected protected-plan risk could not be calculated")
            elif allowed_lots < 1:
                blockers.append(
                    "0 LOTS — one-lot risk "
                    f"Rs. {risk_per_lot:,.2f} exceeds budget "
                    f"Rs. {risk_profile.risk_budget_rupees:,.2f}"
                )

        hard_block = bool(blockers)
        if hard_block:
            readiness = "BLOCKED"
        elif not within_window:
            readiness = "WATCH"
        else:
            readiness = "ENTRY READY"

    if plan is not None and plan.available:
        reasons.extend(
            [
                f"Protected {setup} plan quality {plan.quality_score:.1f}/100",
                f"Risk budget ₹{risk_profile.risk_budget_rupees:,.0f}",
                f"One-trade cap allows {allowed_lots} lot(s)",
            ]
        )
    if confirmations:
        reasons.append(signal_state)

    # Keep UI compact and deterministic.
    unique_reasons = tuple(dict.fromkeys(item for item in reasons if item))[:4]
    unique_blockers = tuple(dict.fromkeys(item for item in blockers if item))[:6]

    return ExecutionGuard(
        as_of=as_of,
        selected_setup=setup,
        readiness=readiness,
        signal_state=signal_state,
        confirmations=confirmations,
        required_confirmations=CONFIG.execution_required_confirmations,
        entry_window=entry_window,
        risk_budget_rupees=risk_profile.risk_budget_rupees,
        risk_per_lot_rupees=risk_per_lot,
        allowed_lots=allowed_lots,
        max_lots_by_budget=max_lots_by_budget,
        max_lots_cap=risk_profile.max_lots_cap,
        target_capture_points=target_capture_points,
        target_exit_debit_points=target_exit_debit_points,
        target_profit_rupees=target_profit_rupees,
        stop_loss_points=stop_loss_points,
        stop_exit_debit_points=stop_exit_debit_points,
        stop_loss_rupees=stop_loss_rupees,
        forced_exit_time=risk_profile.forced_exit.strftime("%H:%M"),
        spot_invalidation_low=invalidation_low,
        spot_invalidation_high=invalidation_high,
        trade_taken_today=discipline_state.trades_taken >= 1,
        day_locked=discipline_state.day_locked,
        reasons=unique_reasons,
        blockers=unique_blockers,
        status=readiness,
    )



def calculate_execution_guard(
    *,
    decision: FinalDecision,
    trade_plan: TradePlanBundle,
    market_session: MarketSession,
    option_intelligence: OptionIntelligence,
    price_action: PriceActionBundle,
    risk_profile: RiskProfile,
    discipline_state: DisciplineState,
    feed_status: dict[str, FeedStatus],
    as_of: datetime,
    big_player: BigPlayerActivity | None = None,
    selected_setup_override: str | None = None,
    final_action_override: str | None = None,
    simple_brain: dict | None = None,
) -> ExecutionGuard:
    """Execution/risk guard for the Simple One-Brain.

    When ``simple_brain`` is absent the exact v2.47 legacy guard is used, keeping old
    tests/replays compatible.  In Simple mode only true safety conditions are hard
    blockers: live data, protected plan, risk budget, session progression, one-trade
    discipline and entry window.  Direction/15m/3m/Future/flow are already combined
    upstream and are not repeated as independent vetoes.
    """
    if not simple_brain:
        return _calculate_execution_guard_legacy(
            decision=decision,
            trade_plan=trade_plan,
            market_session=market_session,
            option_intelligence=option_intelligence,
            price_action=price_action,
            risk_profile=risk_profile,
            discipline_state=discipline_state,
            feed_status=feed_status,
            as_of=as_of,
            big_player=big_player,
            selected_setup_override=selected_setup_override,
            final_action_override=final_action_override,
        )

    setup = str(selected_setup_override or simple_brain.get("candidate_action") or trade_plan.selected_setup or "WAIT").upper()
    plan = {
        "CE BUY": trade_plan.ce_buy,
        "PE BUY": trade_plan.pe_buy,
        "CE SELL": trade_plan.ce_sell,
        "PE SELL": trade_plan.pe_sell,
        "IRON CONDOR": trade_plan.iron_condor,
    }.get(setup)
    simple_final = str(simple_brain.get("final_action") or "WAIT").upper()
    effective_action = str(final_action_override or simple_final or "WAIT").upper()
    # A completed price-action/barrier trigger is already the confirmation. Avoid a
    # second 30/60-second persistence gate after that same event.
    required_confirmations = int(CONFIG.simple_execution_required_confirmations)
    confirmations = required_confirmations if simple_final == setup and setup != "WAIT" else 0
    signal_state = (
        f"CONFIRMED ×{confirmations}" if confirmations >= required_confirmations and confirmations > 0
        else "TRIGGER PENDING"
    )

    entry_window, within_window, after_window = _entry_window(risk_profile, as_of)
    (
        risk_per_lot,
        max_lots_by_budget,
        allowed_lots,
        target_capture_points,
        target_exit_debit_points,
        target_profit_rupees,
        stop_loss_points,
        stop_exit_debit_points,
        stop_loss_rupees,
    ) = _risk_math(plan, risk_profile)
    invalidation_low, invalidation_high = _spot_invalidations(setup, plan, price_action)

    blockers: list[str] = []
    reasons: list[str] = []
    if not market_session.is_live:
        readiness = "REFERENCE ONLY"
        blockers.append("Market session is reference-only")
    else:
        if simple_final != setup:
            blockers.append(str(simple_brain.get("instruction") or simple_brain.get("entry_state") or "Entry trigger pending"))
        if setup == "WAIT" or plan is None:
            blockers.append("No protected setup is selected")
        elif str(plan.status).upper() != "READY":
            blockers.append(f"Protected setup is not READY: {plan.blocker}")
        elif (
            setup in {"CE SELL", "PE SELL", "IRON CONDOR"}
            and float(plan.estimated_credit_points or 0.0) < CONFIG.shadow_journal_min_sell_credit_points
        ):
            blockers.append(
                f"Seller spread credit {float(plan.estimated_credit_points or 0.0):.2f} pts is below minimum value "
                f"{CONFIG.shadow_journal_min_sell_credit_points:.1f} pts"
            )

        for feed_name in ("quotes", "candles", "option_chain"):
            if not _fresh_live(feed_status, feed_name):
                blockers.append(f"{feed_name} is not confirmed live")
        progression = feed_status.get("price_progression")
        if progression is not None and not progression.ok:
            blockers.append("NIFTY price series is flatlined / not progressing")
        expiry_quality = feed_status.get("expiry_close_quality")
        if expiry_quality is not None and not expiry_quality.ok:
            blockers.append("Expiry-close broker data is limited after 15:15")
        if option_intelligence.status == "UNAVAILABLE":
            blockers.append("Options intelligence unavailable")
        elif option_intelligence.confidence < 50:
            reasons.append(f"Options confidence only {option_intelligence.confidence:.0f}% — reduced weight, not hard veto")

        if discipline_state.trades_taken >= 1 or discipline_state.day_locked:
            outcome = discipline_state.last_outcome or "ONE TRADE USED"
            blockers.append(f"One-trade day is locked: {outcome}")
        if after_window:
            blockers.append("New-entry window has closed")
        elif not within_window:
            reasons.append("Wait for the configured entry window")

        if setup != "WAIT" and plan is not None and plan.available:
            if risk_per_lot is None:
                blockers.append("Selected protected-plan risk could not be calculated")
            elif allowed_lots < 1:
                blockers.append(
                    f"0 LOTS — one-lot risk Rs. {risk_per_lot:,.2f} exceeds budget Rs. {risk_profile.risk_budget_rupees:,.2f}"
                )

        if blockers:
            readiness = "BLOCKED"
        elif not within_window:
            readiness = "WATCH"
        else:
            readiness = "ENTRY READY"

    if plan is not None and plan.available:
        reasons.extend([
            f"Simple Brain entry readiness {float(simple_brain.get('entry_readiness') or 0):.1f}/100",
            f"Protected {setup} plan quality {plan.quality_score:.1f}/100",
            f"Risk budget ₹{risk_profile.risk_budget_rupees:,.0f}",
        ])
    unique_reasons = tuple(dict.fromkeys(x for x in reasons if x))[:4]
    unique_blockers = tuple(dict.fromkeys(x for x in blockers if x))[:6]
    return ExecutionGuard(
        as_of=as_of,
        selected_setup=setup,
        readiness=readiness,
        signal_state=signal_state,
        confirmations=confirmations,
        required_confirmations=required_confirmations,
        entry_window=entry_window,
        risk_budget_rupees=risk_profile.risk_budget_rupees,
        risk_per_lot_rupees=risk_per_lot,
        allowed_lots=allowed_lots,
        max_lots_by_budget=max_lots_by_budget,
        max_lots_cap=risk_profile.max_lots_cap,
        target_capture_points=target_capture_points,
        target_exit_debit_points=target_exit_debit_points,
        target_profit_rupees=target_profit_rupees,
        stop_loss_points=stop_loss_points,
        stop_exit_debit_points=stop_exit_debit_points,
        stop_loss_rupees=stop_loss_rupees,
        forced_exit_time=risk_profile.forced_exit.strftime("%H:%M"),
        spot_invalidation_low=invalidation_low,
        spot_invalidation_high=invalidation_high,
        trade_taken_today=discipline_state.trades_taken >= 1,
        day_locked=discipline_state.day_locked,
        reasons=unique_reasons,
        blockers=unique_blockers,
        status=readiness,
    )
