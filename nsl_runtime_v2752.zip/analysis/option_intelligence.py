from __future__ import annotations

import math
from datetime import datetime
from typing import Any

import pandas as pd

from config import CONFIG
from models import FlowWindow, OIWall, OptionIntelligence, PCRBundle


NUMERIC_COLUMNS = (
    "strike",
    "security_id",
    "last_price",
    "top_bid_price",
    "top_ask_price",
    "oi",
    "volume",
    "previous_oi",
    "previous_volume",
    "previous_close_price",
    "day_oi_change",
    "day_price_change",
    "implied_volatility",
)


def _rows_to_frame(rows: list[dict[str, Any]]) -> pd.DataFrame:
    frame = pd.DataFrame(rows)
    if frame.empty:
        return frame
    for column in NUMERIC_COLUMNS:
        if column in frame.columns:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
    frame["side"] = frame["side"].astype(str).str.upper()
    return frame.sort_values(["strike", "side"]).reset_index(drop=True)


def _safe_sum(series: pd.Series) -> float:
    return float(pd.to_numeric(series, errors="coerce").fillna(0.0).sum())


def _finite(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _fair_premium(frame: pd.DataFrame) -> pd.Series:
    """Use a healthy executable midpoint, otherwise fall back to broker LTP."""

    blank = pd.Series(float("nan"), index=frame.index, dtype=float)
    last = pd.to_numeric(frame["last_price"], errors="coerce") if "last_price" in frame else blank
    bid = pd.to_numeric(frame["top_bid_price"], errors="coerce") if "top_bid_price" in frame else blank
    ask = pd.to_numeric(frame["top_ask_price"], errors="coerce") if "top_ask_price" in frame else blank
    valid = bid.gt(0) & ask.gt(0) & ask.ge(bid)
    midpoint = (bid + ask) / 2.0
    spread_pct = (ask - bid).div(midpoint.where(midpoint.gt(0))).mul(100.0)
    valid &= spread_pct.le(20.0)
    return midpoint.where(valid, last)


def _ratio(numerator: float, denominator: float) -> float | None:
    if denominator <= 0:
        return None
    return round(numerator / denominator, 4)


def _classify_flow(
    *,
    price_delta: float,
    oi_delta: float,
    premium_reference: float,
    oi_reference: float,
) -> str:
    price_threshold = max(
        CONFIG.option_min_price_move_points,
        abs(premium_reference) * CONFIG.option_min_price_move_pct / 100.0,
    )
    oi_threshold = max(1.0, abs(oi_reference) * CONFIG.option_min_oi_move_pct / 100.0)
    price_up = price_delta >= price_threshold
    price_down = price_delta <= -price_threshold
    oi_up = oi_delta >= oi_threshold
    oi_down = oi_delta <= -oi_threshold
    if price_up and oi_up:
        return "LONG BUILDUP"
    if price_down and oi_up:
        return "SHORT BUILDUP"
    if price_up and oi_down:
        return "SHORT COVERING"
    if price_down and oi_down:
        return "LONG UNWINDING"
    return "NOISE / FLAT"


def _direction_for(side: str, classification: str) -> str:
    mapping = {
        ("CE", "LONG BUILDUP"): "BULLISH",
        ("CE", "SHORT BUILDUP"): "BEARISH",
        ("CE", "SHORT COVERING"): "BULLISH",
        ("CE", "LONG UNWINDING"): "BEARISH",
        ("PE", "LONG BUILDUP"): "BEARISH",
        ("PE", "SHORT BUILDUP"): "BULLISH",
        ("PE", "SHORT COVERING"): "BEARISH",
        ("PE", "LONG UNWINDING"): "BULLISH",
    }
    return mapping.get((side, classification), "NEUTRAL")


def _flow_strength(
    *,
    oi_delta: float,
    oi_reference: float,
    volume_delta: float,
    strike: float,
    spot: float,
) -> float:
    oi_fraction = abs(oi_delta) / max(abs(oi_reference), 1.0)
    oi_component = min(
        3.0, oi_fraction * 100.0 / max(CONFIG.option_min_oi_move_pct, 0.01)
    )
    volume_component = 1.20 if volume_delta > 0 else 0.80
    distance = abs(strike - spot)
    proximity_component = max(0.55, 1.0 - distance / 500.0)
    return round(oi_component * volume_component * proximity_component, 4)


def _merge_flow(
    current: pd.DataFrame,
    previous: pd.DataFrame | None,
    spot: float,
) -> tuple[pd.DataFrame, str]:
    base = current.copy()
    if base.empty:
        return base, "UNAVAILABLE"
    base["fair_premium"] = _fair_premium(base)
    if previous is not None and not previous.empty:
        previous = previous.copy()
        previous["fair_premium"] = _fair_premium(previous)
        merge_keys = ["strike", "side"]
        if (
            "security_id" in base
            and "security_id" in previous
            and base["security_id"].notna().any()
            and previous["security_id"].notna().any()
        ):
            merge_keys.append("security_id")
        prior = previous[[*merge_keys, "fair_premium", "oi", "volume"]].rename(
            columns={
                "fair_premium": "prior_fair_premium",
                "oi": "prior_oi",
                "volume": "prior_volume",
            }
        )
        base = base.merge(prior, on=merge_keys, how="left")
        base["price_delta"] = base["fair_premium"] - base["prior_fair_premium"]
        base["oi_delta"] = base["oi"] - base["prior_oi"]
        raw_volume_delta = base["volume"] - base["prior_volume"]
        base["volume_delta"] = raw_volume_delta.where(raw_volume_delta.ge(0))
        basis = "EXPIRY + STRIKE + SECURITY MATCHED INTRADAY DELTA"
    else:
        base["prior_fair_premium"] = base.get("previous_close_price")
        base["prior_oi"] = base.get("previous_oi")
        base["prior_volume"] = base.get("previous_volume")
        base["price_delta"] = base.get("day_price_change", 0.0)
        base["oi_delta"] = base.get("day_oi_change", 0.0)
        base["volume_delta"] = pd.to_numeric(
            base.get("volume", 0.0), errors="coerce"
        ).fillna(0.0)
        basis = "DAY CHANGE — FIRST SNAPSHOT"

    rows: list[dict[str, Any]] = []
    for raw in base.to_dict(orient="records"):
        strike = _finite(raw.get("strike")) or 0.0
        side = str(raw.get("side") or "").upper()
        premium = _finite(raw.get("fair_premium")) or 0.0
        oi = _finite(raw.get("oi")) or 0.0
        prior_oi = _finite(raw.get("prior_oi"))
        raw_price_delta = _finite(raw.get("price_delta"))
        raw_oi_delta = _finite(raw.get("oi_delta"))
        raw_volume_delta = _finite(raw.get("volume_delta"))
        integrity_ok = (
            raw_price_delta is not None
            and raw_oi_delta is not None
            and raw_volume_delta is not None
            and prior_oi is not None
            and prior_oi > 0
        )
        price_delta = raw_price_delta or 0.0
        oi_delta = raw_oi_delta or 0.0
        volume_delta = raw_volume_delta or 0.0
        classification = _classify_flow(
            price_delta=price_delta,
            oi_delta=oi_delta,
            premium_reference=premium,
            oi_reference=prior_oi or oi,
        )
        if previous is not None and not integrity_ok:
            classification = "NOISE / FLAT"
        direction = _direction_for(side, classification)
        strength = _flow_strength(
            oi_delta=oi_delta,
            oi_reference=prior_oi or oi,
            volume_delta=volume_delta,
            strike=strike,
            spot=spot,
        )
        raw.update(
            {
                "price_delta": round(price_delta, 4),
                "oi_delta": round(oi_delta, 4),
                "volume_delta": round(volume_delta, 4),
                "classification": classification,
                "directional_bias": direction,
                "flow_strength": strength if classification != "NOISE / FLAT" else 0.0,
                "integrity_status": (
                    "READY" if integrity_ok or previous is None else "INVALID COMPARISON"
                ),
            }
        )
        rows.append(raw)
    return pd.DataFrame(rows).sort_values(["strike", "side"]).reset_index(
        drop=True
    ), basis


def _snapshot_time(item: dict[str, Any]) -> datetime | None:
    try:
        return datetime.fromisoformat(str(item["captured_at"]))
    except (KeyError, TypeError, ValueError):
        return None


def _comparison_age_seconds(
    newer: dict[str, Any], older: dict[str, Any]
) -> float | None:
    newer_time = _snapshot_time(newer)
    older_time = _snapshot_time(older)
    if newer_time is None or older_time is None:
        return None
    return (newer_time - older_time).total_seconds()


def _latest_recent_snapshot(
    history: list[dict[str, Any]], current_time: datetime
) -> dict[str, Any] | None:
    candidates: list[tuple[float, dict[str, Any]]] = []
    for item in history:
        captured_at = _snapshot_time(item)
        if captured_at is None:
            continue
        age = (current_time - captured_at).total_seconds()
        if 0 < age <= CONFIG.option_max_comparison_age_seconds:
            candidates.append((age, item))
    if not candidates:
        return None
    return min(candidates, key=lambda pair: pair[0])[1]


def _choose_history_sample(
    history: list[dict[str, Any]],
    current_time: datetime,
    target_seconds: int,
) -> tuple[dict[str, Any] | None, float | None]:
    tolerance = min(target_seconds * CONFIG.option_window_tolerance_ratio, target_seconds * 0.20)
    minimum_age = max(10.0, target_seconds - tolerance)
    # A 60s timer plus fetch latency commonly yields 75-90s observations.
    # Report actual age; never stretch a one-minute comparison beyond 90s.
    maximum_age = target_seconds + max(tolerance, min(90.0, target_seconds * 0.5))
    candidates: list[tuple[float, dict[str, Any]]] = []
    for item in history:
        captured_at = _snapshot_time(item)
        if captured_at is None:
            continue
        age = (current_time - captured_at).total_seconds()
        if minimum_age <= age <= maximum_age:
            candidates.append((abs(age - target_seconds), item))
    if not candidates:
        return None, None
    _, chosen = min(candidates, key=lambda pair: pair[0])
    chosen_time = _snapshot_time(chosen)
    actual = (current_time - chosen_time).total_seconds() if chosen_time else None
    if actual is None:
        return None, None
    return chosen, round(actual, 1)


def _window(
    *,
    label: str,
    target_seconds: int,
    current: pd.DataFrame,
    spot: float,
    current_time: datetime,
    history: list[dict[str, Any]],
) -> FlowWindow:
    sample, age = _choose_history_sample(history, current_time, target_seconds)
    if sample is None:
        return FlowWindow(
            label=label,
            target_seconds=target_seconds,
            actual_age_seconds=None,
            ce_oi_delta=None,
            pe_oi_delta=None,
            ce_premium_delta=None,
            pe_premium_delta=None,
            ce_volume_delta=None,
            pe_volume_delta=None,
            bias="UNAVAILABLE",
            status="INSUFFICIENT CONTINUITY",
        )
    previous = _rows_to_frame(sample.get("rows") or [])
    flow, _ = _merge_flow(current, previous, spot)
    valid_rows = (
        flow["integrity_status"].eq("READY").sum()
        if not flow.empty and "integrity_status" in flow
        else 0
    )
    if flow.empty or valid_rows < 4:
        bias = "UNAVAILABLE"
    else:
        directional = flow.apply(
            lambda row: row["flow_strength"]
            if row["directional_bias"] == "BULLISH"
            else -row["flow_strength"]
            if row["directional_bias"] == "BEARISH"
            else 0.0,
            axis=1,
        ).sum()
        bias = (
            "BULLISH"
            if directional > 0.75
            else "BEARISH"
            if directional < -0.75
            else "MIXED"
        )

    def side_sum(side: str, column: str) -> float:
        return round(_safe_sum(flow.loc[flow["side"] == side, column]), 4)

    return FlowWindow(
        label=label,
        target_seconds=target_seconds,
        actual_age_seconds=age,
        ce_oi_delta=side_sum("CE", "oi_delta"),
        pe_oi_delta=side_sum("PE", "oi_delta"),
        ce_premium_delta=side_sum("CE", "price_delta"),
        pe_premium_delta=side_sum("PE", "price_delta"),
        ce_volume_delta=side_sum("CE", "volume_delta"),
        pe_volume_delta=side_sum("PE", "volume_delta"),
        bias=bias,
        status="READY" if valid_rows >= 4 else "INVALID OI COMPARISON",
    )


def _wall(
    side: str,
    current: pd.DataFrame,
    previous: pd.DataFrame | None,
) -> OIWall:
    subset = current[current["side"] == side].dropna(subset=["strike", "oi"]).copy()
    if subset.empty:
        return OIWall(side, None, None, None, None, None, None, "UNAVAILABLE")
    top = subset.loc[subset["oi"].idxmax()]
    strike = float(top["strike"])
    oi = float(top["oi"])
    previous_strike = None
    migration = None
    if previous is not None and not previous.empty:
        prior = previous[previous["side"] == side].dropna(subset=["strike", "oi"])
        if not prior.empty:
            previous_strike = float(prior.loc[prior["oi"].idxmax(), "strike"])
            migration = round(strike - previous_strike, 2)

    strikes = sorted(subset["strike"].unique())
    cluster_values: list[tuple[float, float]] = []
    for center in strikes:
        index = strikes.index(center)
        selected = set(strikes[max(0, index - 1) : min(len(strikes), index + 2)])
        cluster_oi = _safe_sum(subset.loc[subset["strike"].isin(selected), "oi"])
        cluster_values.append((cluster_oi, float(center)))
    cluster_oi, cluster_center = max(cluster_values)
    return OIWall(
        side=side,
        strike=strike,
        oi=round(oi, 2),
        previous_strike=previous_strike,
        migration_points=migration,
        cluster_center=cluster_center,
        cluster_oi=round(cluster_oi, 2),
        status="READY",
    )


def _pcr(current: pd.DataFrame, flow: pd.DataFrame) -> PCRBundle:
    ce = current[current["side"] == "CE"]
    pe = current[current["side"] == "PE"]
    ce_oi = _safe_sum(ce["oi"])
    pe_oi = _safe_sum(pe["oi"])
    ce_day_add = _safe_sum(
        ce.get("day_oi_change", pd.Series(dtype=float)).clip(lower=0)
    )
    pe_day_add = _safe_sum(
        pe.get("day_oi_change", pd.Series(dtype=float)).clip(lower=0)
    )
    ce_volume = _safe_sum(ce["volume"])
    pe_volume = _safe_sum(pe["volume"])
    ce_intraday = _safe_sum(flow.loc[flow["side"] == "CE", "oi_delta"].clip(lower=0))
    pe_intraday = _safe_sum(flow.loc[flow["side"] == "PE", "oi_delta"].clip(lower=0))
    oi_pcr = _ratio(pe_oi, ce_oi)
    day_pcr = _ratio(pe_day_add, ce_day_add)
    intraday_pcr = _ratio(pe_intraday, ce_intraday)
    volume_pcr = _ratio(pe_volume, ce_volume)
    context_value = (
        intraday_pcr
        if intraday_pcr is not None
        else day_pcr
        if day_pcr is not None
        else oi_pcr
    )
    if context_value is None:
        state = "UNAVAILABLE"
    elif context_value >= 1.20:
        state = "PE OI DOMINANT"
    elif context_value <= 0.80:
        state = "CE OI DOMINANT"
    else:
        state = "BALANCED"
    return PCRBundle(
        near_atm_oi_pcr=oi_pcr,
        day_addition_pcr=day_pcr,
        intraday_addition_pcr=intraday_pcr,
        volume_pcr=volume_pcr,
        state=state,
        status="READY" if oi_pcr is not None else "UNAVAILABLE",
    )


def _snapshot_bias(current: dict[str, Any], previous: dict[str, Any]) -> str:
    current_frame = _rows_to_frame(current.get("rows") or [])
    previous_frame = _rows_to_frame(previous.get("rows") or [])
    if current_frame.empty or previous_frame.empty:
        return "UNAVAILABLE"
    spot = float(current.get("spot") or current_frame["strike"].median())
    flow, _ = _merge_flow(current_frame, previous_frame, spot)
    score = 0.0
    for row in flow.to_dict(orient="records"):
        if row["directional_bias"] == "BULLISH":
            score += float(row["flow_strength"])
        elif row["directional_bias"] == "BEARISH":
            score -= float(row["flow_strength"])
    return "BULLISH" if score > 0.75 else "BEARISH" if score < -0.75 else "MIXED"


def _persistence(
    history: list[dict[str, Any]], current_snapshot: dict[str, Any], current_bias: str
) -> str:
    sequence = [*history, current_snapshot]
    pair_biases: list[str] = []
    start_index = max(1, len(sequence) - CONFIG.option_persistence_lookback)
    for index in range(start_index, len(sequence)):
        if index <= 0:
            continue
        gap = _comparison_age_seconds(sequence[index], sequence[index - 1])
        if gap is None or gap <= 0 or gap > CONFIG.option_max_comparison_age_seconds:
            pair_biases.append("CONTINUITY GAP")
            continue
        pair_biases.append(_snapshot_bias(sequence[index], sequence[index - 1]))

    trailing = 0
    for item in reversed(pair_biases):
        if item == "CONTINUITY GAP":
            break
        if item == current_bias:
            trailing += 1
        else:
            break
    if current_bias in {"BULLISH", "BEARISH"} and trailing >= 3:
        return f"{current_bias} PERSISTENT ×{trailing}"
    if current_bias in {"BULLISH", "BEARISH"} and trailing >= 2:
        return f"{current_bias} DEVELOPING ×{trailing}"
    usable = [item for item in pair_biases if item in {"BULLISH", "BEARISH", "MIXED"}]
    if not usable:
        return "WARMING UP"
    return "MIXED / NOT PERSISTENT"


def _normalized_scores(
    flow: pd.DataFrame, pcr: PCRBundle
) -> tuple[float, float, float, str]:
    bullish = 0.0
    bearish = 0.0
    neutral = 1.0
    for row in flow.to_dict(orient="records"):
        strength = float(row.get("flow_strength") or 0.0)
        direction = row.get("directional_bias")
        if direction == "BULLISH":
            bullish += strength
        elif direction == "BEARISH":
            bearish += strength
        else:
            neutral += max(0.25, strength * 0.25)

    # PCR is context, never a standalone direction vote. It may reinforce an
    # already matching premium+OI+volume flow, otherwise it adds uncertainty.
    if pcr.state == "PE OI DOMINANT":
        if bullish > bearish:
            bullish += 0.35
        else:
            neutral += 0.50
    elif pcr.state == "CE OI DOMINANT":
        if bearish > bullish:
            bearish += 0.35
        else:
            neutral += 0.50
    else:
        neutral += 0.50

    total = bullish + bearish + neutral
    if total <= 0:
        return 0.0, 0.0, 100.0, "MIXED"
    bull_pct = round(bullish / total * 100.0, 1)
    bear_pct = round(bearish / total * 100.0, 1)
    range_pct = round(max(0.0, 100.0 - bull_pct - bear_pct), 1)
    bias = (
        "BULLISH"
        if bull_pct >= max(bear_pct, range_pct) + 8
        else "BEARISH"
        if bear_pct >= max(bull_pct, range_pct) + 8
        else "MIXED"
    )
    return bull_pct, bear_pct, range_pct, bias


def _blend_movement_windows(
    bullish: float,
    bearish: float,
    range_score: float,
    windows: tuple[FlowWindow, ...],
) -> tuple[float, float, float]:
    """Blend the same option-flow evidence across time, without double counting it.

    The instantaneous snapshot remains useful for fast turns, but a 20-30 second
    comparison must not overpower ready 1m/3m/5m movement windows.  Windows are an
    aggregation of the same OI/premium/volume source, so they replace part of the
    instantaneous score rather than adding a second independent vote.
    """

    ready = [item for item in windows if item.status == "READY"]
    if not ready:
        return bullish, bearish, range_score

    weights = {60: 0.20, 180: 0.35, 300: 0.45}
    bull_weight = bear_weight = mixed_weight = 0.0
    total_weight = 0.0
    for item in ready:
        weight = weights.get(item.target_seconds, 0.25)
        total_weight += weight
        if item.bias == "BULLISH":
            bull_weight += weight
        elif item.bias == "BEARISH":
            bear_weight += weight
        else:
            mixed_weight += weight
    if total_weight <= 0:
        return bullish, bearish, range_score

    # A directional window still retains uncertainty. Conflicting windows naturally
    # increase both sides/range instead of producing a false 90% RANGE result.
    window_bull = (bull_weight + mixed_weight * 0.20) / total_weight * 70.0
    window_bear = (bear_weight + mixed_weight * 0.20) / total_weight * 70.0
    window_range = max(0.0, 100.0 - window_bull - window_bear)
    window_share = {1: 0.35, 2: 0.50, 3: 0.60}.get(len(ready), 0.60)
    values = (
        bullish * (1.0 - window_share) + window_bull * window_share,
        bearish * (1.0 - window_share) + window_bear * window_share,
        range_score * (1.0 - window_share) + window_range * window_share,
    )
    total = sum(values)
    if total <= 0:
        return 20.0, 20.0, 60.0
    result = [round(value / total * 100.0, 1) for value in values]
    result[2] = round(100.0 - result[0] - result[1], 1)
    return result[0], result[1], result[2]


def _bias_from_scores(bullish: float, bearish: float, range_score: float) -> str:
    if bullish >= max(bearish, range_score) + 8:
        return "BULLISH"
    if bearish >= max(bullish, range_score) + 8:
        return "BEARISH"
    return "MIXED"


def _compress_short_window_reversal(
    bullish: float, bearish: float, range_score: float, windows: tuple[FlowWindow, ...]
) -> tuple[float, float, float]:
    """Prevent a stale 5m vote from printing an extreme score during a fresh turn.

    If ready 1m and 3m windows agree against the 5m window, the market is in a
    transition.  The 5m evidence is retained, but the display/brain score is
    compressed toward the faster agreement instead of showing a misleading 90%+.
    """
    ready = [item for item in windows if item.status == "READY"]
    by_seconds = {item.target_seconds: item.bias for item in ready}
    fast1, fast3, slow5 = by_seconds.get(60), by_seconds.get(180), by_seconds.get(300)
    if fast1 not in {"BULLISH", "BEARISH"} or fast1 != fast3 or slow5 not in {"BULLISH", "BEARISH"} or slow5 == fast1:
        return bullish, bearish, range_score
    target = (55.0, 20.0, 25.0) if fast1 == "BULLISH" else (20.0, 55.0, 25.0)
    mixed = [
        bullish * 0.55 + target[0] * 0.45,
        bearish * 0.55 + target[1] * 0.45,
        range_score * 0.55 + target[2] * 0.45,
    ]
    total = sum(mixed) or 1.0
    result = [round(v / total * 100.0, 1) for v in mixed]
    result[2] = round(100.0 - result[0] - result[1], 1)
    return result[0], result[1], result[2]


def _calibrate_scores_for_confidence(
    bullish: float, bearish: float, range_score: float, confidence: float
) -> tuple[float, float, float]:
    """Shrink low-confidence option-flow extremes toward an uncertainty baseline.

    A first/day-change snapshot can have a very one-sided raw classification while
    intraday continuity is still 0/3. Displaying 99/0/1 at 38% confidence overstates
    certainty, so the scores are blended toward 20/20/60 until continuity matures.
    """
    weight = max(0.0, min(1.0, float(confidence) / 100.0))
    baseline = (20.0, 20.0, 60.0)
    values = (bullish, bearish, range_score)
    blended = [values[i] * weight + baseline[i] * (1.0 - weight) for i in range(3)]
    total = sum(blended)
    if total <= 0:
        return 20.0, 20.0, 60.0
    result = [round(value / total * 100.0, 1) for value in blended]
    result[2] = round(100.0 - result[0] - result[1], 1)
    return result[0], result[1], result[2]

def calculate_option_intelligence(
    *,
    current_frame: pd.DataFrame,
    spot: float,
    expiry: str | None,
    captured_at: datetime,
    history: list[dict[str, Any]],
    current_snapshot: dict[str, Any],
    is_live: bool,
) -> OptionIntelligence:
    empty_wall_ce = OIWall("CE", None, None, None, None, None, None, "UNAVAILABLE")
    empty_wall_pe = OIWall("PE", None, None, None, None, None, None, "UNAVAILABLE")
    empty_pcr = PCRBundle(None, None, None, None, "UNAVAILABLE", "UNAVAILABLE")
    empty_windows = tuple(
        FlowWindow(
            label,
            seconds,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            "UNAVAILABLE",
            "INSUFFICIENT CONTINUITY",
        )
        for label, seconds in (("1 minute", 60), ("3 minute", 180), ("5 minute", 300))
    )
    if current_frame.empty or not expiry:
        return OptionIntelligence(
            as_of=captured_at,
            basis="UNAVAILABLE",
            snapshot_count=len(history),
            bullish_score=0.0,
            bearish_score=0.0,
            range_score=100.0,
            confidence=0.0,
            market_bias="UNAVAILABLE",
            persistence="UNAVAILABLE",
            ce_wall=empty_wall_ce,
            pe_wall=empty_wall_pe,
            pcr=empty_pcr,
            windows=empty_windows,
            flow_rows=(),
            reasons=(),
            blockers=("Option chain unavailable",),
            status="UNAVAILABLE",
        )

    current = current_frame.copy()
    for column in NUMERIC_COLUMNS:
        if column in current.columns:
            current[column] = pd.to_numeric(current[column], errors="coerce")
    previous_snapshot = _latest_recent_snapshot(history, captured_at)
    continuity_reset = bool(history) and previous_snapshot is None
    previous_frame = (
        _rows_to_frame(previous_snapshot.get("rows") or [])
        if previous_snapshot
        else None
    )
    flow, basis = _merge_flow(current, previous_frame, spot)
    valid_flow_rows = (
        int(flow["integrity_status"].eq("READY").sum())
        if "integrity_status" in flow
        else 0
    )
    integrity_ready = previous_snapshot is None or valid_flow_rows >= 4
    if continuity_reset:
        basis = "DAY CHANGE — CONTINUITY RESET"
    pcr = _pcr(current, flow)
    ce_wall = _wall("CE", current, previous_frame)
    pe_wall = _wall("PE", current, previous_frame)
    windows = tuple(
        _window(
            label=label,
            target_seconds=seconds,
            current=current,
            spot=spot,
            current_time=captured_at,
            history=history,
        )
        for label, seconds in (("1 minute", 60), ("3 minute", 180), ("5 minute", 300))
    )
    # Five-minute matched contracts provide the stable base, but ready 1m/3m/5m
    # windows are blended below.  Faster windows therefore warn about a turn without
    # creating a second independent OI vote.
    main_sample, main_age = _choose_history_sample(history, captured_at, 300)
    main_ready = False
    if main_sample is not None:
        main_flow, _ = _merge_flow(current, _rows_to_frame(main_sample.get("rows") or []), spot)
        main_ready = not main_flow.empty and int(main_flow.integrity_status.eq("READY").sum()) >= 4
        if main_ready:
            flow = main_flow
            pcr = _pcr(current, flow)
            basis = f"5M MATCHED FLOW ({main_age:.0f}s); 1m/3m early warning only"
    if main_ready and flow.oi_delta.abs().sum() > 0:
        bullish, bearish, range_score, _ = _normalized_scores(flow, pcr)
    else:
        bullish = bearish = range_score = 0.0
        basis = "5M WARMING UP / OI UNCHANGED — no invented range vote"
    preliminary_bias = _bias_from_scores(bullish, bearish, range_score)
    persistence = _persistence(history, current_snapshot, preliminary_bias)
    ready_windows = sum(item.status == "READY" for item in windows)
    if previous_snapshot is None or not integrity_ready:
        confidence = 20.0
    else:
        # Continuity owns usability: a structurally valid day-change snapshot is
        # not the same thing as a live intraday OI-change signal.
        confidence = {0: 25.0, 1: 42.0, 2: 60.0, 3: 76.0}[ready_windows]
        if persistence.endswith("×3") or "PERSISTENT" in persistence:
            confidence += 8.0
    confidence = round(min(90.0, confidence), 1)
    if not main_ready:
        confidence = min(confidence, 20.0)

    # Use the multi-window blend only after a genuine matched-flow base exists.
    # A first/warming snapshot must stay zero-vote rather than inventing 20/20/60.
    if main_ready:
        bullish, bearish, range_score = _blend_movement_windows(
            bullish, bearish, range_score, windows
        )
        bullish, bearish, range_score = _compress_short_window_reversal(
            bullish, bearish, range_score, windows
        )
        bullish, bearish, range_score = _calibrate_scores_for_confidence(
            bullish, bearish, range_score, confidence
        )
    market_bias = _bias_from_scores(bullish, bearish, range_score)

    reasons: list[str] = []
    if market_bias != "MIXED":
        reasons.append(f"Option flow mix is {market_bias}")
    reasons.append(pcr.state)
    ready_biases = [item.bias for item in windows if item.status == "READY"]
    if ready_biases:
        reasons.append("Windows 1m/3m/5m: " + "/".join(ready_biases))
    if ce_wall.strike is not None and pe_wall.strike is not None:
        reasons.append(f"CE wall {ce_wall.strike:.0f} / PE wall {pe_wall.strike:.0f}")
    blockers: list[str] = []
    if previous_snapshot is None:
        blockers.append(
            "Previous snapshot too old; continuity reset"
            if continuity_reset
            else "First snapshot: intraday delta is warming up"
        )
    elif not integrity_ready:
        blockers.append(
            f"Expiry/security matched OI comparisons ready {valid_flow_rows}/4"
        )
    if ready_windows < 3:
        blockers.append(f"Movement windows ready {ready_windows}/3")
    if not is_live:
        blockers.append("Reference-only market session")
    status = (
        "REFERENCE ONLY"
        if not is_live
        else "READY"
        if previous_snapshot is not None and integrity_ready and ready_windows >= 2
        else "WARMING UP"
    )

    display_columns = (
        "strike",
        "side",
        "is_atm",
        "last_price",
        "price_delta",
        "oi",
        "oi_delta",
        "volume",
        "volume_delta",
        "classification",
        "directional_bias",
        "flow_strength",
        "integrity_status",
        "implied_volatility",
    )
    flow_rows = tuple(
        {
            key: (None if isinstance(value, float) and math.isnan(value) else value)
            for key, value in row.items()
            if key in display_columns
        }
        for row in flow.to_dict(orient="records")
    )
    return OptionIntelligence(
        as_of=captured_at,
        basis=basis,
        snapshot_count=len(history) + (1 if is_live else 0),
        bullish_score=bullish,
        bearish_score=bearish,
        range_score=range_score,
        confidence=confidence,
        market_bias=market_bias,
        persistence=persistence,
        ce_wall=ce_wall,
        pe_wall=pe_wall,
        pcr=pcr,
        windows=windows,
        flow_rows=flow_rows,
        reasons=tuple(reasons[:3]),
        blockers=tuple(blockers),
        status=status,
    )
