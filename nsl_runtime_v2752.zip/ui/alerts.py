from __future__ import annotations

import io
import json
import math
import struct
import wave
from datetime import datetime
from zoneinfo import ZoneInfo

import streamlit as st

from analysis.alerts import target_crossed
from config import IST_TIMEZONE
from models import MarketSnapshot
from services.railway_live_client import (
    delete_railway_alert,
    fetch_railway_premium_alerts,
    post_railway_json,
)


def _persistent_bool_toggle(label: str, key: str, default: bool) -> bool:
    """Preserve alert preference when optional alert controls are not rendered."""
    widget_key = f"__widget__{key}"
    if key not in st.session_state:
        st.session_state[key] = bool(default)
    if widget_key not in st.session_state:
        st.session_state[widget_key] = bool(st.session_state.get(key, default))
    value = bool(st.toggle(label, key=widget_key))
    st.session_state[key] = value
    return value


def _bell_wav() -> bytes:
    sample_rate = 22050
    duration = 1.35
    frames = bytearray()
    for index in range(int(sample_rate * duration)):
        second = index / sample_rate
        envelope = max(0.0, 1.0 - second / duration)
        pulse = 1.0 if second < 0.36 or 0.52 < second < 0.88 else 0.0
        value = (
            math.sin(2 * math.pi * 880 * second)
            + 0.45 * math.sin(2 * math.pi * 1320 * second)
        )
        sample = int(11000 * envelope * pulse * value / 1.45)
        frames.extend(struct.pack("<h", sample))
    output = io.BytesIO()
    with wave.open(output, "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(bytes(frames))
    return output.getvalue()


def _play_alert(message: str) -> None:
    st.audio(_bell_wav(), format="audio/wav", autoplay=True)
    safe_message = json.dumps(str(message))
    st.iframe(
        f"""
        <script>
        const message = {safe_message};
        if ('speechSynthesis' in window) {{
          window.speechSynthesis.cancel();
          const voice = new SpeechSynthesisUtterance(message);
          voice.rate = 0.92;
          voice.pitch = 1.0;
          window.speechSynthesis.speak(voice);
        }}
        </script>
        """,
        height=1,
        width="stretch",
    )


def _available_strikes(snapshot: MarketSnapshot, option_side: str) -> list[float]:
    frame = snapshot.option_chain
    if frame is None or frame.empty or not {"side", "strike"}.issubset(frame.columns):
        return []
    rows = frame[frame["side"].astype(str).str.upper() == option_side]
    values = sorted(
        {
            float(value)
            for value in rows["strike"].dropna().tolist()
            if float(value) > 0
        }
    )
    return values


def _option_premium(
    snapshot: MarketSnapshot, option_side: str, strike: float
) -> float | None:
    frame = snapshot.option_chain
    required = {"side", "strike", "last_price"}
    if frame is None or frame.empty or not required.issubset(frame.columns):
        return None
    rows = frame[
        (frame["side"].astype(str).str.upper() == option_side)
        & ((frame["strike"].astype(float) - float(strike)).abs() < 0.01)
    ]
    if rows.empty:
        return None
    try:
        value = float(rows.iloc[0]["last_price"])
    except (TypeError, ValueError):
        return None
    return value if value >= 0 else None


def _option_security_id(snapshot: MarketSnapshot, option_side: str, strike: float) -> int | None:
    frame = snapshot.option_chain
    required = {"side", "strike", "security_id"}
    if frame is None or frame.empty or not required.issubset(frame.columns):
        return None
    rows = frame[
        (frame["side"].astype(str).str.upper() == option_side)
        & ((frame["strike"].astype(float) - float(strike)).abs() < 0.01)
    ]
    if rows.empty:
        return None
    try:
        return int(rows.iloc[0]["security_id"])
    except (TypeError, ValueError):
        return None


def render_market_alerts(
    snapshot: MarketSnapshot,
    *,
    live_server_url: str = "",
    live_server_api_key: str = "",
) -> None:
    """Manual CE/PE premium alert only.

    Automatic Big Player delivery lives in the combined W/M+Candle+Big Player
    alert lane so the same market event cannot ring from two UI sections.
    """
    sound_enabled = bool(st.session_state.get("market_alert_sound_enabled", False))

    # Railway is the durable alert authority. After a Streamlit reconnect/new
    # session, restore the latest ACTIVE premium alert into the browser UI so it
    # does not appear to have switched itself off while the server monitor is alive.
    if (
        live_server_url
        and live_server_api_key
        and not st.session_state.get("manual_option_alert_cloud_state_checked", False)
    ):
        try:
            cloud_rows = fetch_railway_premium_alerts(
                live_server_url, live_server_api_key, timeout_seconds=2.5
            )
            active_rows = [
                row for row in cloud_rows if str(row.get("status", "")).upper() == "ACTIVE"
            ]
            if active_rows:
                row = active_rows[-1]
                st.session_state.manual_option_cloud_alert_id = row.get("id")
                st.session_state.manual_option_alert_active = True
                st.session_state.manual_option_alert_side = str(row.get("side") or "CE")
                st.session_state.manual_option_alert_position = str(row.get("position") or "BUY")
                st.session_state.manual_option_alert_strike = float(row.get("strike") or 0.0)
                st.session_state.manual_option_alert_target = float(row.get("target_premium") or 0.0)
                st.session_state.manual_option_alert_expiry = str(row.get("expiry") or "")
            st.session_state.manual_option_alert_cloud_active_count = len(active_rows)
        except Exception as exc:
            st.session_state.manual_option_alert_cloud_sync_error = type(exc).__name__
        finally:
            st.session_state.manual_option_alert_cloud_state_checked = True

    st.subheader("🔔 Manual CE/PE Premium Alert")
    st.caption(
        "Target premium tum khud set karoge. Yeh alert-only hai; One-Brain decision ya broker order ko change nahi karta. "
        "Big Player alerts ab Strong Candle / W-M / Big Player combined section me hain."
    )

    sound_col, test_col = st.columns(2)
    with sound_col:
        sound_enabled = _persistent_bool_toggle(
            "Alert Sound ON",
            "market_alert_sound_enabled",
            sound_enabled,
        )
    with test_col:
        test_sound = st.button(
            "🔊 Enable / Test Ring",
            width="stretch",
            disabled=not sound_enabled,
            key="test_market_alert_sound",
        )
    if test_sound:
        _play_alert("Nifty Seller Lite alert sound is ready.")
        st.success("Sound ready—browser me awaaz sunai deni chahiye.")

    option_side = st.selectbox(
        "Option type", ("CE", "PE"), key="manual_option_alert_side_input"
    )
    position = st.selectbox(
        "Position", ("BUY", "SELL"), key="manual_option_alert_position_input"
    )
    strikes = _available_strikes(snapshot, option_side)
    strike = (
        st.selectbox(
            "Strike",
            strikes,
            format_func=lambda value: f"{value:,.0f} {option_side}",
            key="manual_option_alert_strike_input",
            disabled=not strikes,
        )
        if strikes
        else None
    )
    current_premium = (
        _option_premium(snapshot, option_side, float(strike))
        if strike is not None
        else None
    )
    if current_premium is not None:
        st.metric("Current option premium", f"₹{current_premium:,.2f}")
    else:
        st.caption("Selected CE/PE premium abhi unavailable")
    default_target = float(round(current_premium, 2)) if current_premium is not None else 0.0
    target = st.number_input(
        "Target option premium ₹",
        min_value=0.0,
        value=default_target,
        step=0.50,
        key="manual_option_alert_target_input",
    )
    m1, m2, m3 = st.columns(3)
    trigger_mode = m1.selectbox(
        "Trigger",
        ("TOUCH", "ABOVE", "BELOW"),
        help="TOUCH target ke aas-paas; ABOVE/BELOW exact crossing.",
        key="manual_option_alert_mode_input",
    )
    tolerance = m2.number_input(
        "Near ₹",
        min_value=0.05,
        value=0.50,
        step=0.05,
        key="manual_option_alert_tolerance_input",
    )
    entry_no = m3.selectbox("Entry no.", (1, 2, 3), key="manual_option_alert_entry_no")
    arm_col, cancel_col = st.columns(2)
    arm_clicked = arm_col.button(
        "ARM ALERT",
        type="primary",
        width="stretch",
        disabled=current_premium is None or target <= 0 or strike is None,
        key="arm_manual_option_alert",
    )
    cancel_clicked = cancel_col.button(
        "CANCEL",
        width="stretch",
        disabled=not st.session_state.get("manual_option_alert_active", False),
        key="cancel_manual_option_alert",
    )
    if arm_clicked and current_premium is not None and strike is not None:
        security_id = _option_security_id(snapshot, option_side, float(strike))
        cloud_armed = False
        if live_server_url and live_server_api_key and security_id is not None:
            try:
                result = post_railway_json(
                    live_server_url,
                    live_server_api_key,
                    "/alerts/premium",
                    {
                        "security_id": security_id,
                        "side": option_side,
                        "position": position,
                        "strike": float(strike),
                        "expiry": str(snapshot.expiry or ""),
                        "target_premium": float(target),
                        "mode": trigger_mode,
                        "tolerance": float(tolerance),
                        "entry_no": int(entry_no),
                    },
                )
                st.session_state.manual_option_cloud_alert_id = result.get("id")
                cloud_armed = True
            except Exception as exc:
                st.error(f"Railway Telegram alert arm nahi hua: {exc}")
        st.session_state.manual_option_alert_active = True
        st.session_state.manual_option_alert_side = option_side
        st.session_state.manual_option_alert_position = position
        st.session_state.manual_option_alert_strike = float(strike)
        st.session_state.manual_option_alert_target = float(target)
        st.session_state.manual_option_alert_armed_premium = float(current_premium)
        st.session_state.manual_option_alert_expiry = str(snapshot.expiry or "")
        st.session_state.manual_option_alert_armed_at = datetime.now(
            ZoneInfo(IST_TIMEZONE)
        ).isoformat()
        st.success(
            f"{option_side} {position} alert ARMED · Strike {float(strike):,.0f} · "
            f"Target ₹{target:,.2f} · Current ₹{current_premium:,.2f} · "
            f"{'Railway + Telegram 24×7' if cloud_armed else 'Browser only'}"
        )
    if cancel_clicked:
        cloud_id = str(st.session_state.get("manual_option_cloud_alert_id", ""))
        if cloud_id and live_server_url and live_server_api_key:
            try:
                delete_railway_alert(live_server_url, live_server_api_key, cloud_id)
            except Exception as exc:
                st.warning(f"Railway cancel pending: {exc}")
        st.session_state.pop("manual_option_cloud_alert_id", None)
        st.session_state.manual_option_alert_active = False
        st.info("Manual CE/PE premium alert cancelled")

    if st.session_state.get("manual_option_alert_active", False):
        active_side = str(st.session_state.get("manual_option_alert_side", "CE"))
        active_position = str(st.session_state.get("manual_option_alert_position", "BUY"))
        active_strike = float(st.session_state.get("manual_option_alert_strike", 0.0))
        active_target = float(st.session_state.get("manual_option_alert_target", 0.0))
        live_premium = _option_premium(snapshot, active_side, active_strike)
        current_text = f"₹{live_premium:,.2f}" if live_premium is not None else "Unavailable"
        st.info(
            f"ACTIVE · {active_strike:,.0f} {active_side} {active_position} · "
            f"Target ₹{active_target:,.2f} · Current {current_text}"
        )
    last_manual = st.session_state.get("last_manual_option_alert")
    if isinstance(last_manual, dict):
        st.caption(
            f"Last: {float(last_manual.get('strike', 0)):,.0f} {last_manual.get('side')} "
            f"{last_manual.get('position')} · Target ₹{float(last_manual.get('target', 0)):,.2f} "
            f"reached at ₹{float(last_manual.get('premium', 0)):,.2f} · {last_manual.get('time')}"
        )

    # Browser fallback is one-shot. Railway premium monitor remains the durable
    # phone/Telegram path and does not depend on this panel staying open.
    if not arm_clicked and st.session_state.get("manual_option_alert_active", False):
        active_side = str(st.session_state.get("manual_option_alert_side", "CE"))
        active_position = str(st.session_state.get("manual_option_alert_position", "BUY"))
        active_strike = float(st.session_state.get("manual_option_alert_strike", 0.0))
        active_target = float(st.session_state.get("manual_option_alert_target", 0.0))
        armed_premium = float(st.session_state.get("manual_option_alert_armed_premium", 0.0))
        live_premium = _option_premium(snapshot, active_side, active_strike)
        if live_premium is not None and active_target > 0 and target_crossed(
            armed_spot=armed_premium, current_spot=live_premium, target=active_target
        ):
            now = datetime.now(ZoneInfo(IST_TIMEZONE))
            message = (
                f"{active_strike:,.0f} {active_side} {active_position} premium reached. "
                f"Current premium {live_premium:,.2f} rupees. Target {active_target:,.2f} rupees."
            )
            st.session_state.manual_option_alert_active = False
            st.session_state.last_manual_option_alert = {
                "side": active_side,
                "position": active_position,
                "strike": active_strike,
                "target": active_target,
                "premium": float(live_premium),
                "time": now.strftime("%H:%M:%S"),
            }
            st.toast(message, icon="🔔")
            if sound_enabled:
                _play_alert(message)
            else:
                st.warning(message + " Sound OFF tha.")

    cloud_count = int(st.session_state.get("manual_option_alert_cloud_active_count", 0) or 0)
    if cloud_count:
        st.caption(f"Railway durable premium alerts active: {cloud_count}")
    if st.session_state.get("manual_option_alert_cloud_sync_error"):
        st.caption("Railway alert-state sync pending; server-side alert monitor unaffected hai.")
    st.caption(
        "Phone/Telegram premium monitoring Railway par chalta hai. Browser sound ke liye tab open hona better hai."
    )

