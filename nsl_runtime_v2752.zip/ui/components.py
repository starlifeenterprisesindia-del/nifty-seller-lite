from __future__ import annotations

import json
import os
import re
from dataclasses import asdict
from html import escape
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

import pandas as pd
import streamlit as st
from config import CONFIG
from analysis.canonical_forecast import build_canonical_forecast, compatible_strategies
from analysis.entry_guidance import build_entry_guidance
from analysis.iv_delta_display import compute_iv_delta_payload

from analysis.evidence_matrix import build_compact_evidence_matrix, build_module_impact_audit
from analysis.presentation_safety import (
    market_rukh_display,
    normalized_news_display,
    safe_brain_hinglish_line,
    simple_core_block_coverage,
    future_brain_display_label,
)
from models import MarketLevel, MarketSnapshot
from services.summary_presenter import (
    best_existing_candidate,
    plan_leg_text,
    required_live_feed_state,
    snapshot_change_hinglish,
    snapshot_change_items,
    unified_direction_line,
)
from ui.presentation_helpers import (
    entry_metric_label,
    public_action_label,
    public_mode_enabled,
    ready_banner_label,
    smart_focus_tags,
    strategy_status_label,
)



def _effective_age_seconds(snapshot: MarketSnapshot, item: Any) -> float | None:
    """Age a frozen feed through the time spent building/rendering the snapshot.

    FeedStatus.age_seconds is measured while the snapshot is being assembled. If a
    build takes several seconds, showing only that frozen age can incorrectly label
    old-on-screen data as "10s fresh". This is display-only and never changes the
    One-Brain calculation.
    """
    base = getattr(item, "age_seconds", None)
    try:
        elapsed = max(0.0, (datetime.now(snapshot.created_at.tzinfo) - snapshot.created_at).total_seconds())
    except Exception:
        elapsed = 0.0
    if base is None:
        return elapsed if elapsed > 0 else None
    try:
        return max(0.0, float(base)) + elapsed
    except (TypeError, ValueError):
        return elapsed if elapsed > 0 else None

def _barrier_sources(level: Any | None) -> str:
    if level is None or not level.sources:
        return "Data unavailable"
    return " + ".join(str(item) for item in level.sources[:4])


def _pressure_label(score: float) -> str:
    if score <= 25:
        return "Bahut kam"
    if score <= 40:
        return "Kam"
    if score < 60:
        return "Barabar takkar"
    if score < 75:
        return "Zyada"
    return "Bahut zyada"


def _barrier_verdict(level: Any) -> str:
    side = str(level.side).upper()
    state = str(getattr(level, "state", "") or "").upper()
    if "AWAITING 3M CLOSE" in state:
        return "Break attempt — completed 3m close se confirm hoga"
    margin = float(level.strength) - float(level.break_pressure)
    if margin >= 15:
        return "Resistance filhaal majboot" if side == "RESISTANCE" else "Support filhaal majboot"
    if margin <= -8:
        return "Resistance toot sakta hai" if side == "RESISTANCE" else "Support toot sakta hai"
    return "Takkar barabar—WAIT"


def _barrier_state_hinglish(level: Any) -> str:
    state = str(level.state).upper()
    mapping = {
        "TESTING": "ABHI TEST HO RAHA",
        "ABOVE ZONE / AWAITING 3M CLOSE": "UPAR NIKLA — 3M CLOSE KA WAIT",
        "BELOW ZONE / AWAITING 3M CLOSE": "NEECHE NIKLA — 3M CLOSE KA WAIT",
        "HOLDING / STRONG": "LEVEL STRONG — REACTION DEKHO",
        "HOLDING": "LEVEL STRONG — REACTION DEKHO",
        "WEAKENING / BREAK RISK": "KAMZOR / TOOTNE KA RISK",
        "APPROACHING": "MARKET PAAS AA RAHA",
        "AHEAD": "AAGE KA LEVEL",
        "FAR": "ABHI DOOR",
    }
    return mapping.get(state, state)


def _barrier_level_html(
    level: Any | None, *, css_class: str, fallback_label: str, active_attack: bool = False
) -> str:
    if level is None:
        return (
            f'<div class="bm-level {css_class} muted">'
            f'<div class="bm-tag">{escape(fallback_label)}</div>'
            '<div class="bm-zone">Unresolved</div></div>'
        )
    raw_state = str(getattr(level, "state", "") or "").upper()
    state = escape(_barrier_state_hinglish(level))
    sources = escape(_barrier_sources(level))
    margin = float(level.break_pressure) - float(level.strength)
    confirmed_break = any(token in raw_state for token in ("BROKEN", "ROLE REVERSAL", "CONFIRMED BREAK"))
    attack_visual = bool(
        active_attack
        and float(level.break_pressure) >= CONFIG.visual_barrier_attack_pressure
        and margin >= CONFIG.visual_barrier_attack_margin
    )
    vulnerable = margin > 0
    visual_class = (
        " confirmed-break" if confirmed_break else
        " attack-break" if attack_visual else
        " vulnerable" if vulnerable else ""
    )
    strength_width = max(0.0, min(100.0, float(level.strength)))
    pressure_width = max(0.0, min(100.0, float(level.break_pressure)))
    confirmation = (
        f"{level.upper:,.0f} ke upar close"
        if str(level.side).upper() == "RESISTANCE"
        else f"{level.lower:,.0f} ke neeche close"
    )
    return (
        f'<div class="bm-level {css_class}{visual_class}">'
        f'<div class="bm-level-head"><span class="bm-tag">{escape(level.label)} · {escape(level.side.title())}</span>'
        f'<span class="bm-state">{state}</span></div>'
        f'<div class="bm-zone">{level.lower:,.0f}–{level.upper:,.0f}</div>'
        f'<div class="bm-bars">'
        f'<div><span>Level strength</span><b>{level.strength:.0f}/100</b><div class="bm-track"><div class="bm-fill" style="width:{strength_width:.0f}%"></div></div></div>'
        f'<div><span>Tootne ka pressure</span><b>{level.break_pressure:.0f}/100 · {escape(_pressure_label(float(level.break_pressure)))}</b><div class="bm-track"><div class="bm-fill pressure" style="width:{pressure_width:.0f}%"></div></div></div>'
        f'</div>'
        f'<div class="bm-verdict">Faisla: {escape(_barrier_verdict(level))}</div>'
        f'<div class="bm-small">Break watch: {confirmation}. History: completed 1m candles ka approx 3m reaction dekho.</div>'
        f'<div class="bm-small">{"Price zone ke andar hai" if level.distance_points == 0 else f"{level.distance_points:,.0f} pts door"} · Kyun: {sources}</div>'
        f'</div>'
    )


def render_compact_barrier_map(
    snapshot: MarketSnapshot,
    previous_snapshot: MarketSnapshot | None = None,
) -> None:
    item = snapshot.barrier_map

    def role_reversal_message() -> tuple[str, bool] | None:
        if previous_snapshot is None:
            return None
        previous = previous_snapshot.barrier_map
        candidates = tuple(
            (old, new, old_side, new_side)
            for old_side, old_levels, new_side, new_levels in (
                ("SUPPORT", (previous.nearest_support, previous.next_support), "RESISTANCE", (item.nearest_resistance, item.next_resistance)),
                ("RESISTANCE", (previous.nearest_resistance, previous.next_resistance), "SUPPORT", (item.nearest_support, item.next_support)),
            )
            for old in old_levels
            for new in new_levels
        )
        completed = snapshot.candles_1m.copy()
        if not completed.empty and "is_complete" in completed.columns:
            completed = completed[completed["is_complete"].fillna(False).astype(bool)]
        completed = completed.dropna(subset=["high", "low", "close"]).tail(12) if not completed.empty else completed
        for old, new, old_side, new_side in candidates:
            if old is None or new is None:
                continue
            lower = max(float(old.lower), float(new.lower))
            upper = min(float(old.upper), float(new.upper))
            if lower > upper:
                continue
            confirmed = False
            if new_side == "RESISTANCE":
                below_seen = False
                for _, candle in completed.iterrows():
                    close = float(candle["close"])
                    if close < lower:
                        if below_seen and float(candle["high"]) >= lower:
                            confirmed = True
                            break
                        below_seen = True
            else:
                above_seen = False
                for _, candle in completed.iterrows():
                    close = float(candle["close"])
                    if close > upper:
                        if above_seen and float(candle["low"]) <= upper:
                            confirmed = True
                            break
                        above_seen = True
            zone = f"{lower:,.0f}–{upper:,.0f}"
            if confirmed:
                return f"Confirmed Role Reversal: Broken {old_side.title()} → {new_side.title()} {zone}", True
            return f"Possible Role Reversal — Retest Pending: Broken {old_side.title()} → {new_side.title()} {zone}", False
        return None

    def pattern_level_text(
        signal: Any | None, fallback: str, *, show_possible_effect: bool = False
    ) -> tuple[str, str]:
        if signal is None or str(getattr(signal, "name", "")).upper() in {
            "",
            "NO VALID W/M",
            "NO IMPORTANT CANDLE",
        }:
            return fallback, "Abhi nearest level par valid signal nahi"
        name = str(signal.name)
        direction = str(getattr(signal, "direction", "NEUTRAL"))
        strength = str(getattr(signal, "strength", "NORMAL"))
        confidence = float(getattr(signal, "confidence", 0.0) or 0.0)
        level_value = getattr(signal, "level_value", None)
        level_label = str(getattr(signal, "level_label", "") or "Nearest level")
        level_text = (
            f"{level_label} {float(level_value):,.0f} ke paas"
            if level_value is not None
            else "Nearest level confirmation nahi"
        )
        stage = str(getattr(signal, "stage", "") or "")
        note = (
            f"{direction} · {strength} · Evidence quality {confidence:.0f}% · "
            f"{stage} · {level_text}"
        )
        if show_possible_effect:
            pattern_meaning = {
                "MORNING STAR": "Girawat ke baad upar palatne/bounce ka signal",
                "EVENING STAR": "Tezi ke baad neeche palatne ka signal",
                "BULL ENGULF": "Buyers ka zor; upar jaane ka signal",
                "BEAR ENGULF": "Sellers ka zor; neeche jaane ka signal",
                "HAMMER": "Neeche se recovery; upar bounce ka signal",
                "SHOOTING STAR": "Upar rejection; neeche pressure ka signal",
                "DOJI": "Buyer-seller barabar; direction clear nahi",
            }.get(name.upper())
            effect = (
                "Upar bounce/continuation"
                if direction.upper() == "BULLISH"
                else "Neeche rejection/pressure"
                if direction.upper() == "BEARISH"
                else "Indecision—level break ka wait"
            )
            if pattern_meaning:
                note += f" · Seedha matlab: {pattern_meaning}"
            note += (
                f" · Mumkin asar: {effect} · "
                f"Chance (signal evidence quality) {confidence:.0f}%"
            )
        return name, note

    def level_text(level: Any | None, fallback: str, *, side: str) -> tuple[str, str]:
        if level is None:
            spot_value = getattr(item, "current_price", None)
            remaining = getattr(item, "vix_expected_remaining_move_points", None)
            if spot_value is None:
                return "— · Data kam", "Fresh snapshot ka wait"
            step = max(25.0, float(remaining or 100.0) * 0.25)
            raw = float(spot_value) + step if side == "RESISTANCE" else float(spot_value) - step
            estimated = round(raw / 50.0) * 50.0
            return (
                f"Estimated zone {estimated:,.0f}",
                f"Agla pakka barrier nahi mila — Evidence quality kam. {fallback}",
            )
        return (
            f"{level.lower:,.0f}–{level.upper:,.0f}",
            f"Bachne ki taakat {level.strength:.0f} · Tootne ka pressure {level.break_pressure:.0f} ({_pressure_label(float(level.break_pressure))}) · {_barrier_verdict(level)}",
        )

    resistance, resistance_note = level_text(item.nearest_resistance, "Resistance unavailable", side="RESISTANCE")
    support, support_note = level_text(item.nearest_support, "Support unavailable", side="SUPPORT")
    overlap_text = None
    if item.nearest_resistance is not None and item.nearest_support is not None:
        overlap_lower = max(item.nearest_resistance.lower, item.nearest_support.lower)
        overlap_upper = min(item.nearest_resistance.upper, item.nearest_support.upper)
        if overlap_lower <= overlap_upper:
            overlap_text = f"{overlap_lower:,.0f}–{overlap_upper:,.0f}"
            resistance_note = "Compression/decision zone ka upper side · " + resistance_note
            support_note = "Compression/decision zone ka lower side · " + support_note
    spot = f"{item.current_price:,.2f}" if item.current_price is not None else "—"
    range_item = item.trading_range
    range_text = (
        f"{range_item.lower:,.0f}–{range_item.upper:,.0f}"
        if range_item.lower is not None and range_item.upper is not None
        else "Range unresolved"
    )
    patterns = getattr(snapshot, "patterns", None)
    wm_name, wm_note = pattern_level_text(
        getattr(patterns, "wm_3m", None), "NO VALID W/M"
    )
    main_candle = (
        getattr(patterns, "candle_3m", None)
    )
    candle_name, candle_note = pattern_level_text(
        main_candle,
        "NO IMPORTANT CANDLE",
        show_possible_effect=True,
    )

    def pattern_visual_class(signal: Any | None, base: str) -> str:
        if signal is None:
            return base
        direction = str(getattr(signal, "direction", "NEUTRAL") or "NEUTRAL").upper()
        strength = str(getattr(signal, "strength", "NORMAL") or "NORMAL").upper()
        stage = str(getattr(signal, "stage", "") or "").upper()
        confidence = float(getattr(signal, "confidence", 0.0) or 0.0)
        strong = strength in {"STRONG", "VERY STRONG"} or confidence >= 70.0
        pulse = strength == "VERY STRONG" or (strong and any(x in stage for x in ("CONFIRM", "BREAK", "VALID")))
        if direction == "BULLISH" and strong:
            return base + " bullish" + (" pulse" if pulse else "")
        if direction == "BEARISH" and strong:
            return base + " bearish" + (" pulse" if pulse else "")
        if direction == "NEUTRAL" and strong:
            return base + " neutral-strong"
        return base

    wm_class = pattern_visual_class(getattr(patterns, "wm_3m", None), "wm")
    candle_class = pattern_visual_class(main_candle, "candle")
    if candle_name != "NO IMPORTANT CANDLE":
        main_direction = str(getattr(main_candle, "direction", "NEUTRAL")).upper()

        def confirmation_text(signal: Any | None) -> str:
            name = str(getattr(signal, "name", "") or "").upper()
            direction = str(getattr(signal, "direction", "NEUTRAL") or "NEUTRAL").upper()
            if name in {"", "NO IMPORTANT CANDLE"}:
                return "NA"
            if main_direction not in {"BULLISH", "BEARISH"}:
                return direction
            if direction == main_direction:
                return "YES"
            if direction in {"BULLISH", "BEARISH"}:
                return "CONFLICT"
            return "NO"

        candle_note += (
            f" · 5M context {confirmation_text(getattr(patterns, 'candle_5m', None))}"
            f" · 15M confirm {confirmation_text(getattr(patterns, 'candle_15m', None))}"
        )

    st.subheader("🧭 Nearest Levels + Core Market Evidence")
    html = (
        '<style>'
        '.cbm-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin:4px 0 8px}'
        '.cbm{border-radius:13px;padding:12px;border:1px solid rgba(127,127,127,.24);background:rgba(127,127,127,.04)}'
        '.cbm.res{border-color:rgba(239,68,68,.42);background:rgba(239,68,68,.08)}'
        '.cbm.spot{border-color:rgba(59,130,246,.42);background:rgba(59,130,246,.08);text-align:center}'
        '.cbm.sup{border-color:rgba(34,197,94,.42);background:rgba(34,197,94,.08)}'
        '.cbm-l{font-size:.74rem;font-weight:800;opacity:.75;letter-spacing:.04em}'
        '.cbm-v{font-size:1.25rem;font-weight:900;margin-top:4px}'
        '.cbm-n{font-size:.72rem;opacity:.72;margin-top:4px;line-height:1.3}'
        '.cbm-patterns{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 8px}'
        '.cbm.pattern{padding:9px 11px}.cbm.pattern .cbm-v{font-size:1rem}'
        '@keyframes cbmPulse{0%,100%{box-shadow:none;transform:scale(1)}50%{box-shadow:0 0 18px rgba(255,255,255,.18);transform:scale(1.008)}}'
        '.cbm.wm{border-color:rgba(168,85,247,.38);background:rgba(168,85,247,.07)}'
        '.cbm.candle{border-color:rgba(245,158,11,.38);background:rgba(245,158,11,.07)}'
        '.cbm.pattern.bullish{border-color:rgba(34,197,94,.68);background:rgba(34,197,94,.14)}'
        '.cbm.pattern.bearish{border-color:rgba(239,68,68,.68);background:rgba(239,68,68,.14)}'
        '.cbm.pattern.neutral-strong{border-color:rgba(245,158,11,.68);background:rgba(245,158,11,.14)}'
        '.cbm.pattern.pulse{animation:cbmPulse .85s ease-in-out 4}'
        '@media(max-width:760px){.cbm-grid,.cbm-patterns{grid-template-columns:1fr}.cbm{padding:10px}.cbm-v{font-size:1.12rem}.cbm.pattern{padding:8px 10px}}'
        '</style>'
        '<div class="cbm-grid">'
        f'<div class="cbm res"><div class="cbm-l">AGLI RUKAWAT</div><div class="cbm-v">{escape(resistance)}</div><div class="cbm-n">{escape(resistance_note)}</div></div>'
        f'<div class="cbm spot"><div class="cbm-l">NIFTY ABHI</div><div class="cbm-v">{escape(spot)}</div><div class="cbm-n">Range {range_item.confidence:.0f}/100 · {escape(range_item.breakout_bias)} · Confirmation tak WAIT</div></div>'
        f'<div class="cbm sup"><div class="cbm-l">AGLA SAHARA</div><div class="cbm-v">{escape(support)}</div><div class="cbm-n">{escape(support_note)}</div></div>'
        '</div><div class="cbm-patterns">'
        f'<div class="cbm pattern {escape(wm_class)}"><div class="cbm-l">3-MINUTE W/M @ NEAREST LEVEL</div><div class="cbm-v">{escape(wm_name)}</div><div class="cbm-n">{escape(wm_note)}</div></div>'
        f'<div class="cbm pattern {escape(candle_class)}"><div class="cbm-l">3-MINUTE CANDLE @ NEAREST LEVEL</div><div class="cbm-v">{escape(candle_name)}</div><div class="cbm-n">{escape(candle_note)}</div></div>'
        '</div>'
    )
    if hasattr(st, "html"):
        st.html(html)
    else:
        st.markdown(html, unsafe_allow_html=True)
    if overlap_text:
        st.warning(
            f"Decision / Compression Zone: {overlap_text}. Is overlap ke andar support aur resistance alag signal nahi; "
            "clear 3-minute close ke baad hi break maana jayega."
        )
    reversal = role_reversal_message()
    if reversal is not None:
        message, confirmed = reversal
        if confirmed:
            st.success("🔄 **" + message + "**")
        else:
            st.warning("🔄 **" + message + "** · Retest ke bina confirmed barrier nahi.")
    st.caption(
        f"Probable range {range_text} · Confidence {range_item.confidence:.0f}/100 · "
        f"Speed {item.market_speed.state} {item.market_speed.score:.0f}/100. Full map detailed section me hai."
    )
    core = snapshot.core_evidence
    core_state = getattr(core, "market_state", getattr(core, "state", "UNRESOLVED"))
    core_range = float(getattr(core, "range_score", 0.0) or 0.0)
    bull = float(core.bullish_score or 0.0)
    bear = float(core.bearish_score or 0.0)
    bull_tone = ""
    bear_tone = ""
    if bull >= CONFIG.visual_evidence_strong_score and bull - bear >= CONFIG.visual_evidence_min_gap:
        bull_tone = "green"
        if bull >= CONFIG.visual_evidence_pulse_score and bull - bear >= CONFIG.visual_evidence_pulse_gap:
            bull_tone += " pulse"
    elif bear >= CONFIG.visual_evidence_strong_score and bear - bull >= CONFIG.visual_evidence_min_gap:
        bear_tone = "red"
        if bear >= CONFIG.visual_evidence_pulse_score and bear - bull >= CONFIG.visual_evidence_pulse_gap:
            bear_tone += " pulse"
    range_tone = "amber" if core_range >= CONFIG.visual_evidence_strong_score else ""
    _render_compact_cards(
        [
            ("Bullish Evidence", f"{bull:.1f}/100", "Upar ke completed-candle signals", bull_tone),
            ("Bearish Evidence", f"{bear:.1f}/100", "Neeche ke completed-candle signals", bear_tone),
            ("Range / Mixed", f"{core_range:.1f}/100", f"Core state {core_state}", range_tone),
            ("Core data coverage", f"{core.confidence:.1f}%", f"Status {core.status}; not win probability", ""),
        ]
    )
    st.info("🧠 **Barrier AI:** " + item.summary)
    with st.expander("Full R1/R2/S1/S2 barrier map", expanded=False):
        render_barrier_map(snapshot)


def render_barrier_map(snapshot: MarketSnapshot) -> None:
    item = snapshot.barrier_map
    st.subheader("🧭 " + ("Live Barrier + Range Map" if snapshot.market_session.is_live else "Last Available Barrier Map"))
    if not snapshot.market_session.is_live:
        st.caption("Neeche ke levels aur testing labels last snapshot ke hain, abhi ki live activity nahi.")
    st.caption("Level strong hona confirmed rejection nahi. Price zone tak aaye, phir completed candle reaction dekho.")
    st.caption(
        "Yeh top live road-map Support/Resistance, OI flow, price structure, volume, Top-9, "
        "market speed aur India VIX ko ek hi view me dikhata hai. Strength aur Break Pressure "
        "evidence scores hain — guaranteed probability nahi."
    )

    range_item = item.trading_range
    speed = item.market_speed
    range_text = (
        f"{range_item.lower:,.0f}–{range_item.upper:,.0f}"
        if range_item.lower is not None and range_item.upper is not None
        else "Unresolved"
    )
    remaining_move = (
        f"±{item.vix_expected_remaining_move_points:,.0f} pts"
        if item.vix_expected_remaining_move_points is not None
        else "—"
    )
    st.caption(
        f"Detail map: Range {range_text} | Confidence {range_item.confidence:.0f}/100 | "
        f"Speed {speed.state} {speed.score:.0f}/100 {speed.direction} | VIX remaining move {remaining_move}."
    )

    if speed.state == "DANGER":
        st.error(
            f"🚨 FAST MARKET DANGER — speed {speed.score:.0f}/100 ({speed.direction}). "
            "Fresh option selling me extra caution; barrier break fast ho sakta hai."
        )
    elif speed.state == "FAST":
        st.warning(
            f"⚡ Market FAST hai — speed {speed.score:.0f}/100 ({speed.direction}). "
            "Nearest barrier ki Break Pressure ko priority se dekho."
        )

    mie = (snapshot.metadata.get("market_intelligence") or {}) if isinstance(snapshot.metadata, dict) else {}
    integrity = mie.get("pressure_integrity") or {}
    integrity_direction = str(integrity.get("direction") or "").upper() if isinstance(integrity, dict) else ""
    attack_state = str(integrity.get("move_attack_state") or "").upper() if isinstance(integrity, dict) else ""
    attack_active = attack_state in {"ATTACK", "BREAK / EXPANSION", "BREAK/EXPANSION"}
    r2 = _barrier_level_html(item.next_resistance, css_class="res secondary", fallback_label="R2")
    r1 = _barrier_level_html(
        item.nearest_resistance, css_class="res primary", fallback_label="R1",
        active_attack=attack_active and integrity_direction == "BULLISH",
    )
    s1 = _barrier_level_html(
        item.nearest_support, css_class="sup primary", fallback_label="S1",
        active_attack=attack_active and integrity_direction == "BEARISH",
    )
    s2 = _barrier_level_html(item.next_support, css_class="sup secondary", fallback_label="S2")
    spot = f"{item.current_price:,.2f}" if item.current_price is not None else "—"
    range_state = escape(range_item.state)
    bias = escape(range_item.breakout_bias)
    range_pos = f"{range_item.position_pct:.0f}%" if range_item.position_pct is not None else "—"
    vix_daily = f"±{item.vix_expected_daily_move_points:,.0f} pts" if item.vix_expected_daily_move_points is not None else "—"
    vix_5 = f"{speed.vix_change_5m_pct:+.1f}%" if speed.vix_change_5m_pct is not None else "warming"
    vix_15 = f"{speed.vix_change_15m_pct:+.1f}%" if speed.vix_change_15m_pct is not None else "warming"
    volume_text = f"{speed.volume_ratio:.2f}x" if speed.volume_ratio is not None else "warming"

    barrier_html = (
        '<style>'
        '.bm-wrap{border:1px solid rgba(128,128,128,.25);border-radius:16px;padding:14px;background:rgba(127,127,127,.035);margin:6px 0 10px}'
        '.bm-level{border-radius:12px;padding:10px 12px;margin:7px 0;border-left:6px solid}'
        '.bm-level.res{border-left-color:#d9534f;background:rgba(217,83,79,.08)}'
        '.bm-level.sup{border-left-color:#2e9d63;background:rgba(46,157,99,.08)}'
        '.bm-level.secondary{opacity:.84}'
        '@keyframes barrierPulse{0%,100%{box-shadow:0 0 0 1px rgba(127,127,127,.10) inset}50%{box-shadow:0 0 0 3px rgba(245,158,11,.20),0 0 22px rgba(245,158,11,.24)}}'
        '.bm-level.primary{box-shadow:0 0 0 1px rgba(127,127,127,.10) inset}'
        '.bm-level.vulnerable{border-color:rgba(245,158,11,.7);background:rgba(245,158,11,.12)}'
        '.bm-level.attack-break{border-color:#f59e0b;background:rgba(245,158,11,.18);animation:barrierPulse .8s ease-in-out 5}'
        '.bm-level.confirmed-break{border-color:#60a5fa;background:rgba(96,165,250,.16);box-shadow:0 0 0 2px rgba(96,165,250,.22) inset}'
        '.bm-level.muted{opacity:.55}'
        '.bm-level-head{display:flex;justify-content:space-between;gap:12px;align-items:center}'
        '.bm-tag{font-size:.78rem;font-weight:800;letter-spacing:.04em;text-transform:uppercase}'
        '.bm-state{font-size:.75rem;font-weight:700;opacity:.8}'
        '.bm-zone{font-size:1.45rem;font-weight:800;line-height:1.2;margin:3px 0 7px}'
        '.bm-bars{display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:.78rem}'
        '.bm-bars>div>span{opacity:.75;margin-right:6px}'
        '.bm-bars b{float:right}'
        '.bm-verdict{font-size:.86rem;font-weight:800;margin-top:8px}'
        '.bm-track{height:6px;border-radius:99px;background:rgba(127,127,127,.18);overflow:hidden;margin-top:4px}'
        '.bm-fill{height:100%;background:#6b7280;border-radius:99px}'
        '.bm-fill.pressure{background:#f59e0b}'
        '.bm-small{font-size:.78rem;opacity:.78;margin-top:7px}'
        '.bm-spot{margin:10px 0;padding:13px;border-radius:12px;text-align:center;border:2px solid rgba(80,130,255,.45);background:rgba(80,130,255,.08)}'
        '.bm-spot .price{font-size:1.55rem;font-weight:900}'
        '.bm-road{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:8px;font-size:.82rem}'
        '.bm-road>div{padding:8px;border-radius:9px;background:rgba(127,127,127,.07)}'
        '@media (max-width:900px){.bm-bars,.bm-road{grid-template-columns:1fr}}'
        '</style>'
        '<div class="bm-wrap">'
        + r2 + r1
        + f'<div class="bm-spot"><div>NIFTY CURRENT</div><div class="price">{spot}</div>'
          f'<div>{range_state} · Position {range_pos} · Break Bias {bias}</div></div>'
        + s1 + s2
        + '<div class="bm-road">'
          f'<div><b>India VIX Risk</b><br>{escape(item.vix_risk)} · Daily move {vix_daily}</div>'
          f'<div><b>VIX Speed</b><br>5m {vix_5} · 15m {vix_15}</div>'
          f'<div><b>Option Shock</b><br>{speed.option_shock_score:.0f}/100 · Volume {volume_text}</div>'
          '</div></div>'
    )
    # st.html is the correct Streamlit primitive for raw HTML/CSS. Using st.markdown
    # can make indented nested HTML appear as literal code on some deployments/themes.
    if hasattr(st, "html"):
        st.html(barrier_html)
    else:
        st.markdown(barrier_html, unsafe_allow_html=True)

    st.info("🧠 **Barrier Brain:** " + item.summary)
    if range_item.explanation:
        st.caption(range_item.explanation)
    if speed.reasons:
        st.caption("Speed reasons: " + " | ".join(speed.reasons))


def render_compact_status_bar(snapshot: MarketSnapshot) -> None:
    """One top status line instead of duplicate session and health banners."""
    statuses = snapshot.feed_status or {}
    critical = [statuses.get(key) for key in ("quotes", "candles", "option_chain")]
    critical = [item for item in critical if item is not None]
    bad = [item for item in critical if not item.ok or item.use_state not in {"LIVE", "REFERENCE"}]
    ages = [age for item in critical if (age := _effective_age_seconds(snapshot, item)) is not None]
    age = f" · max age {max(ages):.0f}s" if ages else ""
    progression = statuses.get("price_progression")
    late_reference = bool(
        snapshot.market_session.is_live
        and progression is not None
        and getattr(progression, "use_state", "") == "REFERENCE"
    )
    if snapshot.market_session.is_live and not bad and late_reference:
        st.info(f"🟢 OPTIONS/FUTURES LIVE · NIFTY SPOT LATE-SESSION REFERENCE{age} · One-Brain safety rules active")
    elif snapshot.market_session.is_live and not bad:
        st.success(f"🟢 MARKET OPEN · DATA FRESH{age} · One-Brain live")
    elif snapshot.market_session.is_live:
        st.warning("🟡 MARKET OPEN · CHECK DATA: " + ", ".join(item.name for item in bad))
    else:
        st.warning("🟡 MARKET CLOSED · LAST DATA · reference only")
    if progression is not None and not progression.ok and getattr(progression, "use_state", "") != "REFERENCE":
        st.error(f"SOURCE FLATLINE · {progression.message} · entry blocked")


def render_greeks_health(frame: pd.DataFrame) -> None:
    """Contract-specific diagnostics; never changes the snapshot or AI votes."""
    if "greeks_quality" not in frame:
        return
    invalid = ~frame.greeks_quality.isin(["READY", "IV WARNING"])
    conditional = frame.greeks_quality.eq("IV WARNING")
    if not (invalid.any() or conditional.any()):
        return
    st.caption(f"Greeks: {int(invalid.sum())} contracts unavailable · {int(conditional.sum())} conditional. Detail neeche; market direction ka alag check hai.")
    with st.expander("Strike-wise Greeks checks", expanded=False):
        st.write("Sirf affected strike/hedge par restriction hai. Valid Price Action, RSI, OI aur Top-9 analysis chalta rahega. Suitable safe strike na mile to trade WAIT reh sakta hai.")
        if invalid.any():
            st.warning("Invalid/missing Greeks: in contracts ki Greek-based ranking aur future premium estimate band. Live quote/OI alag usable hain.")
        if conditional.any():
            st.info("CE/PE IV difference: source values retained. Candidate conditional; automatic retest premium disabled. Manual calculator sirf labelled scenario deta hai, exact entry/SL nahi.")
        columns = [name for name in ("expiry", "strike", "side", "source_implied_volatility", "source_delta", "source_gamma", "source_theta", "source_vega", "iv_pair_ratio", "delta_pair_gap", "greeks_quality", "greeks_reason") if name in frame]
        st.dataframe(frame.loc[invalid | conditional, columns], hide_index=True, width="stretch")


def compact_evidence_note(snapshot: MarketSnapshot, row: dict[str, Any]) -> str:
    """Display-only context; breadth counts never come from evidence scores."""
    if row["Module"] == "NIFTY Top-9":
        from math import isfinite
        values = [getattr(item, "change_15m_pct", None)
                  for item in snapshot.heavyweights.rows]
        values = [float(value) for value in values
                  if value is not None and isfinite(float(value))]
        if not values:
            return "15m: warming / data missing"
        up = sum(value > 0.03 for value in values)
        down = sum(value < -0.03 for value in values)
        note = f"15m: {up} Up · {down} Down · {len(values) - up - down} Flat"
        missing = len(snapshot.heavyweights.rows) - len(values)
        if missing:
            note += f" · {missing} pending"
        return note
    if row["Module"] in {"3M W/M Pattern", "Special Candle", "Big Player Activity"}:
        note = str(row.get("Result") or "—").split(" · ")[0]
        return note if len(note) <= 60 else note[:57] + "…"
    return "—"


def render_evidence_matrix(
    snapshot: MarketSnapshot,
    previous_snapshot: MarketSnapshot | None = None,
) -> None:
    st.subheader("All Features — Compact Evidence")
    st.caption(
        "Diagnostic evidence view — final Simple One-Brain ka operational weight sirf: "
        "Trend 40% · Options 25% · Participation 20% · Barrier/Entry 15%. "
        "Neeche ke 11 rows raw/background evidence samjhane ke liye hain; inko dobara add karke second brain nahi banta."
    )
    rows = build_compact_evidence_matrix(snapshot, previous_snapshot)
    previous_rows = (
        build_compact_evidence_matrix(previous_snapshot)
        if previous_snapshot is not None
        else []
    )
    previous_by_module = {str(row["Module"]): row for row in previous_rows}
    reference_name, impact_by_module = build_module_impact_audit(snapshot, rows)
    previous_impact_by_module = (
        build_module_impact_audit(previous_snapshot, previous_rows)[1]
        if previous_snapshot is not None
        else {}
    )
    impact_history_path = Path("data/last_one_brain_impact.json")
    if previous_snapshot is None:
        try:
            saved = json.loads(impact_history_path.read_text(encoding="utf-8"))
            if (
                str(saved.get("snapshot_id") or "") != str(snapshot.snapshot_id)
                and str(saved.get("date") or "") == snapshot.created_at.date().isoformat()
                and isinstance(saved.get("impacts"), dict)
            ):
                previous_impact_by_module = {
                    str(key): str(value)
                    for key, value in saved["impacts"].items()
                }
        except (OSError, ValueError, TypeError):
            pass
    try:
        impact_history_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = impact_history_path.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(
                {
                    "snapshot_id": snapshot.snapshot_id,
                    "date": snapshot.created_at.date().isoformat(),
                    "created_at": snapshot.created_at.isoformat(),
                    "impacts": impact_by_module,
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        os.replace(temporary, impact_history_path)
    except OSError:
        pass

    impact_pattern = re.compile(
        r"Abhi\s+([0-9]+(?:\.[0-9]+)?)\s+pts\s+(Bull|Bear|Range)",
        re.IGNORECASE,
    )
    risk_pattern = re.compile(
        r"(?:Asar\s+([+-]?\d+)/9|Risk\s+(\d+)/(?:9|12))",
        re.IGNORECASE,
    )

    def impact_with_last(module: str, current_text: str) -> str:
        """Append a compact, truthful last-snapshot contribution comparison."""

        current_match = impact_pattern.search(current_text)
        if current_match is None:
            current_risk = risk_pattern.search(current_text)
            if current_risk is None:
                return current_text
            current_value = float(current_risk.group(1) or current_risk.group(2))
            if not previous_impact_by_module:
                return f"{current_text} · Last: pehla snapshot"
            previous_text = previous_impact_by_module.get(module, "")
            previous_risk = risk_pattern.search(previous_text)
            if previous_risk is None:
                return f"{current_text} · Last NA"
            previous_value = float(previous_risk.group(1) or previous_risk.group(2))
            delta = current_value - previous_value
            arrow = "↑" if delta > 0.05 else "↓" if delta < -0.05 else "→"
            return f"{current_text} · Last {previous_value:+.0f} · Δ {delta:+.0f}{arrow}"
        if not previous_impact_by_module:
            return f"{current_text} · Last: pehla snapshot"
        previous_text = previous_impact_by_module.get(module, "")
        previous_match = impact_pattern.search(previous_text)
        if previous_match is None:
            return f"{current_text} · Last NA"
        current_points = float(current_match.group(1))
        previous_points = float(previous_match.group(1))
        current_direction = current_match.group(2).title()
        previous_direction = previous_match.group(2).title()
        if current_direction != previous_direction:
            return (
                f"{current_text} · Last {previous_points:.1f} {previous_direction}"
                f" → {current_direction}"
            )
        delta = current_points - previous_points
        arrow = "↑" if delta > 0.05 else "↓" if delta < -0.05 else "→"
        return f"{current_text} · Last {previous_points:.1f} · Δ {delta:+.1f}{arrow}"

    def score_text(value: Any, short: str) -> str:
        return f"{short}{float(value):.0f}" if value is not None else f"{short}—"

    def score_cell(value: Any, tone: str) -> str:
        if value is None:
            return "—"
        numeric = max(0.0, min(100.0, float(value)))
        return (
            f'<div class="evt-score {tone}"><i style="width:{numeric:.0f}%"></i>'
            f'<span>{numeric:.0f}%</span></div>'
        )

    def change_text(row: dict[str, Any]) -> str:
        previous = previous_by_module.get(str(row["Module"]))
        if previous is None:
            return "Pehla snapshot"
        deltas = []
        for key, short in (
            ("Bullish %", "Bull"),
            ("Bearish %", "Bear"),
            ("Neutral %", "Neutral"),
        ):
            current_value = row.get(key)
            previous_value = previous.get(key)
            if current_value is not None and previous_value is not None:
                deltas.append(f"{short}{float(current_value) - float(previous_value):+.0f}")
        if str(row["Module"]) == "NIFTY Top-9":
            current_move = snapshot.heavyweights.weighted_move_pct
            previous_move = previous_snapshot.heavyweights.weighted_move_pct
            if current_move is not None and previous_move is not None:
                elapsed = max(0, round((snapshot.created_at - previous_snapshot.created_at).total_seconds() / 60))
                return f"{elapsed}m {current_move - previous_move:+.3f}%"
        if deltas and any(item[-2:] not in {"+0", "-0"} for item in deltas):
            return "Δ " + " ".join(deltas)
        return "Koi badlav nahi" if row.get("Result") == previous.get("Result") else "Result badla"

    body = []
    detail_rows: list[dict[str, str]] = []
    for row in rows:
        module = str(row["Module"])
        top9_feed = snapshot.feed_status.get("heavyweights") if module == "NIFTY Top-9" else None
        top9_no_vote = bool(top9_feed is not None and getattr(top9_feed, "use_state", "") != "LIVE")
        confidence = (
            "NO VOTE"
            if top9_no_vote
            else f"{float(row['Confidence %']):.0f}%"
            if row.get("Confidence %") is not None
            else "—"
        )
        change = change_text(row)
        impact = impact_with_last(
            module, impact_by_module.get(module, "—")
        )
        detail_rows.append(
            {
                "Module": module,
                "One-Brain weight/asar": impact,
                "Result": str(row.get("Result") or "—"),
                "Badlav": change,
            }
        )
        bull_cell = "—" if top9_no_vote else score_text(row.get("Bullish %"), "")
        bear_cell = "—" if top9_no_vote else score_text(row.get("Bearish %"), "")
        neutral_cell = "—" if top9_no_vote else score_text(row.get("Neutral %"), "")
        note_text = (
            f"{getattr(top9_feed, 'use_state', 'REFERENCE')} · {getattr(top9_feed, 'message', 'stale Top-9; no live vote')}"
            if top9_no_vote
            else compact_evidence_note(snapshot, row)
        )
        body.append(
            '<tr>'
            f'<td class="evt-module">{escape(str(row["Module"]))}</td>'
            f'<td class="evt-bull">{bull_cell}</td>'
            f'<td class="evt-bear">{bear_cell}</td>'
            f'<td class="evt-neutral">{neutral_cell}</td>'
            f'<td class="evt-conf">{confidence}</td>'
            f'<td class="evt-note">{escape(note_text)}</td>'
            '</tr>'
        )
    table_html = (
        '<style>'
        '.evt-wrap{overflow-x:auto;border:1px solid rgba(127,127,127,.24);border-radius:10px}'
        '.evt{width:100%;border-collapse:collapse;table-layout:fixed;font-size:.82rem}'
        '.evt th,.evt td{padding:8px;border-bottom:1px solid rgba(127,127,127,.20);text-align:left;vertical-align:middle;overflow-wrap:anywhere}'
        '.evt th{background:rgba(127,127,127,.09);font-weight:800}'
        '.evt tr:last-child td{border-bottom:0}'
        '.evt-module{font-weight:800}.evt-bull,.evt-bear,.evt-neutral{text-align:center}.evt-conf{text-align:center}'
        '.evt-bull{color:#22c55e}.evt-bear{color:#ef4444}.evt-neutral{color:#a3a3a3}'
        '.evt{min-width:560px}'
        '@media(max-width:760px){'
        '.evt{font-size:.68rem}.evt th,.evt td{padding:7px 3px}'
        '}'
        '</style><div class="evt-wrap"><table class="evt">'
        '<colgroup><col style="width:25%"><col style="width:8%"><col style="width:8%"><col style="width:10%"><col style="width:16%"><col style="width:33%"></colgroup><thead><tr>'
        '<th>Module</th><th class="evt-bull">Bull</th><th class="evt-bear">Bear</th><th class="evt-neutral">Neutral</th><th>Evidence quality</th><th>Short note</th>'
        '</tr></thead><tbody>' + ''.join(body) + '</tbody></table></div>'
    )
    st.html(table_html) if hasattr(st, "html") else st.markdown(
        table_html, unsafe_allow_html=True
    )
    with st.expander("Weights, result aur last snapshot ka badlav", expanded=False):
        st.dataframe(pd.DataFrame(detail_rows), width="stretch", hide_index=True)
        st.caption(
            f"Current reference: {reference_name}. Unified One-Brain: "
            "15m+3m+indicators 40%, OI 15%, futures volume 10%, "
            "raw Futures+Top-9 activity 10%, barrier room 15%, special candle/W-M 10%. "
            "Composite Big Player ka extra direction vote 0."
        )
        actual = getattr(snapshot.decision, "score_audit", {}).get(reference_name, {})
        if actual:
            st.write(f"Actual AI calculation — {reference_name}")
            st.dataframe(pd.DataFrame([{"Calculation": key, "Points": round(value, 2)}
                                      for key, value in actual.items()]), hide_index=True, width="stretch")
            st.caption("Base + net adjustments = final fit. Net includes level/risk adjustments, caps and rounding. Evidence quality is separate, not multiplied again. Fit is not profit probability.")



def _level_summary(level: Any | None, *, fallback: str) -> str:
    if level is None:
        return f"{fallback}: unresolved"
    return (
        f"{level.lower:,.0f}–{level.upper:,.0f} | Bachne ki taakat {level.strength:.0f}/100 | "
        f"Tootne ka pressure {level.break_pressure:.0f}/100 | {_barrier_verdict(level)}"
    )


def _compact_cards_html(cards: list[tuple[str, str, str] | tuple[str, str, str, str]]) -> str:
    """Render responsive cards with optional display-only emphasis classes."""

    blocks = []
    for card in cards:
        label, value, note = card[:3]
        tone = card[3] if len(card) > 3 else ""
        blocks.append(
            f'<div class="mai-card {escape(str(tone))}">'
            f'<div class="mai-label">{escape(label)}</div>'
            f'<div class="mai-value">{escape(value)}</div>'
            f'<div class="mai-note">{escape(note)}</div>'
            '</div>'
        )
    return (
        '<style>'
        '@keyframes maiPulse{0%,100%{transform:scale(1);box-shadow:none}50%{transform:scale(1.012);box-shadow:0 0 0 3px rgba(255,255,255,.10),0 0 18px rgba(255,255,255,.12)}}'
        '.mai-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:4px 0 12px}'
        '.mai-card{min-width:0;border:1px solid rgba(127,127,127,.24);border-radius:12px;padding:10px 11px;background:rgba(127,127,127,.045)}'
        '.mai-card.green{border-color:rgba(34,197,94,.58);background:rgba(34,197,94,.12)}'
        '.mai-card.red{border-color:rgba(239,68,68,.58);background:rgba(239,68,68,.12)}'
        '.mai-card.amber{border-color:rgba(245,158,11,.58);background:rgba(245,158,11,.12)}'
        '.mai-card.pulse{animation:maiPulse .85s ease-in-out 4}'
        '.mai-label{font-size:.76rem;opacity:.72;margin-bottom:4px}'
        '.mai-value{font-size:1.18rem;font-weight:800;line-height:1.15;overflow-wrap:anywhere}'
        '.mai-note{font-size:.70rem;opacity:.68;margin-top:4px;line-height:1.25}'
        '@media (max-width:760px){.mai-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.mai-value{font-size:1.03rem}.mai-card{padding:9px}}'
        '</style><div class="mai-grid">' + ''.join(blocks) + '</div>'
    )


def _render_compact_cards(cards: list[tuple[str, str, str] | tuple[str, str, str, str]]) -> None:
    html = _compact_cards_html(cards)
    if hasattr(st, "html"):
        st.html(html)
    else:
        st.markdown(html, unsafe_allow_html=True)


def _plan_structure_text(plan: Any | None) -> str:
    if plan is None or not plan.available:
        return "Strike unresolved"
    if plan.is_buy:
        hedge = (
            f" · HEDGE SELL {plan_leg_text(plan.short_legs)}"
            if plan.short_legs
            else ""
        )
        return f"BUY {plan_leg_text(plan.long_legs)}{hedge}"
    short_text = plan_leg_text(plan.short_legs)
    hedge_text = plan_leg_text(plan.hedge_legs)
    return f"SELL {short_text} · HEDGE {hedge_text}"


def _render_pair_comparison(plan_map):
    with st.expander("Strike + hedge comparison — top protected pairs", expanded=False):
        st.caption("Pair score suitability hai, win probability nahi. Credit/loss per unit; rupees ke liye quantity se multiply. Expiry scenarios intraday estimates nahi.")
        for pair_name in ("CE SELL", "PE SELL"):
            pair_plan = plan_map.get(pair_name)
            if pair_plan and getattr(pair_plan, "pair_comparison", ()):
                st.write(pair_name)
                st.dataframe(list(pair_plan.pair_comparison), hide_index=True, width="stretch")


def render_protected_candidates(snapshot: MarketSnapshot) -> None:
    """Show protected strategy alternatives under the Simple One-Brain direction."""

    evaluations = _decision_evaluations(snapshot)
    bundle = snapshot.trade_plan
    plan_map = {
        "CE BUY": bundle.ce_buy,
        "PE BUY": bundle.pe_buy,
        "CE SELL": bundle.ce_sell,
        "PE SELL": bundle.pe_sell,
        "IRON CONDOR": bundle.iron_condor,
    }
    common = getattr(snapshot, "metadata", {}).get("common_decision") or {}
    selected = str(common.get("final_action") or "WAIT")
    leader = str(common.get("best_strategy") or "WAIT")
    simple = getattr(snapshot, "metadata", {}).get("simple_brain") or {}
    simple_direction = str(simple.get("direction") or common.get("direction") or "MIXED")
    allowed = compatible_strategies(simple_direction)
    if leader not in evaluations:
        eligible = [name for name in evaluations if name in allowed]
        leader = max(eligible or list(evaluations), key=lambda name: evaluations[name].score)

    st.subheader("🛡️ Strategy + Strike Value Table")
    st.caption(
        "Simple One-Brain direction ke compatible protected CE/PE/Condor setups. "
        "Main decision Regime → Direction → Entry → Risk se aata hai; Future Brain advisory only hai."
    )

    def _premium_value(plan: Any | None) -> tuple[str, str]:
        if plan is None or not plan.available:
            return "—", "UNAVAILABLE"
        if plan.is_buy:
            points = float(plan.estimated_debit_points or 0.0)
            premium = f"Debit {points:.2f} pts"
        else:
            points = float(plan.estimated_credit_points or 0.0)
            premium = f"Credit {points:.2f} pts"

        # Display-only value grade. The trade planner already selects strikes by
        # delta, liquidity, distance, spread and hedge efficiency; this grade does
        # not create a second strategy brain or promise a profit.
        quality = float(plan.quality_score or 0.0)
        if quality >= 75 and points >= 5:
            grade = "ACCHI VALUE"
        elif quality >= 58 and points >= 2:
            grade = "THEEK VALUE"
        else:
            grade = "KAMZOR VALUE"
        return premium, grade

    rows: list[dict[str, Any]] = []
    ranked = [name for name in common.get("ranked_strategies", ()) if name in evaluations]
    if not ranked:
        ranked = sorted(evaluations, key=lambda name: evaluations[name].score, reverse=True)
    for rank, name in enumerate(ranked, start=1):
        strategy = evaluations[name]
        plan = plan_map[name]
        premium, value_grade = _premium_value(plan)
        if not snapshot.market_session.is_live:
            status = "REFERENCE ONLY"
        elif common.get("entry_allowed") and name == selected:
            status = "TOP COMPATIBLE • ENTRY READY" if plan.available else "TOP COMPATIBLE • STRIKE BLOCKED"
        elif allowed and name not in allowed:
            status = "DIRECTION BLOCKED"
        elif not common.get("entry_allowed") and name == leader:
            status = "TOP COMPATIBLE • WAIT"
        elif not plan.available:
            status = "BLOCKED"
        else:
            status = "ALTERNATIVE"
        decay_reasons = [reason for reason in plan.reasons if reason.startswith("Theta edge")]
        decay_edge = " | ".join(decay_reasons) if decay_reasons else "Theta check —"
        rows.append(
            {
                "Rank": rank,
                "Strategy": public_action_label(name),
                "Brain Fit": f"{strategy.score:.0f}%",
                "Strike + Hedge": _plan_structure_text(plan),
                "Premium": premium,
                "Status": strategy_status_label(status),
            }
        )
    frame = pd.DataFrame(rows)

    def _strategy_style(row: pd.Series) -> list[str]:
        if str(row["Status"]).startswith("TOP COMPATIBLE"):
            return ["background-color: rgba(59,130,246,.18);font-weight:700"] * len(row)
        if row["Status"] in {"BLOCKED", "DIRECTION BLOCKED"}:
            return ["background-color: rgba(239,68,68,.08)"] * len(row)
        return [""] * len(row)

    styled = frame.style.apply(_strategy_style, axis=1)
    st.dataframe(styled, width="stretch", hide_index=True, row_height=42)
    best_plan = plan_map.get(leader)
    common_entry = common.get("entry") or {}
    guidance = build_entry_guidance(best_plan, entry_ready=bool(common.get("entry_allowed")), live=snapshot.market_session.is_live)
    with st.container(border=True):
        if public_mode_enabled():
            label = "CONDITIONS MET" if common.get("entry_allowed") else "CANDIDATE ONLY — CONDITIONS PENDING"
        else:
            label = "ENTRY" if common.get("entry_allowed") else "CANDIDATE ONLY — ENTRY GATE CLOSED"
        st.markdown(f"**Top compatible {label} — {public_action_label(leader)}: {guidance.status}**")
        c1, c2, c3 = st.columns(3)
        c1.metric("Current package", common_entry.get("current", guidance.current))
        c2.metric("Preferred limit zone", common_entry.get("preferred_zone", guidance.preferred_zone))
        c3.metric("Do-not-cross", common_entry.get("minimum", guidance.minimum))
        st.caption(common_entry.get("instruction", guidance.instruction))
    with st.expander("Advanced strike quality / pair comparison", expanded=False):
        details = []
        for name in ranked:
            plan = plan_map[name]
            premium, value_grade = _premium_value(plan)
            details.append({"Strategy": name, "Premium": premium, "Decay": " | ".join([r for r in plan.reasons if r.startswith('Theta edge')]) or "—", "Strike/Pair Quality": f"{value_grade} · {plan.quality_score:.0f}/100"})
        st.dataframe(details, width="stretch", hide_index=True)
        _render_pair_comparison(plan_map)
    if not snapshot.market_session.is_live:
        st.info("Market live nahi hai—strategy fits sirf frozen reference hain, fresh advice nahi.")
    elif not common.get("entry_allowed"):
        st.info(
            "Simple One-Brain entry abhi WAIT/CONFIRM hai—table protected alternatives sirf reference hain."
        )
    st.caption(
        "Decay Edge me SELL ka absolute theta hedge se zyada hona better hai. "
        "Value Quality liquidity + premium + hedge quality par based hai; IV WARNING me Greeks ka ranking weight automatically kam hota hai. "
        "KAMZOR VALUE setup ko sirf reference samjho; order app kabhi khud place nahi karti."
    )


def _wait_display_stage(simple: dict[str, Any], common_action: str = "WAIT") -> str:
    """Presentation-only WAIT progression; canonical action remains unchanged."""
    if str(common_action or "WAIT").upper() != "WAIT":
        return str(common_action or "WAIT")
    state = str((simple or {}).get("entry_state") or "WAIT").upper()
    if "DATA" in state:
        return "DATA WAIT"
    if "READY" in state or "BREAK TRIGGER" in state or "TRIGGER PENDING" in state:
        return "ARMED · WAIT"
    if "BREAK" in state or "PULLBACK" in state or "WATCH" in state or "BUILD" in state:
        return "WATCH · WAIT"
    if "NO CLEAR" in state or "NO EDGE" in state:
        return "NO EDGE · WAIT"
    return "WAIT"


def _render_final_action_hero(snapshot: MarketSnapshot, feed_ok: bool) -> None:
    decision = snapshot.decision
    common = getattr(snapshot, "metadata", {}).get("common_decision") or {}
    name, score, plan, is_selected = best_existing_candidate(snapshot)
    direction, direction_score, direction_note = market_rukh_display(snapshot)
    direction_text = {
        "UP": "Market upar ja sakta hai",
        "DOWN": "Market neeche ja sakta hai",
        "MIXED": "Market abhi mixed hai",
        "RANGE": "Market range me reh sakta hai",
    }.get(direction, f"Market direction {direction}")
    entry_ready = bool(common.get("entry_allowed"))
    common_action = str(common.get("final_action") or "WAIT")
    simple = getattr(snapshot, "metadata", {}).get("simple_brain") or {}
    display_wait_stage = _wait_display_stage(simple, common_action)
    bundle = getattr(snapshot, "trade_plan", None)
    plan_map = ({"CE BUY": bundle.ce_buy, "PE BUY": bundle.pe_buy,
                 "CE SELL": bundle.ce_sell, "PE SELL": bundle.pe_sell,
                 "IRON CONDOR": bundle.iron_condor} if bundle is not None else {})
    eval_map = {key: getattr(decision, key.lower().replace(" ", "_"), None)
                for key in ("CE BUY", "PE BUY", "CE SELL", "PE SELL", "IRON CONDOR")}
    common_best = str(common.get("best_strategy") or "WAIT")
    if common_best in plan_map:
        name, plan = common_best, plan_map[common_best]
        score = float(getattr(eval_map.get(common_best), "score", 0) or 0)
    if common_action == "WAIT" or not entry_ready:
        css_class = "wait"
        title = display_wait_stage if snapshot.market_session.is_live else "WAIT"
        if not snapshot.market_session.is_live:
            subtitle = "REFERENCE ONLY — fresh strategy ranking band"
            structure = snapshot.market_session.message
        elif common_action == "WAIT":
            subtitle = f"{direction_text} · Evidence {direction_score:.1f}% — entry abhi WAIT"
            reference = (
                f"Reference {public_action_label(name)} (Fit {score:.1f}%): {_plan_structure_text(plan)} · "
                if plan is not None and plan.available and score > 0
                else ""
            )
            if reference:
                reference = "Reference ranking; entry confirmed nahi. " + reference
            else:
                reference = "Koi usable strike setup nahi. "
            simple_reason = str(simple.get("instruction") or "")
            common_blockers = common.get("blockers") or ()
            blocker_text = simple_reason or (str(common_blockers[0]) if common_blockers else "Entry trigger pending")
            structure = (
                f"Karan: {direction_note}. {reference}"
                + blocker_text
            )
        else:
            candidate = public_action_label(common_action)
            blocked_text = "CONDITIONS PENDING" if public_mode_enabled() else "ENTRY BLOCKED"
            subtitle = f"{direction_text} · Evidence {direction_score:.1f}% — {blocked_text}"
            structure = (
                f"Candidate {candidate} (Fit {score:.1f}%): {_plan_structure_text(plan)} · "
                + str((snapshot.execution_guard.blockers or ("Safety confirmation pending",))[0])
            )
    else:
        css_class = "ready"
        title = public_action_label(common_action)
        readiness_word = "Condition readiness" if public_mode_enabled() else "Entry readiness"
        subtitle = f"SIMPLE ONE-BRAIN READY · {readiness_word} {float((getattr(snapshot, 'metadata', {}).get('simple_brain') or {}).get('entry_readiness') or common.get('trade_confidence') or 0):.1f}/100"
        structure = _plan_structure_text(plan_map.get(common_action))
    live_text = "LIVE" if feed_ok else "LAST DATA"
    hero = (
        '<style>'
        '.brain-hero{border-radius:16px;padding:16px 18px;margin:4px 0 12px;border:1px solid rgba(127,127,127,.24)}'
        '.brain-hero.ready{background:rgba(34,197,94,.14);border-color:rgba(34,197,94,.42)}'
        '.brain-hero.wait{background:rgba(245,158,11,.13);border-color:rgba(245,158,11,.42)}'
        '.brain-hero-top{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}'
        '.brain-hero-label{font-size:.76rem;font-weight:800;letter-spacing:.06em;opacity:.76}'
        '.brain-hero-action{font-size:1.65rem;font-weight:900;line-height:1.15;margin-top:3px}'
        '.brain-hero-badge{font-size:.78rem;font-weight:800;padding:6px 9px;border-radius:99px;background:rgba(127,127,127,.13);white-space:nowrap}'
        '.brain-hero-sub{font-size:.92rem;font-weight:700;margin-top:8px}'
        '.brain-hero-structure{font-size:.82rem;opacity:.82;margin-top:5px;overflow-wrap:anywhere}'
        '@media(max-width:760px){.brain-hero{padding:13px}.brain-hero-action{font-size:1.35rem}.brain-hero-top{gap:8px}.brain-hero-badge{font-size:.70rem}}'
        '</style>'
        f'<div class="brain-hero {css_class}">'
        '<div class="brain-hero-top"><div>'
        '<div class="brain-hero-label">COMMON FINAL DECISION</div>'
        f'<div class="brain-hero-action">{escape(title)}</div></div>'
        f'<div class="brain-hero-badge">{escape(live_text)}</div></div>'
        f'<div class="brain-hero-sub">{escape(subtitle)}</div>'
        f'<div class="brain-hero-structure">{escape(structure)}</div>'
        '</div>'
    )
    if hasattr(st, "html"):
        st.html(hero)
    else:
        st.markdown(hero, unsafe_allow_html=True)


def _pattern_compact_text(item: Any | None, *, fallback: str) -> tuple[str, str]:
    if item is None or item.status == "UNAVAILABLE":
        return fallback, "No reliable confirmation"
    if item.name in {"NO VALID W/M", "NO IMPORTANT CANDLE"}:
        return item.name, "Neutral / no important pattern"
    note_bits = [item.strength]
    if item.level_value is not None:
        note_bits.append(f"{item.level_label or 'Level'} {item.level_value:,.0f}")
    if item.neckline is not None:
        note_bits.append(f"NL {item.neckline:,.0f}")
    return item.name, " · ".join(note_bits)


def render_detailed_evidence(snapshot: MarketSnapshot) -> None:
    """Render diagnostics only; this view never recalculates or changes a decision."""
    critical_feeds = [
        snapshot.feed_status.get(key)
        for key in ("quotes", "candles", "option_chain", "future_volume", "vix")
    ]
    critical_feeds = [item for item in critical_feeds if item is not None]
    data_quality = (
        100.0
        * sum(item.ok and item.use_state not in {"UNAVAILABLE", "STALE"} for item in critical_feeds)
        / len(critical_feeds)
        if critical_feeds
        else 0.0
    )

    def evidence_direction(value: str) -> str:
        text = str(value or "").upper()
        if "BULL" in text or "BUYING" in text:
            return "BULLISH"
        if "BEAR" in text or "SELLING" in text:
            return "BEARISH"
        return "RANGE"

    simple_direction = str((snapshot.metadata.get("simple_brain") or {}).get("direction") or "")
    final_direction = evidence_direction(simple_direction or snapshot.decision.market_direction)
    sources = (
        evidence_direction(snapshot.core_evidence.market_state),
        evidence_direction(snapshot.option_intelligence.market_bias),
        evidence_direction(snapshot.price_action.combined_state),
        evidence_direction(snapshot.big_player_activity.direction),
    )
    agreement = round(100.0 * sum(item == final_direction for item in sources) / len(sources))
    with st.expander("Detailed evidence, agreement, Greeks and history", expanded=False):
        st.caption("🎯 " + unified_direction_line(snapshot))
        st.caption(f"Feed coverage {data_quality:.0f}% · Legacy module agreement {agreement:.0f}% (diagnostic only)")
        for line in snapshot.metadata.get("history_context", {}).get("lines", []):
            st.caption("History context: " + line)
        render_greeks_health(snapshot.option_chain)


def render_main_ai_market_view(
    snapshot: MarketSnapshot,
    previous_snapshot: MarketSnapshot | None = None,
    decision_reason_renderer: Callable[[], None] | None = None,
) -> None:
    """Simple top-screen view of the existing canonical MarketSnapshot."""

    barrier = snapshot.barrier_map
    feed_ok, _feed_text = required_live_feed_state(snapshot)
    direction, direction_score, direction_note = market_rukh_display(snapshot)
    spot = snapshot.nifty_quote.get("last_price")

    st.subheader("🧠 Simple One-Brain Trading Workspace")

    with st.container(border=True):
        _render_final_action_hero(snapshot, feed_ok)
        simple = snapshot.metadata.get("simple_brain") or {}
        future = snapshot.metadata.get("future_brain") or {}
        common = snapshot.metadata.get("common_decision") or {}
        if simple:
            st.markdown("### 🎯 One Simple Decision")
            entry_state = str(simple.get("entry_state") or "WAIT")
            a, b, c, d = st.columns(4)
            core_block_coverage = simple_core_block_coverage(simple)
            _display_direction_strength = float(simple.get("display_direction_strength", simple.get("direction_strength")) or 0)
            _raw_direction_strength = float(simple.get("raw_direction_strength", simple.get("direction_strength")) or 0)
            a.metric("DIRECTION", f"{simple.get('direction', 'MIXED')} {_display_direction_strength:.0f}/100")
            if abs(_display_direction_strength - _raw_direction_strength) >= 3:
                a.caption(f"Raw {_raw_direction_strength:.0f} · stability view")
            if core_block_coverage is not None:
                a.caption(f"Core blocks available {core_block_coverage:.0f}%")
            regime_text = str(simple.get("regime") or "TRANSITION")
            b.markdown(
                '<div class="regime-card"><div class="regime-label">REGIME</div>'
                f'<div class="regime-value">{escape(regime_text)}</div></div>'
                '<style>.regime-card{min-height:74px;padding:4px 0}.regime-label{font-size:.82rem;opacity:.72}'
                '.regime-value{font-size:1.42rem;font-weight:750;line-height:1.12;overflow-wrap:anywhere;white-space:normal}'
                '@media(max-width:760px){.regime-value{font-size:1.05rem}}</style>',
                unsafe_allow_html=True,
            )
            c.metric(
                entry_metric_label(),
                "DATA INCOMPLETE" if "DATA" in entry_state else f"{float(simple.get('display_entry_readiness', simple.get('entry_readiness')) or 0):.0f}/100",
            )
            if "DATA" in entry_state:
                c.caption(f"Structural readiness {float(simple.get('display_entry_readiness', simple.get('entry_readiness')) or 0):.0f}/100")
            _action_raw = str(common.get("final_action") or simple.get("final_action") or "WAIT")
            _action_display = _wait_display_stage(simple, _action_raw) if _action_raw.upper() == "WAIT" else public_action_label(_action_raw)
            d.metric("ACTION", _action_display)
            trigger = str(simple.get("trigger") or simple.get("instruction") or "")
            if common.get("entry_allowed"):
                st.success(f"🚨 **{ready_banner_label()} — {public_action_label(common.get('final_action'))}** · {trigger}")
            elif "WAIT" in entry_state or "NO CLEAR" in entry_state or "DATA" in entry_state:
                st.warning(f"⏳ **{entry_state}** · {trigger}")
            else:
                st.info(f"🎯 **{entry_state}** · {trigger}")
            if simple.get("risk_notes"):
                st.caption("Risk: " + " | ".join(str(x) for x in simple.get("risk_notes") or ()))
            next_level = simple.get("next_level")
            if next_level is not None:
                st.caption(f"Next level: {float(next_level):,.0f}")
            coverage = simple.get("evidence_coverage")
            if coverage is not None:
                st.caption(
                    f"Entry-evidence coverage: {float(coverage):.0f}% · "
                    "ye entry-readiness denominator hai; missing block ko RANGE/neutral vote nahi maana jata."
                )
            with st.expander("4 core blocks — calculation", expanded=False):
                blocks = simple.get("blocks") or {}
                rows = []
                for key, value in blocks.items():
                    if not isinstance(value, dict):
                        continue
                    def _cell(value_in: Any, *, pct: bool = False) -> str:
                        if value_in is None or value_in == "":
                            return "—"
                        try:
                            number = float(value_in)
                        except (TypeError, ValueError):
                            return str(value_in)
                        return f"{number:.0f}%" if pct else f"{number:.1f}"

                    rows.append({
                        "Block": key.replace("_", " ").title(),
                        "Weight": _cell(value.get("weight"), pct=True),
                        "Available": (
                            "YES" if value.get("available") is True
                            else "NO" if value.get("available") is False
                            else "—"
                        ),
                        "Bull": _cell(value.get("bullish")),
                        "Bear": _cell(value.get("bearish")),
                        "Neutral/State": _cell(value.get("neutral", value.get("state"))),
                    })
                if rows:
                    st.dataframe(rows, width="stretch", hide_index=True)
                for reason in simple.get("reasons") or ():
                    st.caption("• " + str(reason))
            if future:
                future_title, future_history_note = future_brain_display_label(future)
                with st.expander("🔮 " + future_title, expanded=False):
                    st.caption(future_history_note)
                    st.caption("Future Brain ab ordinary MIXED forecast par current trade direction ko hard block nahi karta.")
                    p1, p2, p3 = st.columns(3)
                    p1.metric("15m UP", f"{float(future.get('up_15m') or 0):.1f}%")
                    p2.metric("15m DOWN", f"{float(future.get('down_15m') or 0):.1f}%")
                    p3.metric("15m RANGE", f"{float(future.get('range_15m') or 0):.1f}%")
                    st.caption(f"{future.get('transition', 'MIXED')} · {future.get('final_gate', 'ADVISORY')}")
            if decision_reason_renderer is not None:
                decision_reason_renderer()
        elif future:
            st.markdown("### 🔮 Future Brain — legacy snapshot")
            st.caption(str(future.get("transition") or "MIXED / TRANSITION"))
        else:
            forecast = build_canonical_forecast(snapshot)
            st.markdown(f"**Next 5–15 min path — {forecast.direction} · {forecast.state}**")
        compact_simple = snapshot.metadata.get("simple_brain") or {}
        compact_entry_state = str(compact_simple.get("entry_state") or snapshot.execution_guard.readiness)
        compact_entry_value = (
            "DATA INCOMPLETE"
            if "DATA" in compact_entry_state
            else f"{float(compact_simple.get('entry_readiness') or snapshot.decision.decision_confidence):.0f}%"
        )
        data_score, _data_detail = _data_confidence(snapshot)
        _render_compact_cards(
            [
                ("NIFTY", f"{float(spot):,.2f}" if spot is not None else "—", "Current / last available"),
                (
                    "Final Market Bias",
                    direction,
                    f"Directional evidence {direction_score:.0f}/100"
                    + (f" · core coverage {core_block_coverage:.0f}%" if core_block_coverage is not None else "")
                    + f" · {direction_note}",
                ),
                (
                    "Entry State" if snapshot.market_session.is_live else "Reference State",
                    compact_entry_value,
                    compact_entry_state,
                ),
                (
                    "Data Confidence",
                    f"{data_score}/100" if snapshot.market_session.is_live else f"{data_score}/100 REF",
                    "Feed trust only · One-Brain score unchanged",
                ),
            ]
        )

        pa15_text = str(getattr(snapshot.price_action.fifteen_minute, "structure", "") or "15m mixed")
        pa3_text = str(getattr(snapshot.price_action.three_minute, "structure", "") or "3m mixed")
        option_ready = str(getattr(snapshot.option_intelligence, "status", "")).upper() == "READY"
        barrier_state = str(((compact_simple.get("blocks") or {}).get("barrier_entry") or {}).get("state") or "UNKNOWN")
        short_reason = (
            f"15m {pa15_text}; 3m {pa3_text}. "
            f"Options flow {'ready' if option_ready else 'warming/unavailable'}. "
            f"Barrier {barrier_state}. {compact_entry_state}."
        )
        flow_maturity = _display_flow_maturity(snapshot.option_intelligence)
        flow_conflict = _option_conflict_text(snapshot.option_intelligence)
        st.info(
            "🧠 **AI samajh:** " + short_reason
            + f" Flow maturity {flow_maturity}. Conflict/Caution: {flow_conflict}."
        )
        with st.expander("Full AI reasoning", expanded=False):
            st.caption(safe_brain_hinglish_line(snapshot, previous_snapshot))
        patterns = getattr(snapshot, "patterns", None)
        wm_text, _wm_note = _pattern_compact_text(
            patterns.wm_3m if patterns is not None else None,
            fallback="NO VALID W/M",
        )
        candle_text, _candle_note = _pattern_compact_text(
            (
                patterns.candle_3m
                if patterns is not None
                else None
            ),
            fallback="NO IMPORTANT CANDLE",
        )

        inst = snapshot.institutional_context
        if inst.observations <= 0:
            inst_text = "MISSING"
        elif "FII SELLING / DII ABSORPTION" in inst.state:
            inst_text = "FII SELL · DII BUY"
        elif "FII BUYING / DII SELLING" in inst.state:
            inst_text = "FII BUY · DII SELL"
        elif "SUPPORT" in inst.state:
            inst_text = "NET SUPPORT"
        elif "PRESSURE" in inst.state:
            inst_text = "NET PRESSURE"
        else:
            inst_text = "MIXED"

        heavy = snapshot.heavyweights
        top7_move = (
            f"15m {heavy.recent_15m_move_pct:+.2f}%"
            if heavy.recent_15m_move_pct is not None
            else "15m WARMING UP"
        )
        news_display = normalized_news_display(snapshot.news_context)
        if news_display.status == "READY":
            news_text = f"{news_display.risk} RISK"
        else:
            news_text = "ZERO LIVE WEIGHT"
        st.caption(
            f"W/M: {wm_text} • Candle: {candle_text} • Top-9: {top7_move} • "
            f"FII/DII background: {inst_text} • News: {news_text}"
        )
        activity = getattr(snapshot, "big_player_activity", None)
        if activity is not None:
            activity_type = str(getattr(activity, "activity_type", ""))
            closing_flow = activity_type in {"SHORT COVERING", "LONG UNWINDING"}
            icon = "🟡" if closing_flow else "🟢" if activity.direction == "BUYING" else "🔴" if activity.direction == "SELLING" else "🟣"
            display_direction = activity_type if closing_flow else activity.direction
            confirmation_text = (
                "No danger confirmation"
                if activity.state == "NORMAL"
                else f"{activity.confirmation_count}/{activity.confirmation_total}"
            )
            activity_line = (
                f"{icon} **Big Player:** {activity.state} {display_direction} "
                f"{activity.score:.0f}/100 · {confirmation_text} "
                f"· Reversal {activity.reversal_risk} · Recent 3m flow"
            )
            if closing_flow and activity.score >= 60:
                st.warning(activity_line)
            elif activity.confirmation_count >= 2 and activity.score >= 75 and activity.direction == "SELLING":
                st.error(activity_line)
            elif activity.confirmation_count >= 2 and activity.score >= 75 and activity.direction == "BUYING":
                st.success(activity_line)
            elif activity.score >= 60:
                st.warning(activity_line)
            else:
                st.caption(activity_line)
            if closing_flow:
                st.caption("↳ " + activity.participant_explanation)

        resistance = _level_summary(barrier.nearest_resistance, fallback="R1")
        support = _level_summary(barrier.nearest_support, fallback="S1")
        st.caption(f"🔴 Resistance: {resistance}   |   🟢 Support: {support}")

        with st.expander("Last snapshot se badlav", expanded=False):
            changes = snapshot_change_items(snapshot, previous_snapshot)
            if changes:
                cards = [
                    (label, value, f"Badlav {delta}" if delta else "No comparable delta")
                    for label, value, delta in changes
                ]
                _render_compact_cards(cards)
            st.caption(snapshot_change_hinglish(snapshot, previous_snapshot))




def render_news_context(snapshot: MarketSnapshot) -> None:
    news = snapshot.news_context
    status = str(news.status).upper()
    risk = str(news.risk_level).upper()
    bias = str(news.bias).upper()
    if status == "READY":
        points = {"HIGH": 9, "MEDIUM": 5, "LOW": 2}.get(risk, 0)
    elif status == "OLD":
        points = min(2, {"HIGH": 9, "MEDIUM": 5, "LOW": 2}.get(risk, 0))
    else:
        points = 0
    severity = (
        "DANGEROUS" if risk == "HIGH" and status == "READY"
        else "CAUTION" if points >= 3 or status == "OLD"
        else "NORMAL" if points > 0
        else "NO LIVE NEWS"
    )
    signed = -points if bias == "BEARISH" else points if bias == "BULLISH" else 0
    age = (
        f"{news.newest_age_minutes:.0f}m"
        if news.newest_age_minutes is not None
        else "NA"
    )
    st.info(
        f"**News Indicator:** {bias} • {severity} • Asar {signed:+d}/9 • "
        f"{status} • Age {age}"
    )


def _decision_evaluations(snapshot: MarketSnapshot) -> dict[str, Any]:
    item = snapshot.decision
    return {
        "CE BUY": item.ce_buy,
        "PE BUY": item.pe_buy,
        "CE SELL": item.ce_sell,
        "PE SELL": item.pe_sell,
        "IRON CONDOR": item.iron_condor,
    }


def render_position_guardian(snapshot: MarketSnapshot) -> None:
    item = snapshot.position_guardian
    st.subheader("Position Guardian — Manual Trade Monitor")
    st.caption(
        "This monitor starts only after you manually mark a protected trade taken. "
        "It tracks the exact stored legs from the same full option-chain snapshot and "
        "shows deterministic target, SL, spot-invalidation and time-exit alerts. It "
        "cannot place, modify or exit a broker order."
    )

    if item.status == "IDLE":
        st.info(
            "No open trade is recorded. Position monitoring will start after an ENTRY READY setup is manually marked taken."
        )
        return

    is_buy = item.action in {"CE BUY", "PE BUY"}
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Guardian Instruction", item.instruction)
    c2.metric(
        "Current Option Value" if is_buy else "Current Combo Debit",
        f"{item.current_debit_points:.2f} pts"
        if item.current_debit_points is not None
        else "—",
    )
    c3.metric(
        "P&L Estimate",
        f"₹{item.unrealized_pnl_rupees:,.0f}"
        if item.unrealized_pnl_rupees is not None
        else "—",
        f"{item.unrealized_pnl_points:+.2f} pts"
        if item.unrealized_pnl_points is not None
        else None,
    )
    c4.metric(
        "Target Progress",
        f"{item.target_progress_pct:.1f}%"
        if item.target_progress_pct is not None
        else "—",
    )

    entry_label = "Entry debit" if is_buy else "Entry credit"
    summary = (
        f"Action: {item.action or '—'} | Expiry: {item.expiry or '—'} | "
        f"Lots: {item.lots} × {item.lot_size} | {entry_label}: "
        f"{item.entry_credit_points:.2f} pts"
        if item.entry_credit_points is not None
        else f"Action: {item.action or '—'} | Expiry: {item.expiry or '—'} | Lots: {item.lots} × {item.lot_size}"
    )
    if item.status in {"EXIT ALERT", "TARGET ALERT"}:
        st.warning(summary)
    elif item.status == "DATA BLOCKED":
        st.error(summary)
    elif item.status == "CLOSED":
        st.info(summary)
    else:
        st.success(summary)

    rule_rows = [
        {
            "Entry spot": item.entry_spot,
            "Current spot": item.current_spot,
            "Target option value": item.target_exit_debit_points,
            "SL option value": item.stop_exit_debit_points,
            "Spot invalidation low": item.spot_invalidation_low,
            "Spot invalidation high": item.spot_invalidation_high,
            "Compulsory exit": item.forced_exit_time,
            "Status": item.status,
        }
    ]
    st.dataframe(pd.DataFrame(rule_rows), width="stretch", hide_index=True)

    if item.legs:
        leg_rows = [
            {
                "Role": leg.role,
                "Side": leg.side,
                "Strike": leg.strike,
                "Entry price": leg.entry_price,
                "Current close price": leg.current_price,
                "P&L contribution pts": leg.pnl_contribution_points,
                "Status": leg.status,
            }
            for leg in item.legs
        ]
        st.dataframe(pd.DataFrame(leg_rows), width="stretch", hide_index=True)

    left, right = st.columns(2)
    with left:
        st.write("**Guardian evidence**")
        for reason in item.reasons or ("No active guardian reason",):
            st.write(f"• {reason}")
    with right:
        st.write("**Guardian blockers**")
        for blocker in item.blockers or ("None",):
            st.write(f"• {blocker}")


def _data_confidence(snapshot: MarketSnapshot) -> tuple[int, str]:
    """Display-only trust score from existing FeedStatus objects.

    No API calls and no impact on One-Brain scores. Closed sessions are explicitly
    labelled reference-only so normal after-market staleness is not misread as a
    live-feed failure.
    """
    weights = {"quotes": 25, "candles": 25, "option_chain": 30, "future_volume": 10, "vix": 10}
    statuses = snapshot.feed_status or {}
    total = 0.0
    details = []
    for key, weight in weights.items():
        item = statuses.get(key)
        if item is None:
            factor, state = 0.0, "MISSING"
        else:
            state = str(getattr(item, "use_state", "UNAVAILABLE") or "UNAVAILABLE").upper()
            if not bool(getattr(item, "ok", False)) or state == "UNAVAILABLE":
                factor = 0.0
            elif state == "LIVE":
                factor = 1.0
            elif state in {"CAUTION", "DELAYED"}:
                factor = 0.65
            elif state == "STALE":
                factor = 0.25
            else:
                factor = 0.50
        total += weight * factor
        details.append(f"{key}:{state}")
    score = int(round(max(0.0, min(100.0, total))))
    mode = "REFERENCE ONLY" if not snapshot.market_session.is_live else "LIVE TRUST"
    return score, mode + " · " + " · ".join(details)


def _display_flow_maturity(item: Any) -> str:
    """Human-friendly persistence label; presentation only."""
    ready = [w for w in getattr(item, "windows", ()) if str(getattr(w, "status", "")).upper() == "READY"]
    by_sec = {int(getattr(w, "target_seconds", 0)): str(getattr(w, "bias", "MIXED")).upper() for w in ready}
    fast1, fast3, slow5 = by_sec.get(60), by_sec.get(180), by_sec.get(300)
    directional = {"BULLISH", "BEARISH"}
    if fast1 in directional and fast3 == fast1 and slow5 in directional and slow5 != fast1:
        return "FADING / TRANSITION"
    persistence = str(getattr(item, "persistence", "") or "").upper()
    if "PERSISTENT" in persistence:
        return "SUSTAINED"
    if "DEVELOPING" in persistence:
        return "FORMING"
    directional_ready = [w for w in ready if str(getattr(w, "bias", "")).upper() in directional]
    if len(directional_ready) == 1:
        return "NEW SPIKE"
    if len(directional_ready) >= 2 and len({str(w.bias).upper() for w in directional_ready}) == 1:
        return "FORMING"
    if not ready:
        return "WARMING UP"
    return "MIXED"


def _option_conflict_text(item: Any) -> str:
    ready = [w for w in getattr(item, "windows", ()) if str(getattr(w, "status", "")).upper() == "READY"]
    biases = [str(getattr(w, "bias", "")).upper() for w in ready]
    directional = {b for b in biases if b in {"BULLISH", "BEARISH"}}
    if len(directional) > 1:
        return "1m/3m/5m directional disagreement"
    market_bias = str(getattr(item, "market_bias", "")).upper()
    if market_bias in {"BULLISH", "BEARISH"} and any(b in {"BULLISH", "BEARISH"} and b != market_bias for b in biases):
        return "Fast/slow flow conflict"
    blockers = tuple(getattr(item, "blockers", ()) or ())
    return str(blockers[0]) if blockers else "No major flow conflict"


def render_core_evidence(snapshot: MarketSnapshot) -> None:
    item = snapshot.core_evidence
    st.dataframe(
        [{
            "Market": f"{item.market_state} {item.range_score:.0f}%",
            "Bullish": f"{item.bullish_score:.0f}%",
            "Bearish": f"{item.bearish_score:.0f}%",
            "Evidence quality": f"{item.confidence:.0f}%",
        }],
        width="stretch",
        hide_index=True,
    )
    st.info(
        f"**Kyon:** {(item.reasons or ('Mixed evidence',))[0]}  •  "
        f"**Savdhani:** {(item.blockers or ('Koi major caution nahi',))[0]}"
    )


def render_price_action(snapshot: MarketSnapshot) -> None:
    bundle = snapshot.price_action
    st.caption(
        f"Cross-timeframe view: **{bundle.combined_state}** — {bundle.relationship} "
        f"(confidence {bundle.confidence:.1f}%)."
    )
    rows = []
    for item in (bundle.three_minute, bundle.fifteen_minute):
        rows.append({
            "Time": item.timeframe,
            "Structure": item.structure,
            "Current move": item.event,
            "Invalidation": item.invalidation_level,
            "Evidence quality": f"{item.confidence:.0f}%",
        })
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)


def _level_row(level: MarketLevel | None, fallback: str) -> dict[str, Any]:
    if level is None:
        return {
            "Level": fallback,
            "Zone": "—",
            "Midpoint": None,
            "Distance": None,
            "Strength": None,
            "Status": "UNAVAILABLE",
            "Sources": "—",
        }
    return {
        "Level": f"{level.label} {level.side}",
        "Zone": f"{level.lower:,.2f}–{level.upper:,.2f}",
        "Midpoint": level.midpoint,
        "Distance": level.distance_points,
        "Strength": level.strength,
        "Status": level.status,
        "Sources": ", ".join(level.sources),
    }


def render_levels(snapshot: MarketSnapshot) -> None:
    item = snapshot.levels
    rows = []
    for level, fallback in (
        (item.immediate_support, "S1"), (item.strong_support, "S2"),
        (item.immediate_resistance, "R1"), (item.strong_resistance, "R2"),
    ):
        raw = _level_row(level, fallback)
        rows.append({
            "Level": raw["Level"], "Zone": raw["Zone"],
            "Distance": raw["Distance"], "Strength": raw["Strength"], "Status": raw["Status"],
        })
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)


def render_volume(snapshot: MarketSnapshot) -> None:
    item = snapshot.volume
    st.write(f"**Volume:** {item.overall_view} • Evidence quality {item.confidence:.0f}%")
    rows = []
    for row in (item.three_minute, item.fifteen_minute):
        rows.append({
            "Time": row.timeframe,
            "Relative volume": f"{row.relative_volume:.2f}×" if row.relative_volume is not None else "—",
            "Participation": row.volume_state,
            "Trend": row.volume_trend,
            "Move support": row.move_support,
        })
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)


def render_candles(snapshot: MarketSnapshot) -> None:
    tabs = st.tabs(
        [
            "NIFTY 3m",
            "NIFTY 15m",
            "NIFTY 1m",
            "Future 3m Volume",
            "Future 15m Volume",
        ]
    )
    with tabs[0]:
        st.caption(
            "3-minute candles are aggregated from Dhan 1-minute candles at 09:15 IST."
        )
        st.dataframe(snapshot.candles_3m.tail(30), width="stretch", hide_index=True)
    with tabs[1]:
        st.dataframe(snapshot.candles_15m.tail(30), width="stretch", hide_index=True)
    with tabs[2]:
        st.dataframe(snapshot.candles_1m.tail(30), width="stretch", hide_index=True)
    with tabs[3]:
        st.dataframe(
            snapshot.future_candles_3m.tail(30),
            width="stretch",
            hide_index=True,
        )
    with tabs[4]:
        st.dataframe(
            snapshot.future_candles_15m.tail(30),
            width="stretch",
            hide_index=True,
        )


def render_option_chain(snapshot: MarketSnapshot) -> None:
    if snapshot.option_chain.empty:
        st.warning("Option chain is unavailable in this snapshot.")
        return
    columns = [
        "strike",
        "side",
        "is_atm",
        "last_price",
        "oi",
        "day_oi_change",
        "volume",
        "previous_close_price",
        "day_price_change",
        "implied_volatility",
        "top_bid_price",
        "top_ask_price",
    ]
    available = [col for col in columns if col in snapshot.option_chain.columns]
    st.caption(
        "Raw option-chain fields from the same authoritative snapshot. Derived flow is shown "
        "in the Options Intelligence section above."
    )
    st.dataframe(snapshot.option_chain[available], width="stretch", hide_index=True)


def render_heavyweights(snapshot: MarketSnapshot) -> None:
    bundle = snapshot.heavyweights
    st.info(f"Top-9 combined: {bundle.recent_state} · day basket {bundle.weighted_move_pct}%")
    st.caption(f"15m basket {bundle.recent_15m_move_pct}%; 3m early change {bundle.recent_3m_move_pct}%; estimated Nifty contribution {bundle.recent_contribution_points} points")
    st.caption(f"Recent coverage: {bundle.recent_coverage_pct:.2f}/{bundle.covered_weight_pct:.2f}% index weight. Configured weights dated {bundle.weight_date}; estimated, not predictive. Rest of index may offset this.")
    st.dataframe([{"Stock": r.symbol, "Day %": r.change_pct, "15m %": r.change_15m_pct, "3m %": r.change_3m_pct, "Nifty pts (15m)": r.contribution_15m_points, "Now": r.recent_state} for r in bundle.rows], width="stretch", hide_index=True)
    if not snapshot.heavyweight_quotes:
        st.info("Top-9 quotes are unavailable in this snapshot.")
        return
    rows: list[dict[str, Any]] = []
    for item in snapshot.heavyweight_quotes:
        ohlc = item.get("ohlc") or {}
        previous_close = ohlc.get("close")
        last = item.get("last_price")
        change_pct = None
        if previous_close not in (None, 0) and last is not None:
            change_pct = (
                (float(last) - float(previous_close)) / float(previous_close) * 100
            )
        rows.append(
            {
                "Symbol": item.get("symbol"),
                "Name": item.get("display_name"),
                "Last": last,
                "Change %": change_pct,
                "Day High": ohlc.get("high"),
                "Day Low": ohlc.get("low"),
                "Volume": item.get("volume"),
                "Security ID": item.get("security_id"),
            }
        )
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)


def render_indicators(snapshot: MarketSnapshot) -> None:
    rows = []
    for item in (snapshot.indicators.three_minute, snapshot.indicators.fifteen_minute):
        rows.append({
            "Time": item.timeframe,
            "EMA trend": item.ema_state,
            "MACD": item.macd_state,
            "RSI": f"{item.rsi14:.0f} • {item.rsi_state}" if item.rsi14 is not None else item.rsi_state,
        })
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)


def render_option_intelligence(snapshot: MarketSnapshot) -> None:
    item = snapshot.option_intelligence
    provisional = item.persistence != "CONFIRMED" or item.confidence < 75
    st.dataframe([{
        "Bias": f"{item.market_bias}{' • Provisional' if provisional else ''}",
        "Bullish": f"{item.bullish_score:.0f}%",
        "Bearish": f"{item.bearish_score:.0f}%",
        "Mixed": f"{item.range_score:.0f}%",
        "Evidence quality": f"{item.confidence:.0f}%",
    }], width="stretch", hide_index=True)
    st.info(
        f"**Reason:** {(item.reasons or ('Option flow mixed',))[0]}  •  "
        f"**Waiting:** {(item.blockers or ('Confirmation complete',))[0]}"
    )


def render_option_flow_matrix(snapshot: MarketSnapshot) -> None:
    rows = list(snapshot.option_intelligence.flow_rows)
    if not rows:
        st.info("Option flow matrix is unavailable in this snapshot.")
        return
    frame = pd.DataFrame(rows)
    keep = [column for column in ("strike", "side", "last_price", "classification", "directional_bias", "flow_strength") if column in frame.columns]
    st.dataframe(frame[keep], width="stretch", hide_index=True)


def render_option_windows(snapshot: MarketSnapshot) -> None:
    rows = []
    for item in snapshot.option_intelligence.windows:
        rows.append(
            {
                "Window": item.label,
                "Target sec": item.target_seconds,
                "Actual age sec": item.actual_age_seconds,
                "CE OI Δ": item.ce_oi_delta,
                "PE OI Δ": item.pe_oi_delta,
                "CE Premium Δ": item.ce_premium_delta,
                "PE Premium Δ": item.pe_premium_delta,
                "CE Volume Δ": item.ce_volume_delta,
                "PE Volume Δ": item.pe_volume_delta,
                "Bias": item.bias,
                "Status": item.status,
            }
        )
    ready = [row for row in rows if row["Bias"] not in {"UNAVAILABLE", None}]
    if not ready:
        st.info(f"⏳ Movement confirmation warming up • Ready 0/{len(rows)}")
        return
    st.dataframe(pd.DataFrame(ready), width="stretch", hide_index=True)


def render_walls_and_pcr(snapshot: MarketSnapshot) -> None:
    item = snapshot.option_intelligence
    global_walls = (snapshot.metadata or {}).get("global_oi_walls") or {}
    walls = []
    for wall in (item.ce_wall, item.pe_wall):
        global_wall = global_walls.get(str(wall.side).upper()) or {}
        walls.append(
            {
                "Side": wall.side,
                "Near-ATM Wall Strike": wall.strike,
                "Near-ATM Wall OI": wall.oi,
                "Global Max OI Strike": global_wall.get("strike"),
                "Global Max OI": global_wall.get("oi"),
                "Strongest 3-Strike Cluster": wall.cluster_center,
            }
        )
    st.dataframe(pd.DataFrame(walls), width="stretch", hide_index=True)
    pcr = item.pcr
    c1, c2, c3, c4 = st.columns(4)
    c1.metric(
        "Near-ATM OI PCR",
        f"{pcr.near_atm_oi_pcr:.2f}" if pcr.near_atm_oi_pcr is not None else "—",
    )
    c2.metric(
        "Day Addition PCR",
        f"{pcr.day_addition_pcr:.2f}" if pcr.day_addition_pcr is not None else "—",
    )
    c3.metric(
        "Intraday Addition PCR",
        f"{pcr.intraday_addition_pcr:.2f}"
        if pcr.intraday_addition_pcr is not None
        else "—",
    )
    c4.metric(
        "Volume PCR", f"{pcr.volume_pcr:.2f}" if pcr.volume_pcr is not None else "—"
    )
    st.caption(f"PCR context: **{pcr.state}** | Status: {pcr.status}")


def render_options_live_board(snapshot: MarketSnapshot, option_state_store: Any | None = None) -> None:
    """Broker-style single-screen options board using only the current snapshot.

    This is presentation-only: it performs no API request and does not recompute
    One-Brain scores. The goal is to keep the flow windows, PCR/walls and the
    strike chain visible together for audit/live comparison.
    """
    item = snapshot.option_intelligence
    chain = snapshot.option_chain.copy()
    if chain.empty:
        st.warning("Options Live Board unavailable — option chain is empty.")
        return

    st.subheader("📊 Options Live Board")
    st.caption(
        "Broker-style single screen • CE left | STRIKE center | PE right • "
        "same authoritative snapshot, no extra Dhan/API call."
    )

    pcr = item.pcr
    ready_windows = [
        w for w in item.windows
        if str(getattr(w, "status", "")).upper() not in {"UNAVAILABLE", "INSUFFICIENT CONTINUITY"}
        and str(getattr(w, "bias", "")).upper() not in {"UNAVAILABLE", "NONE", ""}
    ]
    maturity = f"{len(ready_windows)}/{len(item.windows)} READY" if item.windows else "0/0"
    maturity_state = _display_flow_maturity(item)
    data_score, _ = _data_confidence(snapshot)
    ce_wall = item.ce_wall
    pe_wall = item.pe_wall

    cards = [
        ("OPTIONS BIAS", str(item.market_bias or "MIXED"), f"Evidence {item.confidence:.0f}% · {maturity_state}"),
        ("FLOW MATURITY", maturity_state, maturity + " · 1m / 3m / 5m"),
        ("DATA CONFIDENCE", f"{data_score}/100", "Display-only feed trust; no score impact"),
        ("NEAR-ATM PCR", f"{pcr.near_atm_oi_pcr:.2f}" if pcr.near_atm_oi_pcr is not None else "—", str(pcr.state or pcr.status)),
        ("INTRADAY PCR", f"{pcr.intraday_addition_pcr:.2f}" if pcr.intraday_addition_pcr is not None else "—", "OI addition context"),
        ("CE WALL / CLUSTER", f"{ce_wall.strike:,.0f}" if ce_wall.strike is not None else "—", f"Cluster {ce_wall.cluster_center:,.0f}" if ce_wall.cluster_center is not None else "Cluster —"),
        ("PE WALL / CLUSTER", f"{pe_wall.strike:,.0f}" if pe_wall.strike is not None else "—", f"Cluster {pe_wall.cluster_center:,.0f}" if pe_wall.cluster_center is not None else "Cluster —"),
    ]
    _render_compact_cards(cards)
    why = str((item.reasons or ("Option flow mixed",))[0])
    conflict = _option_conflict_text(item)
    st.info(f"**WHY:** {why}  •  **CONFLICT/CAUTION:** {conflict}")

    # IV delta is deliberately on-demand. Reading bounded persisted history is
    # presentation work and must never become part of the One-Brain refresh path.
    iv_payload = None
    if st.session_state.get("iv_delta_snapshot_id") == snapshot.snapshot_id:
        cached = st.session_state.get("iv_delta_payload")
        if isinstance(cached, dict):
            iv_payload = cached
    iv_cols = st.columns([1, 2])
    if iv_cols[0].button(
        "⚡ Load IV Δ",
        key="load_iv_delta_display_only",
        help="Existing saved option snapshots only. No Dhan/API call and no One-Brain score impact.",
        width="stretch",
    ):
        with st.spinner("Saved IV history compare ho rahi hai — broker call nahi ho rahi..."):
            current_state = (getattr(snapshot, "metadata", {}) or {}).get("option_state_snapshot") or {}
            if option_state_store is None or not snapshot.expiry or not current_state:
                iv_payload = {
                    "status": "UNAVAILABLE",
                    "message": "Saved option history unavailable for IV Δ.",
                    "windows": [],
                    "preferred_window": None,
                    "preferred_strikes": {},
                }
            else:
                try:
                    history = option_state_store.load_session(
                        captured_at=snapshot.created_at, expiry=str(snapshot.expiry)
                    )
                    iv_payload = compute_iv_delta_payload(
                        current_snapshot=current_state, history=history
                    )
                except Exception as exc:
                    iv_payload = {
                        "status": "UNAVAILABLE",
                        "message": f"IV history read failed: {exc}",
                        "windows": [],
                        "preferred_window": None,
                        "preferred_strikes": {},
                    }
        st.session_state.iv_delta_payload = iv_payload
        st.session_state.iv_delta_snapshot_id = snapshot.snapshot_id
    iv_cols[1].caption(
        "IV Δ default OFF hai. Click par hi saved history se 1m/3m/5m change niklega; "
        "core calculation aur broker/API path untouched rehta hai."
    )

    iv_by_window = {}
    if isinstance(iv_payload, dict):
        iv_by_window = {
            str(row.get("label")): row
            for row in (iv_payload.get("windows") or [])
            if isinstance(row, dict)
        }
        iv_rows = []
        for label in ("1m", "3m", "5m"):
            row = iv_by_window.get(label) or {}
            def _iv_text(value):
                try:
                    return f"{float(value):+.2f} pts"
                except (TypeError, ValueError):
                    return "—"
            age = row.get("actual_age_seconds")
            iv_rows.append({
                "Window": label,
                "CE IV Δ": _iv_text(row.get("ce_iv_delta")),
                "PE IV Δ": _iv_text(row.get("pe_iv_delta")),
                "Actual age": f"{float(age):.0f}s" if age is not None else "—",
                "Matched": int(row.get("matched_rows") or 0),
                "Status": row.get("status") or "WARMING UP",
            })
        st.dataframe(pd.DataFrame(iv_rows), width="stretch", hide_index=True, row_height=32)
        preferred = iv_payload.get("preferred_window")
        if preferred:
            st.caption(
                f"IV Δ strike-board reference: {preferred}. Values volatility-point change hain, "
                "direction/profit probability nahi."
            )
        else:
            st.caption(str(iv_payload.get("message") or "IV history warming up."))

    # Compact flow-window strip: enough information for live audit without
    # opening another tab. Values are exactly those already computed in the
    # canonical OptionIntelligence object.
    flow_rows = []
    for w in item.windows:
        row = {
            "Window": w.label,
            "CE OI Δ": w.ce_oi_delta,
            "PE OI Δ": w.pe_oi_delta,
            "CE Prem Δ": w.ce_premium_delta,
            "PE Prem Δ": w.pe_premium_delta,
            "CE Vol Δ": w.ce_volume_delta,
            "PE Vol Δ": w.pe_volume_delta,
            "Bias": w.bias,
            "Status": w.status,
        }
        iv_window = iv_by_window.get(str(w.label)) or {}
        if iv_payload is not None:
            row["CE IV Δ"] = iv_window.get("ce_iv_delta")
            row["PE IV Δ"] = iv_window.get("pe_iv_delta")
        flow_rows.append(row)
    if flow_rows:
        st.dataframe(pd.DataFrame(flow_rows), width="stretch", hide_index=True, row_height=34)

    # Normalize both sides into one broker-style strike matrix.
    work = chain.copy()
    for col in ("strike", "last_price", "oi", "day_oi_change", "volume", "day_price_change", "top_bid_price", "top_ask_price", "implied_volatility", "delta", "theta"):
        if col not in work.columns:
            work[col] = None
    work["side"] = work["side"].astype(str).str.upper()

    ce = work[work["side"] == "CE"].copy()
    pe = work[work["side"] == "PE"].copy()
    ce = ce.sort_values("strike").drop_duplicates("strike", keep="last")
    pe = pe.sort_values("strike").drop_duplicates("strike", keep="last")

    strikes = sorted(set(ce["strike"].dropna().tolist()) | set(pe["strike"].dropna().tolist()))
    if not strikes:
        st.info("No strike rows available in the current snapshot.")
        return

    # Keep the active window compact. The current source normally carries 15
    # strikes; if it grows later, show ATM +/- 7 to avoid turning this board into
    # a long scrolling diagnostic table.
    spot = float((snapshot.nifty_quote or {}).get("last_price") or 0.0)
    atm = min(strikes, key=lambda x: abs(float(x) - spot)) if spot else strikes[len(strikes)//2]
    focus_tags = smart_focus_tags(snapshot, atm=float(atm))
    atm_idx = strikes.index(atm)
    lo = max(0, atm_idx - 7)
    hi = min(len(strikes), atm_idx + 8)
    visible_strikes = strikes[lo:hi]

    ce_map = {float(r["strike"]): r for _, r in ce.iterrows()}
    pe_map = {float(r["strike"]): r for _, r in pe.iterrows()}

    def price(value):
        if value is None or pd.isna(value):
            return "—"
        try:
            return f"{float(value):,.2f}"
        except (TypeError, ValueError):
            return "—"

    def qty(value, *, signed=False):
        if value is None or pd.isna(value):
            return "—"
        try:
            val = float(value)
        except (TypeError, ValueError):
            return "—"
        sign = "+" if signed and val > 0 else ("-" if val < 0 else "")
        abs_val = abs(val)
        if abs_val >= 10_000_000:
            body = f"{abs_val / 10_000_000:.2f}Cr"
        elif abs_val >= 100_000:
            body = f"{abs_val / 100_000:.2f}L"
        elif abs_val >= 1_000:
            body = f"{abs_val / 1_000:.1f}K"
        else:
            body = f"{abs_val:.0f}"
        return f"{sign}{body}"

    def greek(value, digits=3):
        if value is None or pd.isna(value):
            return "—"
        try:
            return f"{float(value):.{digits}f}"
        except (TypeError, ValueError):
            return "—"

    iv_preferred_label = str((iv_payload or {}).get("preferred_window") or "")
    iv_strikes = (iv_payload or {}).get("preferred_strikes") or {}
    ce_iv_delta = iv_strikes.get("CE") or {} if isinstance(iv_strikes, dict) else {}
    pe_iv_delta = iv_strikes.get("PE") or {} if isinstance(iv_strikes, dict) else {}

    rows = []
    for strike in visible_strikes:
        c = ce_map.get(float(strike), {})
        p = pe_map.get(float(strike), {})
        row = {
            "CE OI": qty(c.get("oi")),
            "CE OI Δ": qty(c.get("day_oi_change"), signed=True),
            "CE VOL": qty(c.get("volume")),
            "CE IV": greek(c.get("implied_volatility"), 2),
            "CE Delta": greek(c.get("delta"), 3),
            "CE Theta": greek(c.get("theta"), 2),
            "CE LTP": price(c.get("last_price")),
            "STRIKE": f"{float(strike):,.0f}" + ("  ◀ ATM" if float(strike) == float(atm) else ""),
            "FOCUS": " · ".join(focus_tags.get(float(strike), ())) or "—",
            "PE LTP": price(p.get("last_price")),
            "PE Theta": greek(p.get("theta"), 2),
            "PE Delta": greek(p.get("delta"), 3),
            "PE IV": greek(p.get("implied_volatility"), 2),
            "PE VOL": qty(p.get("volume")),
            "PE OI Δ": qty(p.get("day_oi_change"), signed=True),
            "PE OI": qty(p.get("oi")),
        }
        if iv_payload is not None and iv_preferred_label:
            row[f"CE IV Δ ({iv_preferred_label})"] = greek(ce_iv_delta.get(float(strike)), 2)
            row[f"PE IV Δ ({iv_preferred_label})"] = greek(pe_iv_delta.get(float(strike)), 2)
        rows.append(row)
    frame = pd.DataFrame(rows)

    ce_columns = {col for col in frame.columns if str(col).startswith("CE ")}
    pe_columns = {col for col in frame.columns if str(col).startswith("PE ")}

    def board_style(data: pd.DataFrame) -> pd.DataFrame:
        styles = pd.DataFrame("", index=data.index, columns=data.columns)
        for col in ce_columns:
            if col in styles:
                styles[col] = "background-color: rgba(34,197,94,.055)"
        for col in pe_columns:
            if col in styles:
                styles[col] = "background-color: rgba(239,68,68,.055)"
        if "STRIKE" in styles:
            styles["STRIKE"] = "background-color: rgba(245,158,11,.08);font-weight:700"
        if "FOCUS" in styles:
            styles["FOCUS"] = "background-color: rgba(59,130,246,.06);font-weight:650"
        for idx in data.index:
            if "ATM" in str(data.at[idx, "STRIKE"]):
                styles.loc[idx, :] = "background-color: rgba(245,158,11,.20);font-weight:800"
        return styles

    styled = frame.style.apply(board_style, axis=None)
    st.dataframe(styled, width="stretch", hide_index=True, row_height=31)
    spot_line = f"Spot {spot:,.2f} • ATM {float(atm):,.0f}"
    if ce_wall.strike is not None:
        spot_line += f" • CE wall {ce_wall.strike:,.0f}"
    if pe_wall.strike is not None:
        spot_line += f" • PE wall {pe_wall.strike:,.0f}"
    st.caption(spot_line)
    active_focus = [f"{strike:,.0f}: {' / '.join(tags)}" for strike, tags in sorted(focus_tags.items()) if strike in {float(x) for x in visible_strikes}]
    if active_focus:
        st.caption("🎯 Smart Focus: " + " | ".join(active_focus))
    st.caption(
        "Smart Focus display-only hai; ATM, existing walls/clusters aur already-computed protected-plan strikes ko mark karta hai. "
        "Board/One-Brain/strategy score, Greeks aur broker requests duplicate nahi hote. "
        "IV Δ bhi explicit click par saved history se load hota hai; default refresh cost zero rakhi gayi hai. "
        "Advanced detail neeche optional panel me available hai."
    )


def render_heavyweight_intelligence(snapshot: MarketSnapshot) -> None:
    item = snapshot.heavyweights
    st.info(f"Recent combined: {item.recent_state} · 15m {item.recent_15m_move_pct}% · 3m {item.recent_3m_move_pct}%")
    st.caption(f"Estimated 15m Nifty contribution {item.recent_contribution_points} points; data coverage {item.recent_coverage_pct}/{item.covered_weight_pct}% index weight; weights dated {item.weight_date}.")
    remaining_move = (
        f"{item.estimated_remaining_move_pct:+.3f}%"
        if item.estimated_remaining_move_pct is not None
        else "— · Data kam"
    )
    st.info(
        f"**Top-9:** {item.state} • Move {item.weighted_move_pct or 0:+.3f}% • "
        f"{item.advancing}↑/{item.declining}↓/{item.unchanged}→ • Data coverage {item.confidence:.0f}%"
    )
    if "DISAGREEMENT" in item.market_disagreement and "NO CLEAR" not in item.market_disagreement:
        st.warning(f"⚠️ **Market disagreement:** {item.market_disagreement} — confidence kam rakho")
    st.caption(
        f"Remaining Market ({item.remaining_weight_pct:.2f}% weight) estimated move: {remaining_move} · "
        "NIFTY actual move minus Top-9 contribution se nikla; extra 41 quote calls nahi."
    )
    rows = [asdict(row) for row in item.rows]
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)


def render_market_context(snapshot: MarketSnapshot) -> None:
    institutional = snapshot.institutional_context
    event = snapshot.event_risk
    c1, c2, c3, c4 = st.columns(4)
    c1.metric(
        "Latest FII cash ₹ cr",
        f"{institutional.latest_fii_net:,.1f}"
        if institutional.latest_fii_net is not None
        else "Missing",
    )
    c2.metric(
        "Latest DII cash ₹ cr",
        f"{institutional.latest_dii_net:,.1f}"
        if institutional.latest_dii_net is not None
        else "Missing",
    )
    c3.metric(
        "FII Futures contracts",
        f"{institutional.latest_fii_index_futures_contracts:,.0f}"
        if institutional.latest_fii_index_futures_contracts is not None
        else "Missing",
    )
    futures_split = (
        f"Long {institutional.latest_fii_futures_long_pct:.2f}% | Short {institutional.latest_fii_futures_short_pct:.2f}%"
        if institutional.latest_fii_futures_long_pct is not None
        and institutional.latest_fii_futures_short_pct is not None
        else "Long/Short missing"
    )
    c4.metric("FII Futures Bias", institutional.fii_futures_bias, delta=futures_split, delta_color="off")
    event_text = event.level if event.verified else "Unverified • Weight 0%"
    st.info(f"**Institutional:** {institutional.state} • **Event:** {event_text}")
    rows = [
        {
            "Window": "5 sessions",
            "FII cash net ₹ cr": institutional.fii_5d_net,
            "DII cash net ₹ cr": institutional.dii_5d_net,
            "FII Futures Long avg %": institutional.fii_futures_5d_long_avg_pct,
            "FII Futures Short avg %": institutional.fii_futures_5d_short_avg_pct,
        },
        {
            "Window": "10 sessions",
            "FII cash net ₹ cr": institutional.fii_10d_net,
            "DII cash net ₹ cr": institutional.dii_10d_net,
            "FII Futures Long avg %": institutional.fii_futures_10d_long_avg_pct,
            "FII Futures Short avg %": institutional.fii_futures_10d_short_avg_pct,
        },
        {
            "Window": "15 sessions",
            "FII cash net ₹ cr": institutional.fii_15d_net,
            "DII cash net ₹ cr": institutional.dii_15d_net,
            "FII Futures Long avg %": institutional.fii_futures_15d_long_avg_pct,
            "FII Futures Short avg %": institutional.fii_futures_15d_short_avg_pct,
        },
    ]
    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)
    _inst_age = ""
    if institutional.as_of_date:
        try:
            _as_of = datetime.fromisoformat(str(institutional.as_of_date)).date()
            _snapshot_day = snapshot.created_at.date()
            _days_old = max(0, (_snapshot_day - _as_of).days)
            _inst_age = f" · {_days_old} calendar day{'s' if _days_old != 1 else ''} old"
        except (TypeError, ValueError):
            _inst_age = ""
    st.write(
        f"**Institutional status:** {institutional.status} | "
        f"**Observations:** {institutional.observations}/15 | "
        f"**As of:** {institutional.as_of_date or '—'}{_inst_age} | "
        f"**Confidence:** {institutional.confidence:.1f}%"
    )


def render_vix_context(snapshot: MarketSnapshot) -> None:
    item = snapshot.vix_context
    c1, c2, c3, c4 = st.columns(4)
    c1.metric(
        "India VIX", f"{item.last_price:.2f}" if item.last_price is not None else "—"
    )
    c2.metric(
        "VIX Change",
        f"{item.change_pct:+.2f}%" if item.change_pct is not None else "—",
    )
    c3.metric("VIX Regime", item.regime)
    c4.metric("Movement", item.movement)
    message = (
        f"**Seller environment:** {item.seller_environment} | **Status:** {item.status}"
    )
    if item.status != "READY":
        st.warning(
            f"{message} — zero or missing VIX is treated as unavailable, never as a "
            "balanced premium environment."
        )
    else:
        st.info(message)
