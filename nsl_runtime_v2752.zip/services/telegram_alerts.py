from __future__ import annotations

import json
import os
import threading
from collections import deque
import time
from datetime import datetime, time as clock_time
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

from services.live_monitor import LiveImpulse, calculate_live_impulse_from_changes


IST = ZoneInfo("Asia/Kolkata")


def _market_hours(now: datetime) -> bool:
    local = now.astimezone(IST)
    return local.weekday() < 5 and clock_time(9, 15) <= local.time() <= clock_time(15, 30)


class TelegramNotifier:
    def __init__(self) -> None:
        self.bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
        self.enabled = os.getenv("TELEGRAM_ALERTS_ENABLED", "1").strip().lower() not in {
            "0",
            "false",
            "off",
            "no",
        }


    @property
    def configured(self) -> bool:
        return bool(self.enabled and self.bot_token and self.chat_id)

    def send(self, text: str) -> None:
        if not self.configured:
            raise RuntimeError("Telegram bot token or chat ID is missing")
        body = urlencode(
            {
                "chat_id": self.chat_id,
                "text": str(text)[:4000],
                "disable_web_page_preview": "true",
            }
        ).encode("utf-8")
        request = Request(
            f"https://api.telegram.org/bot{self.bot_token}/sendMessage",
            data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with urlopen(request, timeout=5.0) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if not payload.get("ok"):
            raise RuntimeError(str(payload.get("description") or "Telegram send failed"))


class LiveAlertEngine:
    """Deduplicated live-speed alerts; never places or recommends an order."""

    def __init__(
        self,
        notifier: TelegramNotifier | None = None,
        *,
        confirmations: int = 2,
        cooldown_seconds: int = 180,
        sender: Callable[[str], None] | None = None,
        async_delivery: bool = True,
    ) -> None:
        self.notifier = notifier or TelegramNotifier()
        self.confirmations = max(2, int(confirmations))
        self.cooldown_seconds = max(30, int(cooldown_seconds))
        self._sender = sender or self.notifier.send
        self.async_delivery = bool(async_delivery)
        self._lock = threading.Lock()
        self._candidate = ""
        self._candidate_count = 0
        self._last_sent: dict[str, float] = {}
        self.last_alert_at: float | None = None
        self.last_alert = ""
        self.last_error = ""
        self.alert_count = 0
        # Alert audit is deliberately isolated from the real-time decision path.
        # Delivery threads append a tiny bounded record *after* network delivery;
        # no broker call or market calculation is added here.
        self._history_lock = threading.Lock()
        self._history: deque[dict[str, Any]] = deque(maxlen=200)
        self._dedupe_path: Path | None = None
        self._history_path: Path | None = None
        mount = os.getenv("RAILWAY_VOLUME_MOUNT_PATH", "").strip()
        if mount:
            root = Path(mount) / "nifty_day_memory"
            self._dedupe_path = root / "telegram_dedupe.json"
            self._history_path = root / "telegram_alert_history.json"
            self._load_dedupe_state()
            self._load_alert_history()

    def _load_dedupe_state(self) -> None:
        """Restore only recent alert fingerprints; tiny file, no market work."""
        if self._dedupe_path is None:
            return
        try:
            payload = json.loads(self._dedupe_path.read_text(encoding="utf-8"))
            now = time.time()
            raw = payload.get("last_sent") if isinstance(payload, dict) else {}
            if isinstance(raw, dict):
                self._last_sent.update({
                    str(k): float(v) for k, v in raw.items()
                    if now - float(v) <= 6 * 3600
                })
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return

    def _persist_dedupe_state(self) -> None:
        if self._dedupe_path is None:
            return
        try:
            self._dedupe_path.parent.mkdir(parents=True, exist_ok=True)
            now = time.time()
            recent = {k: v for k, v in self._last_sent.items() if now - float(v) <= 6 * 3600}
            tmp = self._dedupe_path.with_suffix(".tmp")
            tmp.write_text(json.dumps({"last_sent": recent}, separators=(",", ":")), encoding="utf-8")
            tmp.replace(self._dedupe_path)
        except OSError:
            pass

    def _load_alert_history(self) -> None:
        if self._history_path is None:
            return
        try:
            payload = json.loads(self._history_path.read_text(encoding="utf-8"))
            if isinstance(payload, list):
                for row in payload[-200:]:
                    if isinstance(row, dict):
                        self._history.append(dict(row))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return

    def _append_alert_history(self, row: dict[str, Any]) -> None:
        """Append bounded audit data from a delivery thread, never market logic."""
        clean = {str(k): v for k, v in row.items() if v is not None}
        with self._history_lock:
            self._history.append(clean)
            if self._history_path is None:
                return
            try:
                self._history_path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self._history_path.with_suffix(".tmp")
                tmp.write_text(json.dumps(list(self._history), separators=(",", ":")), encoding="utf-8")
                tmp.replace(self._history_path)
            except OSError:
                pass

    def alert_history(self, limit: int = 50) -> list[dict[str, Any]]:
        """Read-only recent delivery audit. No market/API work is performed."""
        count = max(1, min(200, int(limit)))
        with self._history_lock:
            rows = list(self._history)[-count:]
        return [dict(row) for row in reversed(rows)]

    @property
    def configured(self) -> bool:
        return self.notifier.configured

    @staticmethod
    def _message(impulse: LiveImpulse, ltp: float | None) -> str:
        icon = "🟢" if impulse.direction == "BULLISH" else "🔴"
        title = "MAJOR MOVE" if impulse.state == "MAJOR MOVE CONFIRMED" else "FAST MOVE"
        lines = [
            f"{icon} NIFTY {title} — {impulse.direction}",
            f"Speed score: {impulse.score:.0f}/100",
        ]
        if ltp is not None:
            lines.append(f"NIFTY: {ltp:,.2f}")
        if impulse.reasons:
            lines.append(" | ".join(impulse.reasons[:4]))
        lines.extend(
            (
                "Status: Early warning — One-Brain confirmation alag se check karein.",
                "Automatic order nahi lagaya gaya.",
            )
        )
        return "\n".join(lines)

    def observe(
        self,
        *,
        changes: dict[int, float | None],
        ltp: float | None,
        now_ts: float | None = None,
        enforce_market_hours: bool = True,
    ) -> bool:
        timestamp = float(now_ts if now_ts is not None else time.time())
        if enforce_market_hours and not _market_hours(datetime.fromtimestamp(timestamp, IST)):
            return False
        impulse = calculate_live_impulse_from_changes(changes)
        qualified = (
            impulse.direction in {"BULLISH", "BEARISH"}
            and (
                impulse.state == "MAJOR MOVE CONFIRMED"
                or (impulse.state == "FAST MOVE WATCH" and impulse.score >= 55)
            )
        )
        with self._lock:
            if not qualified:
                self._candidate = ""
                self._candidate_count = 0
                return False
            signature = f"{impulse.direction}:{impulse.state}"
            if signature == self._candidate:
                self._candidate_count += 1
            else:
                self._candidate = signature
                self._candidate_count = 1
            if self._candidate_count < self.confirmations:
                return False
            if timestamp - self._last_sent.get(signature, 0.0) < self.cooldown_seconds:
                return False
            self._last_sent[signature] = timestamp
            self._candidate_count = 0

        message = self._message(impulse, ltp)
        if self.async_delivery:
            threading.Thread(
                target=self._deliver,
                args=(message, signature, timestamp),
                daemon=True,
                name="telegram-alert-send",
            ).start()
            return True
        return self._deliver(message, signature, timestamp)

    def _deliver(self, message: str, signature: str, timestamp: float) -> bool:
        delivered_at = time.time()
        try:
            self._sender(message)
            delivered_at = time.time()
            with self._lock:
                self.last_alert_at = timestamp
                self.last_alert = signature
                self.last_error = ""
                self.alert_count += 1
            self._append_alert_history({
                "kind": "FAST_MOVE", "status": "SENT", "signature": signature,
                "generated_at": datetime.fromtimestamp(timestamp, IST).isoformat(),
                "delivered_at": datetime.fromtimestamp(delivered_at, IST).isoformat(),
                "latency_seconds": round(max(0.0, delivered_at - timestamp), 3),
                "message": message[:500],
            })
            return True
        except Exception as exc:
            failed_at = time.time()
            with self._lock:
                self.last_error = str(exc)[:300]
            self._append_alert_history({
                "kind": "FAST_MOVE", "status": "FAILED", "signature": signature,
                "generated_at": datetime.fromtimestamp(timestamp, IST).isoformat(),
                "delivered_at": datetime.fromtimestamp(failed_at, IST).isoformat(),
                "latency_seconds": round(max(0.0, failed_at - timestamp), 3),
                "error": type(exc).__name__,
            })
            return False

    def send_test(self) -> None:
        self._sender(
            "✅ Nifty Seller Lite Telegram alert connected.\n"
            "Railway server se test message successful hai.\n"
            "Automatic order kabhi place nahi hoga."
        )

    def observe_pattern(self, payload: dict[str, Any], now_ts: float | None = None) -> bool:
        timestamp = time.time() if now_ts is None else now_ts
        if not _market_hours(datetime.fromtimestamp(timestamp, IST)):
            return False
        try:
            stamp = datetime.fromisoformat(str(payload["captured_at"]))
            if not 0 <= timestamp - stamp.timestamp() <= 120:
                return False
        except (KeyError, ValueError, TypeError):
            return False
        ids = payload.get("pattern_ids")
        if payload.get("direction") not in {"BULLISH", "BEARISH"} or not isinstance(ids, list) or not 1 <= len(ids) <= 4:
            return False
        signatures = ["pattern:" + stamp.date().isoformat() + ":" + str(x)[:180] for x in ids]
        message = str(payload.get("message", "Strong aligned pattern confirmation"))[:1800]
        with self._lock:
            if all(x in self._last_sent for x in signatures):
                return False
            # Reserve fingerprints *before* network delivery. This prevents two
            # Streamlit reruns from ringing twice while keeping Telegram I/O off
            # the app's critical path. Failed sends remove the reservation so a
            # later rerun can retry.
            for signature in signatures:
                self._last_sent[signature] = timestamp
            self._persist_dedupe_state()

        audit = {
            "kind": str(payload.get("kind") or "COMBINED_SIGNAL")[:80],
            "captured_at": str(payload.get("captured_at") or ""),
            "direction": str(payload.get("direction") or ""),
            "names": str(payload.get("names") or "")[:300],
            "conflict": bool(payload.get("conflict")),
            "nifty_ltp": payload.get("nifty_ltp"),
            "big_player": payload.get("big_player") if isinstance(payload.get("big_player"), dict) else None,
            "generated_at": datetime.fromtimestamp(timestamp, IST).isoformat(),
        }
        if self.async_delivery:
            threading.Thread(
                target=self._deliver_pattern,
                args=(message, signatures, timestamp, audit),
                daemon=True,
                name="telegram-pattern-send",
            ).start()
            return True
        return self._deliver_pattern(message, signatures, timestamp, audit)

    def observe_market_intelligence(self, payload: dict[str, Any], now_ts: float | None = None) -> bool:
        """Send one deduplicated OB-MIE shadow alert, including direction-unclear expansion.

        The caller has already calculated market intelligence from an authoritative
        snapshot.  This method performs delivery only; it never fetches market data.
        """
        timestamp = time.time() if now_ts is None else now_ts
        if not _market_hours(datetime.fromtimestamp(timestamp, IST)):
            return False
        try:
            stamp = datetime.fromisoformat(str(payload["captured_at"]))
            if not 0 <= timestamp - stamp.timestamp() <= 120:
                return False
        except (KeyError, ValueError, TypeError):
            return False
        direction = str(payload.get("direction") or "MIXED").upper()
        if direction not in {"BULLISH", "BEARISH", "MIXED"}:
            return False
        alert_id = str(payload.get("alert_id") or "").strip()[:180]
        if not alert_id:
            return False
        signature = "mie:" + stamp.date().isoformat() + ":" + alert_id
        message = str(payload.get("message") or "Market Intelligence alert")[:1800]
        with self._lock:
            if signature in self._last_sent:
                return False
            self._last_sent[signature] = timestamp
            self._persist_dedupe_state()
        audit = {
            "kind": "MARKET_INTELLIGENCE",
            "captured_at": str(payload.get("captured_at") or ""),
            "direction": direction,
            "names": str(payload.get("title") or payload.get("kind") or "OB-MIE")[:300],
            "conflict": str(payload.get("kind") or "") == "SYSTEM_CONFLICT",
            "nifty_ltp": payload.get("nifty_ltp"),
            "generated_at": datetime.fromtimestamp(timestamp, IST).isoformat(),
            "market_intelligence": {
                "kind": str(payload.get("kind") or "")[:80],
                "score": payload.get("score"),
                "coverage": payload.get("coverage"),
                "alignment": str(payload.get("alignment") or "")[:100],
                "liquidity_bias": str(payload.get("liquidity_bias") or "")[:40],
                "liquidity_target": payload.get("liquidity_target") if isinstance(payload.get("liquidity_target"), dict) else None,
                "sweep_outcome": str(payload.get("sweep_outcome") or "")[:80],
            },
        }
        if self.async_delivery:
            threading.Thread(
                target=self._deliver_pattern,
                args=(message, [signature], timestamp, audit),
                daemon=True,
                name="telegram-market-intelligence-send",
            ).start()
            return True
        return self._deliver_pattern(message, [signature], timestamp, audit)

    def _deliver_pattern(
        self, message: str, signatures: list[str], timestamp: float, audit: dict[str, Any] | None = None
    ) -> bool:
        try:
            self._sender(message)
            delivered_at = time.time()
            with self._lock:
                self.alert_count += 1
                self.last_alert = signatures[0] if signatures else "pattern"
                self.last_alert_at = timestamp
                self.last_error = ""
            self._append_alert_history({
                **(audit or {"kind": "COMBINED_SIGNAL"}),
                "status": "SENT",
                "signature": signatures[0] if signatures else "pattern",
                "delivered_at": datetime.fromtimestamp(delivered_at, IST).isoformat(),
                "latency_seconds": round(max(0.0, delivered_at - timestamp), 3),
                "message": message[:700],
            })
            return True
        except Exception as exc:
            failed_at = time.time()
            with self._lock:
                for signature in signatures:
                    if self._last_sent.get(signature) == timestamp:
                        self._last_sent.pop(signature, None)
                self.last_error = str(exc)[:300]
                self._persist_dedupe_state()
            self._append_alert_history({
                **(audit or {"kind": "COMBINED_SIGNAL"}),
                "status": "FAILED",
                "signature": signatures[0] if signatures else "pattern",
                "delivered_at": datetime.fromtimestamp(failed_at, IST).isoformat(),
                "latency_seconds": round(max(0.0, failed_at - timestamp), 3),
                "error": type(exc).__name__,
            })
            return False

    def status(self) -> dict[str, Any]:
        with self._lock:
            return {
                "configured": self.configured,
                "alert_count": self.alert_count,
                "last_alert": self.last_alert or None,
                "last_alert_age_seconds": (
                    round(time.time() - self.last_alert_at, 1)
                    if self.last_alert_at is not None
                    else None
                ),
                "last_error": self.last_error,
                "confirmations_required": self.confirmations,
                "cooldown_seconds": self.cooldown_seconds,
            }
