from __future__ import annotations

from datetime import datetime
from html import escape
from io import BytesIO
import json
from typing import Any, Iterable, Sequence
from zipfile import ZIP_DEFLATED, ZipFile

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from analysis.evidence_matrix import build_compact_evidence_matrix, build_module_impact_audit
from analysis.presentation_safety import safe_brain_hinglish_line, simple_core_block_coverage, future_brain_display_label
from config import CONFIG
from models import MarketSnapshot
from services.summary_presenter import (
    best_existing_candidate,
    direction_evidence_score,
    plan_leg_text,
    required_live_feed_state,
)


_PAGE_SIZE = landscape(A4)
_DARK = colors.HexColor("#223047")
_BLUE = colors.HexColor("#DCE8F7")
_LIGHT = colors.HexColor("#F4F6F8")
_WARN = colors.HexColor("#FFF2CC")
_RED = colors.HexColor("#FCE8E6")
_GREEN = colors.HexColor("#E6F4EA")
_GRID = colors.HexColor("#AEB7C2")


def _text(value: Any, decimals: int = 2) -> str:
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "YES" if value else "NO"
    if isinstance(value, (datetime, pd.Timestamp)):
        return value.isoformat()
    if isinstance(value, float):
        if pd.isna(value):
            return "-"
        return f"{value:,.{decimals}f}"
    return str(value)


def _pct(value: Any) -> str:
    if value is None:
        return "-"
    try:
        return f"{float(value):.1f}%"
    except (TypeError, ValueError):
        return str(value)


def _operational_view(snapshot: MarketSnapshot) -> dict[str, Any]:
    """Presentation-safe Simple One-Brain view with legacy fallback."""
    metadata = getattr(snapshot, "metadata", {}) or {}
    simple = metadata.get("simple_brain") or {}
    common = metadata.get("common_decision") or {}
    decision = snapshot.decision
    action = str(common.get("final_action") or simple.get("final_action") or decision.final_action or "WAIT")
    direction = str(simple.get("direction") or common.get("direction") or getattr(decision, "market_direction", "MIXED") or "MIXED")
    entry = float(simple.get("entry_readiness") or common.get("trade_confidence") or decision.decision_confidence or 0.0)
    strength = float(simple.get("direction_strength") or direction_evidence_score(snapshot) or 0.0)
    return {
        "action": action,
        "direction": direction,
        "direction_strength": strength,
        "entry_readiness": entry,
        "regime": str(simple.get("regime") or "LEGACY"),
        "entry_state": str(simple.get("entry_state") or ("READY" if common.get("entry_allowed") else "WAIT")),
        "candidate": str(simple.get("candidate_action") or common.get("best_strategy") or action),
        "trigger": str(simple.get("trigger") or simple.get("instruction") or "-"),
        "risk_notes": tuple(simple.get("risk_notes") or ()),
        "next_level": simple.get("next_level"),
        "blocks": simple.get("blocks") or {},
        "simple": simple,
    }


def _paragraph(value: Any, style: ParagraphStyle) -> Paragraph:
    text = escape(_text(value)).replace("\n", "<br/>")
    return Paragraph(text, style)


def _bullet_lines(values: Iterable[Any]) -> str:
    cleaned = [_text(value) for value in values if _text(value).strip()]
    return "\n".join(f"- {value}" for value in cleaned) if cleaned else "- None"


def _table(
    headers: Sequence[str],
    rows: Sequence[Sequence[Any]],
    *,
    widths: Sequence[float] | None = None,
    compact: bool = False,
    header_background: colors.Color = _DARK,
) -> Table:
    styles = _styles()
    body_style = styles["Small"] if compact else styles["Body"]
    header_style = styles["TableHeader"]
    data: list[list[Any]] = [[_paragraph(header, header_style) for header in headers]]
    for row in rows:
        data.append([_paragraph(value, body_style) for value in row])
    table = Table(
        data,
        colWidths=list(widths) if widths else None,
        repeatRows=1,
        hAlign="LEFT",
        splitByRow=1,
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), header_background),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.35, _GRID),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, _LIGHT]),
            ]
        )
    )
    return table


def _styles() -> dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()
    return {
        "Title": ParagraphStyle(
            "AuditTitle",
            parent=base["Title"],
            fontName="Helvetica-Bold",
            fontSize=20,
            leading=24,
            alignment=TA_CENTER,
            textColor=_DARK,
            spaceAfter=8,
        ),
        "Subtitle": ParagraphStyle(
            "AuditSubtitle",
            parent=base["Normal"],
            fontName="Helvetica",
            fontSize=9,
            leading=12,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#465568"),
            spaceAfter=10,
        ),
        "H1": ParagraphStyle(
            "AuditH1",
            parent=base["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=13,
            leading=16,
            textColor=_DARK,
            spaceBefore=8,
            spaceAfter=5,
            keepWithNext=True,
        ),
        "H2": ParagraphStyle(
            "AuditH2",
            parent=base["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=10,
            leading=13,
            textColor=_DARK,
            spaceBefore=6,
            spaceAfter=3,
            keepWithNext=True,
        ),
        "Body": ParagraphStyle(
            "AuditBody",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=7.5,
            leading=10,
            alignment=TA_LEFT,
            spaceAfter=3,
        ),
        "Small": ParagraphStyle(
            "AuditSmall",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=6.2,
            leading=8,
            alignment=TA_LEFT,
        ),
        "TableHeader": ParagraphStyle(
            "AuditTableHeader",
            parent=base["BodyText"],
            fontName="Helvetica-Bold",
            fontSize=6.6,
            leading=8,
            textColor=colors.white,
            alignment=TA_LEFT,
        ),
        "Callout": ParagraphStyle(
            "AuditCallout",
            parent=base["BodyText"],
            fontName="Helvetica-Bold",
            fontSize=9,
            leading=12,
            textColor=_DARK,
            spaceAfter=4,
        ),
        "Mono": ParagraphStyle(
            "AuditMono",
            parent=base["Code"],
            fontName="Courier",
            fontSize=5.2,
            leading=6.4,
            leftIndent=0,
            spaceAfter=2,
        ),
    }


def _section_title(text: str) -> Paragraph:
    return Paragraph(escape(text), _styles()["H1"])


def _sub_title(text: str) -> Paragraph:
    return Paragraph(escape(text), _styles()["H2"])


def _callout(text: str, background: colors.Color) -> Table:
    style = _styles()["Callout"]
    table = Table([[_paragraph(text, style)]], colWidths=[257 * mm])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), background),
                ("BOX", (0, 0), (-1, -1), 0.6, _GRID),
                ("LEFTPADDING", (0, 0), (-1, -1), 7),
                ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    return table


def _level_row(label: str, level: Any) -> list[Any]:
    if level is None:
        return [label, "-", "-", "-", "UNAVAILABLE", "-"]
    return [
        label,
        f"{level.lower:,.2f} - {level.upper:,.2f}",
        level.midpoint,
        level.distance_points,
        level.status,
        ", ".join(level.sources),
    ]


def _trade_leg_text(legs: Sequence[Any]) -> str:
    if not legs:
        return "-"
    return " + ".join(f"{leg.strike:,.0f} {leg.side} ({leg.role})" for leg in legs)


def _frame_rows(
    frame: pd.DataFrame, columns: Sequence[str], tail: int
) -> list[list[Any]]:
    if frame is None or frame.empty:
        return []
    available = [column for column in columns if column in frame.columns]
    result: list[list[Any]] = []
    for _, row in frame[available].tail(tail).iterrows():
        result.append([row.get(column) for column in available])
    return result


def _completed_audit_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Defensive report-only filter for rows already marked as completed."""

    if frame is None or frame.empty:
        return frame
    if "is_complete" not in frame.columns:
        return frame.iloc[0:0].copy()
    return frame.loc[frame["is_complete"].fillna(False).eq(True)].copy()


def _market_data_health(snapshot: MarketSnapshot) -> str:
    feed_ok, _ = required_live_feed_state(snapshot)
    if snapshot.market_session.is_live and feed_ok:
        return "MARKET DATA FRESH"
    if snapshot.market_session.is_live:
        return "MARKET DATA DELAYED / INCOMPLETE"
    return "LAST MARKET DATA - REFERENCE ONLY"


def _role_reversal_status(
    snapshot: MarketSnapshot,
    previous_snapshot: MarketSnapshot | None,
) -> tuple[str, bool] | None:
    if previous_snapshot is None:
        return None
    current = snapshot.barrier_map
    previous = previous_snapshot.barrier_map
    candidates = tuple(
        (old, new, old_side, new_side)
        for old_side, old_levels, new_side, new_levels in (
            ("SUPPORT", (previous.nearest_support, previous.next_support), "RESISTANCE", (current.nearest_resistance, current.next_resistance)),
            ("RESISTANCE", (previous.nearest_resistance, previous.next_resistance), "SUPPORT", (current.nearest_support, current.next_support)),
        )
        for old in old_levels
        for new in new_levels
    )
    completed = _completed_audit_frame(snapshot.candles_1m)
    required = {"high", "low", "close"}
    if completed is None or completed.empty or not required.issubset(completed.columns):
        completed = pd.DataFrame(columns=sorted(required))
    else:
        completed = completed.dropna(subset=sorted(required)).tail(12)
    for old, new, old_side, new_side in candidates:
        if old is None or new is None:
            continue
        lower = max(float(old.lower), float(new.lower))
        upper = min(float(old.upper), float(new.upper))
        if lower > upper:
            continue
        confirmed = False
        break_seen = False
        for _, candle in completed.iterrows():
            close = float(candle["close"])
            if new_side == "RESISTANCE" and close < lower:
                if break_seen and float(candle["high"]) >= lower:
                    confirmed = True
                    break
                break_seen = True
            elif new_side == "SUPPORT" and close > upper:
                if break_seen and float(candle["low"]) <= upper:
                    confirmed = True
                    break
                break_seen = True
        zone = f"{lower:,.0f}-{upper:,.0f}"
        label = "CONFIRMED ROLE REVERSAL" if confirmed else "POSSIBLE ROLE REVERSAL - RETEST PENDING"
        return f"{label}: Broken {old_side.title()} -> {new_side.title()} {zone}", confirmed
    return None


def _activity_report_rows(snapshot: MarketSnapshot) -> tuple[list[list[Any]], list[tuple[str, colors.Color]]]:
    item = snapshot.big_player_activity
    if item is None:
        return [["Unavailable", "-", "-", "-", "-", "No activity payload"]], []
    use_status = "LAST LIVE ACTIVITY - REFERENCE ONLY" if item.frozen_after_close else item.status
    rows = [[
        item.direction,
        f"{item.score:.1f}/100",
        f"{item.confirmation_count}/{item.confirmation_total}",
        f"{item.futures_volume_ratio:.2f}x" if item.futures_volume_ratio is not None else "-",
        f"{item.futures_oi_change_pct:+.2f}% | {item.futures_setup}" if item.futures_oi_change_pct is not None else item.futures_setup,
        use_status,
    ]]
    callouts: list[tuple[str, colors.Color]] = []
    if item.price_shock_state != "NONE":
        points = f"{abs(float(item.price_shock_points)):.1f} points" if item.price_shock_points is not None else "points unavailable"
        shock_label = item.price_shock_state if str(item.price_shock_state).startswith("PRICE SHOCK") else f"PRICE SHOCK {item.price_shock_state}"
        callouts.append((f"{shock_label}: completed spot move {points}. Participation confirmation remains separate.", _RED))
    if item.frozen_after_close:
        callouts.append(("LAST LIVE ACTIVITY - REFERENCE ONLY: post-close quote changes did not recalculate participation.", _WARN))
    return rows, callouts


def _page_decor(canvas: Any, document: Any, snapshot: MarketSnapshot) -> None:
    canvas.saveState()
    width, height = _PAGE_SIZE
    canvas.setStrokeColor(_GRID)
    canvas.setLineWidth(0.4)
    canvas.line(15 * mm, height - 12 * mm, width - 15 * mm, height - 12 * mm)
    canvas.setFont("Helvetica-Bold", 7)
    canvas.setFillColor(_DARK)
    canvas.drawString(
        15 * mm, height - 9 * mm, "Nifty Seller Lite - Full Live Audit Report"
    )
    canvas.setFont("Helvetica", 6.5)
    canvas.setFillColor(colors.HexColor("#566273"))
    canvas.drawRightString(
        width - 15 * mm,
        height - 9 * mm,
        f"Snapshot {snapshot.snapshot_id[-12:]} | {snapshot.created_at.strftime('%d-%m-%Y %H:%M:%S IST')}",
    )
    canvas.line(15 * mm, 11 * mm, width - 15 * mm, 11 * mm)
    canvas.drawString(
        15 * mm,
        7 * mm,
        "Decision-support only. Verify broker quotes, liquidity, margin and hedge before trading.",
    )
    canvas.drawRightString(width - 15 * mm, 7 * mm, f"Page {document.page}")
    canvas.restoreState()


def build_full_audit_pdf(snapshot: MarketSnapshot, previous_snapshot: MarketSnapshot | None = None) -> bytes:
    """Render the current authoritative snapshot without recalculating any strategy.

    The report reads the already-built MarketSnapshot. It does not call Dhan, mutate
    state, recalculate the Final One-Brain Decision or create a second prediction path.
    """

    styles = _styles()
    buffer = BytesIO()
    document = SimpleDocTemplate(
        buffer,
        pagesize=_PAGE_SIZE,
        rightMargin=15 * mm,
        leftMargin=15 * mm,
        topMargin=17 * mm,
        bottomMargin=15 * mm,
        title=f"Nifty Seller Lite Audit {snapshot.snapshot_id}",
        author="Nifty Seller Lite",
        subject="Live market decision audit",
        pageCompression=1,
    )
    story: list[Any] = []

    # Cover and immutable snapshot identity.
    story.append(Paragraph("Nifty Seller Lite", styles["Title"]))
    story.append(Paragraph("Full Live Audit Report", styles["Subtitle"]))
    snapshot_rows = [
        ["App version", CONFIG.version, "Snapshot ID", snapshot.snapshot_id],
        [
            "Created at",
            snapshot.created_at.isoformat(),
            "Session",
            snapshot.market_session.label,
        ],
        [
            "NIFTY",
            snapshot.nifty_quote.get("last_price"),
            "Expiry",
            snapshot.expiry or "-",
        ],
        [
            "Mode",
            "READ ONLY",
            "Final brain",
            "analysis/decision.py (single canonical brain)",
        ],
        [
            "Risk profile",
            f"Rs. {snapshot.risk_profile.capital_rupees:,.0f} at {snapshot.risk_profile.risk_pct:.2f}%",
            "Risk budget",
            f"Rs. {snapshot.risk_profile.risk_budget_rupees:,.2f}",
        ],
    ]
    story.append(
        _table(
            ["Field", "Value", "Field", "Value"],
            snapshot_rows,
            widths=[30 * mm, 92 * mm, 30 * mm, 105 * mm],
        )
    )
    story.append(Spacer(1, 4 * mm))
    session_color = _GREEN if snapshot.market_session.is_live else _WARN
    story.append(
        _callout(
            f"SESSION STATUS: {snapshot.market_session.label} - {snapshot.market_session.message}",
            session_color,
        )
    )
    story.append(Spacer(1, 3 * mm))
    story.append(
        Paragraph(
            "Audit rule: this PDF is a frozen rendering of the same MarketSnapshot shown on screen. "
            "It performs no API request and no independent CE/PE/Condor calculation.",
            styles["Body"],
        )
    )

    # Main AI is presentation-only: it condenses the existing canonical snapshot.
    story.append(_section_title("1. Main AI Market View"))
    feed_ok, feed_text = required_live_feed_state(snapshot)
    operational = _operational_view(snapshot)
    direction = operational["direction"]
    speed = snapshot.barrier_map.market_speed
    story.append(
        _table(
            ["NIFTY", "Direction", "Directional evidence", "Final action", "Entry readiness", "Market danger", "Data status"],
            [[
                snapshot.nifty_quote.get("last_price"),
                direction,
                f"{operational['direction_strength']:.1f}/100",
                operational["action"],
                f"{operational['entry_readiness']:.1f}/100",
                f"{speed.state} {speed.score:.1f}/100",
                _market_data_health(snapshot),
            ]],
            widths=[31 * mm, 30 * mm, 34 * mm, 34 * mm, 38 * mm, 50 * mm, 40 * mm],
            compact=True,
        )
    )
    story.append(Spacer(1, 2 * mm))
    story.append(
        _callout(
            "AI samajh: " + safe_brain_hinglish_line(snapshot, previous_snapshot),
            _BLUE,
        )
    )
    future = snapshot.metadata.get("future_brain") or {}
    if future:
        future_title, future_history_note = future_brain_display_label(future)
        story.append(_sub_title(future_title + " - Next 5 / 15 Minute"))
        story.append(Paragraph(future_history_note, styles["Small"]))
        story.append(_table(
            ["Transition", "5m UP/DOWN/RANGE", "15m UP/DOWN/RANGE", "Advisory", "History"],
            [[
                future.get("transition"),
                f"{future.get('up_5m')} / {future.get('down_5m')} / {future.get('range_5m')}",
                f"{future.get('up_15m')} / {future.get('down_15m')} / {future.get('range_15m')}",
                future.get("final_gate"),
                f"{future.get('historical_matches', 0)} matches - {future.get('historical_status')}",
            ]],
            widths=[50 * mm, 48 * mm, 48 * mm, 60 * mm, 52 * mm], compact=True,
        ))

    activity_rows, activity_callouts = _activity_report_rows(snapshot)
    story.append(_sub_title("Big Player Activity, Price Shock and Freeze Status"))
    story.append(
        _table(
            ["Activity", "Score", "Confirm", "Futures volume", "OI / setup", "Use status"],
            activity_rows,
            widths=[34 * mm, 26 * mm, 27 * mm, 34 * mm, 72 * mm, 60 * mm],
            compact=True,
        )
    )
    for message, color in activity_callouts:
        story.append(_callout(message, color))

    roadmap = snapshot.barrier_map
    r1 = roadmap.nearest_resistance
    s1 = roadmap.nearest_support
    range_item = roadmap.trading_range
    story.append(
        _table(
            ["Next resistance", "R strength / break", "Next support", "S strength / break", "Probable range", "Range conf.", "VIX context"],
            [[
                f"{r1.lower:,.0f}-{r1.upper:,.0f}" if r1 else "-",
                f"{r1.strength:.0f}/{r1.break_pressure:.0f}" if r1 else "-",
                f"{s1.lower:,.0f}-{s1.upper:,.0f}" if s1 else "-",
                f"{s1.strength:.0f}/{s1.break_pressure:.0f}" if s1 else "-",
                f"{range_item.lower:,.0f}-{range_item.upper:,.0f}" if range_item.lower is not None and range_item.upper is not None else "-",
                f"{range_item.confidence:.0f}/100",
                f"{roadmap.vix_risk}; daily +/-{roadmap.vix_expected_daily_move_points:.0f} pts" if roadmap.vix_expected_daily_move_points is not None else roadmap.vix_risk,
            ]],
            widths=[42 * mm, 34 * mm, 42 * mm, 34 * mm, 40 * mm, 27 * mm, 38 * mm],
            compact=True,
        )
    )

    candidate_name, candidate_score, candidate_plan, candidate_selected = best_existing_candidate(snapshot)
    if candidate_plan is not None and candidate_plan.available:
        candidate_status = candidate_plan.status if candidate_selected else "REFERENCE ONLY"
        story.append(
            _table(
                ["Protected setup", "Strategy suitability", "Sell", "Hedge", "Credit pts", "Max risk pts", "Strike+hedge quality", "Status"],
                [[
                    candidate_name,
                    _pct(candidate_score),
                    plan_leg_text(candidate_plan.short_legs),
                    plan_leg_text(candidate_plan.hedge_legs),
                    candidate_plan.estimated_credit_points,
                    candidate_plan.max_risk_points,
                    _pct(candidate_plan.quality_score),
                    candidate_status,
                ]],
                widths=[30 * mm, 25 * mm, 38 * mm, 38 * mm, 27 * mm, 30 * mm, 25 * mm, 44 * mm],
                compact=True,
            )
        )
        if _operational_view(snapshot)["action"] == "WAIT":
            story.append(Paragraph("Simple One-Brain Action is WAIT; protected setup above is reference-only, not an entry signal.", styles["Body"]))

    # Feed integrity.
    story.append(_section_title("2. Snapshot and Feed Integrity"))
    feed_rows = []
    for name, status in snapshot.feed_status.items():
        feed_rows.append(
            [
                name,
                "YES" if status.ok else "NO",
                status.use_state,
                _text(status.age_seconds, 1),
                status.message,
                status.source,
            ]
        )
    story.append(
        _table(
            ["Feed", "Available", "Use", "Age sec", "Message", "Source"],
            feed_rows,
            widths=[27 * mm, 20 * mm, 22 * mm, 19 * mm, 130 * mm, 39 * mm],
            compact=True,
        )
    )

    # Evidence and decision.
    op = _operational_view(snapshot)
    story.append(_section_title("3. Simple One-Brain + Background Evidence"))
    if op["simple"]:
        simple_rows = []
        for label, key in (("Trend / Regime", "trend"), ("Options Flow", "options"), ("Participation", "participation"), ("Barrier / Entry", "barrier_entry")):
            block = op["blocks"].get(key) or {}
            if key == "barrier_entry":
                detail = f"{block.get('state', '-')} | score {float(block.get('score') or 0):.1f} | {block.get('note', '-')}"
            else:
                availability = "READY" if block.get("available", True) else "UNAVAILABLE — NO VOTE"
                detail = f"{availability} | B/D/N {float(block.get('bullish') or 0):.1f}/{float(block.get('bearish') or 0):.1f}/{float(block.get('neutral') or 0):.1f}"
            simple_rows.append([label, f"{float(block.get('weight') or 0):.0f}%", detail])
        story.append(_table(["Core block", "Weight", "Current evidence"], simple_rows, widths=[55*mm, 28*mm, 164*mm], compact=True))
        story.append(_table(
            ["Regime", "Direction", "Direction strength", "Entry", "Action", "Trigger / next level"],
            [[op["regime"], op["direction"], f"{op['direction_strength']:.1f}/100", f"{op['entry_state']} {op['entry_readiness']:.1f}/100", op["action"], f"{op['trigger']} | next {op['next_level'] if op['next_level'] is not None else '-'}"]],
            widths=[45*mm, 30*mm, 34*mm, 55*mm, 32*mm, 62*mm], compact=True,
        ))
        if op["simple"].get("evidence_coverage") is not None:
            core_availability = simple_core_block_coverage(op["simple"])
            core_text = (
                f" Core-block availability: {core_availability:.1f}%."
                if core_availability is not None else ""
            )
            story.append(Paragraph(
                f"Entry-evidence coverage: {float(op['simple'].get('evidence_coverage') or 0):.1f}%."
                f"{core_text} Unavailable block receives no neutral/range vote.",
                styles["Small"],
            ))
    story.append(_sub_title("Background / diagnostic evidence — extra hard vote nahi"))
    matrix = build_compact_evidence_matrix(snapshot, previous_snapshot)
    reference_name, impact_by_module = build_module_impact_audit(snapshot, matrix)
    matrix_rows = [
        [
            row["Module"],
            _pct(row["Bullish %"]),
            _pct(row["Bearish %"]),
            _pct(row["Neutral %"]),
            _pct(row["Confidence %"]),
        ]
        for row in matrix
    ]
    story.append(
        _table(
            ["Module", "Bullish", "Bearish", "Neutral", "Confidence"],
            matrix_rows,
            widths=[82 * mm, 40 * mm, 40 * mm, 40 * mm, 45 * mm],
            compact=True,
        )
    )
    story.append(_sub_title("Legacy module impact audit — diagnostic only"))
    story.append(
        _table(
            ["Module", "Canonical weight / bounded effect"],
            [[row["Module"], impact_by_module.get(str(row["Module"]), "-")] for row in matrix],
            widths=[65 * mm, 182 * mm],
            compact=True,
        )
    )
    story.append(
        Paragraph(
            f"Legacy/module impact is diagnostic context for protected-plan construction. Simple One-Brain four core blocks above own the operational action; no row below creates a second action. Reference: {reference_name}.",
            styles["Body"],
        )
    )

    roadmap = snapshot.barrier_map
    story.append(_sub_title("Live Barrier + Range Map"))
    roadmap_rows = []
    for level in (
        roadmap.next_resistance,
        roadmap.nearest_resistance,
        roadmap.nearest_support,
        roadmap.next_support,
    ):
        if level is None:
            continue
        roadmap_rows.append(
            [
                level.label,
                level.side,
                f"{level.lower:,.2f} - {level.upper:,.2f}",
                f"{level.strength:.1f}/100",
                f"{level.break_pressure:.1f}/100",
                level.state,
                " | ".join(level.sources[:4]),
            ]
        )
    if roadmap_rows:
        story.append(
            _table(
                ["Level", "Side", "Zone", "Na tootne ki majbooti", "Tootne ka pressure", "State", "Kyun"],
                roadmap_rows,
                widths=[16 * mm, 24 * mm, 42 * mm, 25 * mm, 31 * mm, 36 * mm, 83 * mm],
                compact=True,
            )
        )
    range_item = roadmap.trading_range
    speed = roadmap.market_speed
    story.append(
        _table(
            ["Range", "Range conf.", "Position", "Break bias", "Speed", "VIX risk", "VIX rem. move"],
            [[
                f"{range_item.lower:,.2f} - {range_item.upper:,.2f}" if range_item.lower is not None and range_item.upper is not None else "-",
                f"{range_item.confidence:.1f}/100",
                f"{range_item.position_pct:.1f}%" if range_item.position_pct is not None else "-",
                range_item.breakout_bias,
                f"{speed.state} {speed.score:.1f}/100 {speed.direction}",
                roadmap.vix_risk,
                f"+/- {roadmap.vix_expected_remaining_move_points:.1f} pts" if roadmap.vix_expected_remaining_move_points is not None else "-",
            ]],
            widths=[45 * mm, 28 * mm, 24 * mm, 32 * mm, 48 * mm, 30 * mm, 42 * mm],
            compact=True,
        )
    )
    story.append(Paragraph(roadmap.summary, styles["Body"]))

    reversal = _role_reversal_status(snapshot, previous_snapshot)
    if reversal is not None:
        reversal_text, confirmed = reversal
        story.append(_callout(reversal_text, _GREEN if confirmed else _WARN))

    decision = snapshot.decision
    op = _operational_view(snapshot)
    story.append(_section_title("4. Detailed Simple One-Brain Decision"))
    decision_color = _GREEN if op["action"] != "WAIT" else _WARN
    story.append(
        _callout(
            f"FINAL ACTION: {op['action']} | REGIME: {op['regime']} | DIRECTION: {op['direction']} {op['direction_strength']:.1f}/100 | "
            f"ENTRY: {op['entry_state']} {op['entry_readiness']:.1f}% | TRIGGER: {op['trigger']}",
            decision_color,
        )
    )
    if op["risk_notes"]:
        story.append(_callout("Risk: " + " | ".join(map(str, op["risk_notes"])), _WARN))
    story.append(_sub_title("Protected-strategy legacy diagnostics — final authority nahi"))
    decision_rows = []
    for item in (
        decision.ce_buy,
        decision.pe_buy,
        decision.ce_sell,
        decision.pe_sell,
        decision.iron_condor,
        decision.wait_need,
    ):
        decision_rows.append(
            [
                item.name,
                _pct(item.score),
                item.status,
                " | ".join(item.reasons) or "-",
                " | ".join(item.cautions) or "None",
            ]
        )
    story.append(
        _table(
            ["Setup", "Score / need", "Status", "Key evidence", "Cautions"],
            decision_rows,
            widths=[28 * mm, 24 * mm, 25 * mm, 88 * mm, 92 * mm],
            compact=True,
        )
    )
    story.append(
        _table(
            ["Top reasons", "Main blocker", "Instant read", "Hedge required"],
            [
                [
                    _bullet_lines(decision.reasons),
                    decision.blocker,
                    decision.instant_action or decision.final_action,
                    "YES" if decision.hedge_required else "NO",
                ]
            ],
            widths=[100 * mm, 74 * mm, 43 * mm, 40 * mm],
        )
    )

    outlook = decision.outlook
    story.append(_section_title("5. Next 5-15 Minute Conditional Outlook"))
    story.append(
        _table(
            [
                "Bullish path",
                "Range path",
                "Bearish path",
                "Fake-move risk",
                "Risk state",
                "Signal memory",
                "Invalidation",
                "Status",
            ],
            [
                [
                    _pct(outlook.bullish_path_pct),
                    _pct(outlook.range_path_pct),
                    _pct(outlook.bearish_path_pct),
                    _pct(outlook.fake_move_risk),
                    outlook.fake_move_state,
                    outlook.signal_memory,
                    outlook.invalidation_text,
                    outlook.status,
                ]
            ],
            widths=[
                27 * mm,
                25 * mm,
                27 * mm,
                29 * mm,
                25 * mm,
                42 * mm,
                43 * mm,
                39 * mm,
            ],
        )
    )
    story.append(
        _paragraph(
            "Fake-move checks:\n" + _bullet_lines(outlook.reasons), styles["Body"]
        )
    )

    # Core market evidence.
    story.append(PageBreak())
    story.append(_section_title("6. Core Market Evidence"))
    core = snapshot.core_evidence
    story.append(
        _table(
            [
                "Bullish index",
                "Bearish index",
                "Range index",
                "Confidence",
                "Market state",
                "Move stage",
                "Status",
            ],
            [
                [
                    core.bullish_score,
                    core.bearish_score,
                    core.range_score,
                    _pct(core.confidence),
                    core.market_state,
                    core.move_stage,
                    core.status,
                ]
            ],
            widths=[31 * mm, 31 * mm, 31 * mm, 28 * mm, 47 * mm, 42 * mm, 47 * mm],
        )
    )
    story.append(
        _table(
            ["Main evidence", "Blockers / cautions"],
            [[_bullet_lines(core.reasons), _bullet_lines(core.blockers)]],
            widths=[128.5 * mm, 128.5 * mm],
        )
    )

    story.append(_sub_title("Price Action - completed candles"))
    pa_rows = []
    for item in (
        snapshot.price_action.three_minute,
        snapshot.price_action.fifteen_minute,
    ):
        pa_rows.append(
            [
                item.timeframe,
                item.as_of,
                item.structure,
                item.event,
                item.move_stage,
                item.last_swing_high,
                item.last_swing_low,
                item.invalidation_level,
                item.atr14,
                f"{item.bullish_score:.1f}/{item.bearish_score:.1f}/{item.range_score:.1f}",
                _pct(item.confidence),
                item.status,
            ]
        )
    story.append(
        _table(
            [
                "TF",
                "As of",
                "Structure",
                "Event",
                "Stage",
                "Swing H",
                "Swing L",
                "Invalidation",
                "ATR14",
                "B/B/R",
                "Conf.",
                "Status",
            ],
            pa_rows,
            widths=[
                12 * mm,
                31 * mm,
                27 * mm,
                43 * mm,
                25 * mm,
                20 * mm,
                20 * mm,
                23 * mm,
                17 * mm,
                24 * mm,
                17 * mm,
                25 * mm,
            ],
            compact=True,
        )
    )
    story.append(
        Paragraph(
            f"Cross-timeframe: {escape(snapshot.price_action.combined_state)} - "
            f"{escape(snapshot.price_action.relationship)} (confidence {snapshot.price_action.confidence:.1f}%).",
            styles["Body"],
        )
    )

    story.append(_sub_title("Support and Resistance"))
    levels = snapshot.levels
    level_rows = [
        _level_row("Immediate support", levels.immediate_support),
        _level_row("Strong support", levels.strong_support),
        _level_row("Immediate resistance", levels.immediate_resistance),
        _level_row("Strong resistance", levels.strong_resistance),
    ]
    story.append(
        _table(
            ["Level", "Zone", "Midpoint", "Distance", "Status", "Sources"],
            level_rows,
            widths=[38 * mm, 43 * mm, 24 * mm, 24 * mm, 37 * mm, 91 * mm],
            compact=True,
        )
    )
    story.append(
        _table(
            [
                "Current position",
                "Upside room",
                "Downside room",
                "PDH",
                "PDL",
                "ORH",
                "ORL",
                "Status",
            ],
            [
                [
                    levels.current_position,
                    levels.upside_room,
                    levels.downside_room,
                    levels.previous_day_high,
                    levels.previous_day_low,
                    levels.opening_range_high,
                    levels.opening_range_low,
                    levels.status,
                ]
            ],
            widths=[
                44 * mm,
                30 * mm,
                31 * mm,
                27 * mm,
                27 * mm,
                27 * mm,
                27 * mm,
                44 * mm,
            ],
            compact=True,
        )
    )

    story.append(_sub_title("NIFTY Futures Volume"))
    volume_rows = []
    for item in (snapshot.volume.three_minute, snapshot.volume.fifteen_minute):
        volume_rows.append(
            [
                item.timeframe,
                item.as_of,
                item.current_volume,
                item.baseline_volume,
                item.relative_volume,
                item.volume_state,
                item.volume_trend,
                item.price_direction,
                item.move_support,
                item.baseline_samples,
                _pct(item.confidence),
                item.status,
            ]
        )
    story.append(
        _table(
            [
                "TF",
                "As of",
                "Current",
                "Baseline",
                "Rel. vol",
                "State",
                "Trend",
                "Price",
                "Support",
                "Samples",
                "Conf.",
                "Status",
            ],
            volume_rows,
            widths=[
                12 * mm,
                31 * mm,
                24 * mm,
                24 * mm,
                20 * mm,
                25 * mm,
                26 * mm,
                24 * mm,
                30 * mm,
                18 * mm,
                18 * mm,
                25 * mm,
            ],
            compact=True,
        )
    )
    story.append(
        Paragraph(
            f"Source: {escape(snapshot.volume.source)} | Overall view: {escape(snapshot.volume.overall_view)} | "
            f"Confidence: {snapshot.volume.confidence:.1f}% | Status: {escape(snapshot.volume.status)}",
            styles["Body"],
        )
    )

    story.append(_sub_title("EMA / MACD / RSI"))
    indicator_rows = []
    for item in (snapshot.indicators.three_minute, snapshot.indicators.fifteen_minute):
        indicator_rows.append(
            [
                item.timeframe,
                item.as_of,
                item.close,
                item.ema20,
                item.ema50,
                item.ema_state,
                item.macd,
                item.macd_signal,
                item.macd_histogram,
                item.macd_state,
                item.rsi14,
                item.rsi_state,
                item.status,
            ]
        )
    story.append(
        _table(
            [
                "TF",
                "As of",
                "Close",
                "EMA20",
                "EMA50",
                "EMA state",
                "MACD",
                "Signal",
                "Hist.",
                "MACD state",
                "RSI14",
                "RSI state",
                "Status",
            ],
            indicator_rows,
            widths=[
                11 * mm,
                31 * mm,
                20 * mm,
                20 * mm,
                20 * mm,
                32 * mm,
                18 * mm,
                18 * mm,
                18 * mm,
                28 * mm,
                18 * mm,
                32 * mm,
                24 * mm,
            ],
            compact=True,
        )
    )

    # Options intelligence.
    story.append(PageBreak())
    story.append(_section_title("7. Options Intelligence"))
    option = snapshot.option_intelligence
    story.append(
        _table(
            [
                "Basis",
                "Snapshots",
                "Bullish",
                "Bearish",
                "Range",
                "Confidence",
                "Bias",
                "Persistence",
                "Status",
            ],
            [
                [
                    option.basis,
                    option.snapshot_count,
                    option.bullish_score,
                    option.bearish_score,
                    option.range_score,
                    _pct(option.confidence),
                    option.market_bias,
                    option.persistence,
                    option.status,
                ]
            ],
            widths=[
                48 * mm,
                22 * mm,
                22 * mm,
                22 * mm,
                22 * mm,
                25 * mm,
                30 * mm,
                38 * mm,
                28 * mm,
            ],
        )
    )
    story.append(
        _table(
            ["Reasons", "Blockers"],
            [[_bullet_lines(option.reasons), _bullet_lines(option.blockers)]],
            widths=[128.5 * mm, 128.5 * mm],
        )
    )

    story.append(_sub_title("OI Walls, Clusters and PCR"))
    wall_rows = []
    for wall in (option.ce_wall, option.pe_wall):
        wall_rows.append(
            [
                wall.side,
                wall.strike,
                wall.oi,
                wall.previous_strike,
                wall.migration_points,
                wall.cluster_center,
                wall.cluster_oi,
                wall.status,
            ]
        )
    story.append(
        _table(
            [
                "Side",
                "Near-ATM Wall",
                "OI",
                "Previous",
                "Migration",
                "Cluster",
                "Cluster OI",
                "Status",
            ],
            wall_rows,
            widths=[
                22 * mm,
                30 * mm,
                32 * mm,
                31 * mm,
                30 * mm,
                31 * mm,
                43 * mm,
                38 * mm,
            ],
            compact=True,
        )
    )
    global_walls = (snapshot.metadata or {}).get("global_oi_walls") or {}
    if global_walls:
        story.append(
            _table(
                ["Side", "Global Max OI Strike", "Global Max OI"],
                [
                    [side, (global_walls.get(side) or {}).get("strike"), (global_walls.get(side) or {}).get("oi")]
                    for side in ("CE", "PE")
                ],
                widths=[35 * mm, 70 * mm, 70 * mm],
                compact=True,
            )
        )
    pcr = option.pcr
    story.append(
        _table(
            [
                "Near-ATM OI PCR",
                "Day addition PCR",
                "Intraday addition PCR",
                "Volume PCR",
                "PCR state",
                "Status",
            ],
            [
                [
                    pcr.near_atm_oi_pcr,
                    pcr.day_addition_pcr,
                    pcr.intraday_addition_pcr,
                    pcr.volume_pcr,
                    pcr.state,
                    pcr.status,
                ]
            ],
            widths=[42 * mm, 42 * mm, 48 * mm, 38 * mm, 53 * mm, 34 * mm],
            compact=True,
        )
    )

    story.append(_sub_title("1m / 3m / 5m Flow Windows"))
    window_rows = [
        [
            item.label,
            item.actual_age_seconds,
            item.ce_oi_delta,
            item.pe_oi_delta,
            item.ce_premium_delta,
            item.pe_premium_delta,
            item.ce_volume_delta,
            item.pe_volume_delta,
            item.bias,
            item.status,
        ]
        for item in option.windows
    ]
    story.append(
        _table(
            [
                "Window",
                "Age sec",
                "CE OI d",
                "PE OI d",
                "CE prem d",
                "PE prem d",
                "CE vol d",
                "PE vol d",
                "Bias",
                "Status",
            ],
            window_rows,
            widths=[
                25 * mm,
                22 * mm,
                26 * mm,
                26 * mm,
                27 * mm,
                27 * mm,
                29 * mm,
                29 * mm,
                24 * mm,
                22 * mm,
            ],
            compact=True,
        )
    )

    story.append(_sub_title("Strike-wise Premium + OI + Volume Classification"))
    flow_headers = [
        "Strike",
        "Side",
        "ATM",
        "LTP",
        "Price d",
        "OI",
        "OI d",
        "Volume",
        "Vol d",
        "Class",
        "Bias",
        "Strength",
        "IV",
    ]
    flow_rows = []
    for row in option.flow_rows:
        flow_rows.append(
            [
                row.get("strike"),
                row.get("side"),
                row.get("is_atm"),
                row.get("last_price"),
                row.get("price_delta"),
                row.get("oi"),
                row.get("oi_delta"),
                row.get("volume"),
                row.get("volume_delta"),
                row.get("classification"),
                row.get("directional_bias"),
                row.get("flow_strength"),
                row.get("implied_volatility"),
            ]
        )
    if flow_rows:
        story.append(
            _table(
                flow_headers,
                flow_rows,
                widths=[
                    20 * mm,
                    12 * mm,
                    13 * mm,
                    18 * mm,
                    20 * mm,
                    24 * mm,
                    22 * mm,
                    24 * mm,
                    21 * mm,
                    34 * mm,
                    22 * mm,
                    24 * mm,
                    16 * mm,
                ],
                compact=True,
            )
        )
    else:
        story.append(Paragraph("Option flow matrix unavailable.", styles["Body"]))

    # Market support and risk.
    story.append(PageBreak())
    story.append(_section_title("8. Top-9, VIX, FII/DII, News and Event Risk"))
    heavy = snapshot.heavyweights
    story.append(
        _table(
            [
                "Covered weight",
                "Weighted move",
                "Est. index contribution",
                "Advancing",
                "Declining",
                "Unchanged",
                "State",
                "Confidence",
                "Status",
            ],
            [
                [
                    _pct(heavy.covered_weight_pct),
                    _pct(heavy.weighted_move_pct),
                    _pct(heavy.estimated_index_contribution_pct),
                    heavy.advancing,
                    heavy.declining,
                    heavy.unchanged,
                    heavy.state,
                    _pct(heavy.confidence),
                    heavy.status,
                ]
            ],
            widths=[
                31 * mm,
                31 * mm,
                37 * mm,
                23 * mm,
                23 * mm,
                23 * mm,
                42 * mm,
                25 * mm,
                22 * mm,
            ],
            compact=True,
        )
    )
    story.append(
        _table(
            ["Top-9 covered weight", "Remaining market weight", "Estimated remaining move", "Top-9 vs remaining market"],
            [[
                _pct(heavy.covered_weight_pct),
                _pct(heavy.remaining_weight_pct),
                _pct(heavy.estimated_remaining_move_pct),
                heavy.market_disagreement,
            ]],
            widths=[58 * mm, 58 * mm, 58 * mm, 83 * mm],
            compact=True,
        )
    )
    heavy_rows = [
        [
            row.symbol,
            row.name,
            _pct(row.official_weight_pct),
            row.last_price,
            _pct(row.change_pct),
            _pct(row.index_contribution_pct),
            row.direction,
        ]
        for row in heavy.rows
    ]
    story.append(
        _table(
            ["Symbol", "Name", "Weight", "Last", "Change", "Contribution", "Direction"],
            heavy_rows,
            widths=[26 * mm, 54 * mm, 26 * mm, 34 * mm, 29 * mm, 39 * mm, 49 * mm],
            compact=True,
        )
    )

    vix = snapshot.vix_context
    inst = snapshot.institutional_context
    event = snapshot.event_risk
    story.append(_sub_title("Volatility and Background Context"))
    story.append(
        _table(
            [
                "Context",
                "Latest / value",
                "5-day",
                "10-day",
                "15-day",
                "State / regime",
                "Confidence / status",
                "Note",
            ],
            [
                [
                    "India VIX",
                    vix.last_price,
                    vix.change_pct,
                    "-",
                    "-",
                    f"{vix.regime}; {vix.movement}",
                    vix.status,
                    vix.seller_environment,
                ],
                [
                    "FII cash net",
                    inst.latest_fii_net,
                    inst.fii_5d_net,
                    inst.fii_10d_net,
                    inst.fii_15d_net,
                    inst.state,
                    f"{inst.confidence:.1f}% / {inst.status}",
                    f"Observations {inst.observations}",
                ],
                [
                    "DII cash net",
                    inst.latest_dii_net,
                    inst.dii_5d_net,
                    inst.dii_10d_net,
                    inst.dii_15d_net,
                    inst.state,
                    f"{inst.confidence:.1f}% / {inst.status}",
                    f"As of {inst.as_of_date or '-'}",
                ],
                [
                    "FII index futures position",
                    (
                        f"{inst.latest_fii_index_futures_contracts:,.0f} contracts; "
                        f"L {inst.latest_fii_futures_long_pct:.2f}% / S {inst.latest_fii_futures_short_pct:.2f}%"
                        if inst.latest_fii_index_futures_contracts is not None
                        and inst.latest_fii_futures_long_pct is not None
                        and inst.latest_fii_futures_short_pct is not None
                        else inst.fii_futures_bias
                    ),
                    f"L {inst.fii_futures_5d_long_avg_pct or 0:.2f}% / S {inst.fii_futures_5d_short_avg_pct or 0:.2f}%",
                    f"L {inst.fii_futures_10d_long_avg_pct or 0:.2f}% / S {inst.fii_futures_10d_short_avg_pct or 0:.2f}%",
                    f"L {inst.fii_futures_15d_long_avg_pct or 0:.2f}% / S {inst.fii_futures_15d_short_avg_pct or 0:.2f}%",
                    inst.fii_futures_bias,
                    f"{inst.confidence:.1f}% / {inst.status}",
                    "Contracts are quantity; direction uses Long/Short %; cash stays primary",
                ],
                [
                    "Verified event risk",
                    event.level,
                    "-",
                    "-",
                    "-",
                    "VERIFIED" if event.verified else "NOT VERIFIED",
                    event.status,
                    event.note or "None",
                ],
            ],
            widths=[
                34 * mm,
                30 * mm,
                28 * mm,
                28 * mm,
                28 * mm,
                47 * mm,
                36 * mm,
                26 * mm,
            ],
            compact=True,
        )
    )

    news = snapshot.news_context
    story.append(_sub_title("Live Market News Context"))
    story.append(
        _table(
            ["Status", "Risk", "Bias", "Newest age min", "Source", "Summary"],
            [[news.status, news.risk_level, news.bias, news.newest_age_minutes, news.source, news.summary]],
            widths=[28 * mm, 24 * mm, 26 * mm, 31 * mm, 52 * mm, 96 * mm],
            compact=True,
        )
    )
    if news.headlines:
        headline_rows = [
            [item.age_minutes, item.impact, item.bias, item.title, item.source]
            for item in news.headlines[:8]
        ]
        story.append(
            _table(
                ["Age min", "Impact", "Bias", "Headline", "Source"],
                headline_rows,
                widths=[21 * mm, 23 * mm, 24 * mm, 148 * mm, 41 * mm],
                compact=True,
            )
        )

    # Plans and guards.
    story.append(
        _section_title("9. Protected Plan, Execution Guard and Position Guardian")
    )
    plan = snapshot.trade_plan
    plan_rows = []
    decision_scores = {
        "CE BUY": decision.ce_buy.score,
        "PE BUY": decision.pe_buy.score,
        "CE SELL": decision.ce_sell.score,
        "PE SELL": decision.pe_sell.score,
        "IRON CONDOR": decision.iron_condor.score,
    }
    for setup in (plan.ce_buy, plan.pe_buy, plan.ce_sell, plan.pe_sell, plan.iron_condor):
        breakeven = "-"
        if setup.lower_breakeven is not None and setup.upper_breakeven is not None:
            breakeven = f"{setup.lower_breakeven:,.2f} to {setup.upper_breakeven:,.2f}"
        elif setup.lower_breakeven is not None:
            breakeven = f"Lower {setup.lower_breakeven:,.2f}"
        elif setup.upper_breakeven is not None:
            breakeven = f"Upper {setup.upper_breakeven:,.2f}"
        primary = (
            "BUY " + _trade_leg_text(setup.long_legs)
            if setup.is_buy
            else "SELL " + _trade_leg_text(setup.short_legs)
        )
        protection = (
            "SELL " + _trade_leg_text(setup.short_legs)
            if setup.is_buy
            else "BUY " + _trade_leg_text(setup.hedge_legs)
        )
        premium = (
            f"Debit {setup.estimated_debit_points:.2f}"
            if setup.estimated_debit_points is not None
            else f"Credit {setup.estimated_credit_points:.2f}"
            if setup.estimated_credit_points is not None
            else "-"
        )
        plan_rows.append(
            [
                setup.name,
                primary,
                protection,
                premium,
                setup.max_risk_points,
                breakeven,
                decision_scores.get(setup.name, 0.0),
                setup.quality_score,
                setup.status,
                setup.blocker,
            ]
        )
    story.append(
        _table(
            [
                "Setup",
                "Primary",
                "Protection",
                "Premium",
                "Max risk",
                "Breakeven",
                "Brain fit",
                "Quality",
                "Status",
                "Blocker",
            ],
            plan_rows,
            widths=[
                23 * mm,
                49 * mm,
                49 * mm,
                19 * mm,
                18 * mm,
                22 * mm,
                36 * mm,
                20 * mm,
                24 * mm,
                37 * mm,
            ],
            compact=True,
        )
    )
    guard = snapshot.execution_guard
    story.append(_sub_title("Execution Guard"))
    story.append(
        _table(
            [
                "Readiness",
                "Setup",
                "Signal",
                "Confirmations",
                "Risk budget",
                "Risk / lot",
                "Allowed lots",
                "Entry window",
                "Exit by",
                "Status",
            ],
            [
                [
                    guard.readiness,
                    guard.selected_setup,
                    guard.signal_state,
                    f"{guard.confirmations}/{guard.required_confirmations}",
                    guard.risk_budget_rupees,
                    guard.risk_per_lot_rupees,
                    guard.allowed_lots,
                    guard.entry_window,
                    guard.forced_exit_time,
                    guard.status,
                ]
            ],
            widths=[
                31 * mm,
                31 * mm,
                37 * mm,
                27 * mm,
                27 * mm,
                27 * mm,
                22 * mm,
                28 * mm,
                25 * mm,
                22 * mm,
            ],
            compact=True,
        )
    )
    story.append(
        _table(
            ["Guard evidence", "Guard blockers", "Spot invalidation"],
            [
                [
                    _bullet_lines(guard.reasons),
                    _bullet_lines(guard.blockers),
                    f"Low {guard.spot_invalidation_low if guard.spot_invalidation_low is not None else '-'} | High {guard.spot_invalidation_high if guard.spot_invalidation_high is not None else '-'}",
                ]
            ],
            widths=[105 * mm, 105 * mm, 47 * mm],
        )
    )

    guardian = snapshot.position_guardian
    story.append(_sub_title("Position Guardian"))
    story.append(
        _table(
            [
                "Status",
                "Instruction",
                "Action",
                "Opened",
                "Lots x size",
                "Entry spot",
                "Current spot",
                "Entry credit",
                "Current debit",
                "P&L pts",
                "P&L Rs",
                "Target progress",
            ],
            [
                [
                    guardian.status,
                    guardian.instruction,
                    guardian.action or "-",
                    guardian.opened_at or "-",
                    f"{guardian.lots} x {guardian.lot_size}",
                    guardian.entry_spot,
                    guardian.current_spot,
                    guardian.entry_credit_points,
                    guardian.current_debit_points,
                    guardian.unrealized_pnl_points,
                    guardian.unrealized_pnl_rupees,
                    _pct(guardian.target_progress_pct),
                ]
            ],
            widths=[
                24 * mm,
                38 * mm,
                26 * mm,
                34 * mm,
                24 * mm,
                22 * mm,
                22 * mm,
                22 * mm,
                23 * mm,
                20 * mm,
                22 * mm,
                24 * mm,
            ],
            compact=True,
        )
    )
    if guardian.legs:
        guardian_rows = [
            [
                leg.role,
                leg.side,
                leg.strike,
                leg.entry_price,
                leg.current_price,
                leg.pnl_contribution_points,
                leg.status,
            ]
            for leg in guardian.legs
        ]
        story.append(
            _table(
                [
                    "Role",
                    "Side",
                    "Strike",
                    "Entry",
                    "Current",
                    "P&L contribution",
                    "Status",
                ],
                guardian_rows,
                widths=[44 * mm, 25 * mm, 35 * mm, 35 * mm, 35 * mm, 42 * mm, 41 * mm],
                compact=True,
            )
        )

    # Raw market appendices.
    story.append(PageBreak())
    story.append(_section_title("10. Raw Market Audit Tables"))
    option_columns = [
        "strike",
        "side",
        "is_atm",
        "last_price",
        "oi",
        "day_oi_change",
        "volume",
        "previous_close_price",
        "day_price_change",
        "implied_volatility",
        "top_bid_price",
        "top_ask_price",
    ]
    option_available = [
        column for column in option_columns if column in snapshot.option_chain.columns
    ]
    option_rows = _frame_rows(snapshot.option_chain, option_available, tail=100)
    story.append(_sub_title("Option Chain - active ATM window"))
    if option_rows:
        widths_map = {
            "strike": 23,
            "side": 12,
            "is_atm": 14,
            "last_price": 20,
            "oi": 24,
            "day_oi_change": 25,
            "volume": 24,
            "previous_close_price": 25,
            "day_price_change": 25,
            "implied_volatility": 21,
            "top_bid_price": 22,
            "top_ask_price": 22,
        }
        widths = [widths_map[column] * mm for column in option_available]
        story.append(_table(option_available, option_rows, widths=widths, compact=True))
    else:
        story.append(Paragraph("Option chain unavailable.", styles["Body"]))

    candle_columns = [
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume",
        "open_interest",
    ]
    for label, frame, tail in (
        ("NIFTY completed 3-minute candles", snapshot.candles_3m, 20),
        ("NIFTY completed 15-minute candles", snapshot.candles_15m, 12),
        ("NIFTY future 3-minute candles", snapshot.future_candles_3m, 20),
        ("NIFTY future 15-minute candles", snapshot.future_candles_15m, 12),
    ):
        completed_frame = _completed_audit_frame(frame)
        available = [
            column for column in candle_columns if column in completed_frame.columns
        ]
        rows = _frame_rows(completed_frame, available, tail=tail)
        story.append(_sub_title(label))
        if rows:
            widths = [
                42 * mm if column == "timestamp" else 28 * mm for column in available
            ]
            story.append(_table(available, rows, widths=widths, compact=True))
        else:
            story.append(Paragraph("Unavailable.", styles["Body"]))

    # Verification worksheet and compact JSON audit.
    story.append(PageBreak())
    story.append(_section_title("11. Live Outcome Verification Worksheet"))
    story.append(
        Paragraph(
            "Use the exact snapshot ID and time below to compare NIFTY after 5 and 15 minutes. "
            "Generate another PDF at the later checkpoint so both records remain immutable.",
            styles["Body"],
        )
    )
    baseline_price = snapshot.nifty_quote.get("last_price")
    story.append(
        _table(
            [
                "Checkpoint",
                "Time",
                "NIFTY",
                "App state",
                "Bullish path",
                "Range path",
                "Bearish path",
                "Result / notes",
            ],
            [
                [
                    "Baseline",
                    snapshot.created_at.isoformat(),
                    baseline_price,
                    decision.signal_state,
                    _pct(outlook.bullish_path_pct),
                    _pct(outlook.range_path_pct),
                    _pct(outlook.bearish_path_pct),
                    f"Snapshot {snapshot.snapshot_id}",
                ],
                [
                    "After 5 minutes",
                    "To record",
                    "To record",
                    "Compare with later PDF",
                    "-",
                    "-",
                    "-",
                    "Pending",
                ],
                [
                    "After 15 minutes",
                    "To record",
                    "To record",
                    "Compare with later PDF",
                    "-",
                    "-",
                    "-",
                    "Pending",
                ],
            ],
            widths=[
                27 * mm,
                49 * mm,
                27 * mm,
                47 * mm,
                25 * mm,
                25 * mm,
                27 * mm,
                30 * mm,
            ],
        )
    )
    story.append(
        _table(
            ["Review classification", "Definition"],
            [
                ["CORRECT", "Dominant conditional path occurred without invalidation."],
                [
                    "PARTIAL",
                    "Direction broadly matched but range/fake-move caution was material.",
                ],
                ["WRONG", "Opposite path developed and remained confirmed."],
                [
                    "FAKE MOVE AVOIDED",
                    "Instant signal flipped but memory/fake-move filter kept action at WAIT.",
                ],
            ],
            widths=[55 * mm, 202 * mm],
        )
    )

    story.append(_section_title("12. Audit Completeness and Live-Test Checklist"))
    ready_windows = sum(
        1 for item in snapshot.option_intelligence.windows if item.status == "READY"
    )
    required_feed_keys = ("quotes", "candles", "option_chain")
    live_feed_names = [
        key
        for key in required_feed_keys
        if (
            (item := snapshot.feed_status.get(key)) is not None
            and item.ok
            and item.use_state == "LIVE"
        )
    ]
    required_feeds_value = (
        "PASS / LIVE"
        if len(live_feed_names) == len(required_feed_keys)
        else f"BLOCKED {len(live_feed_names)}/{len(required_feed_keys)} LIVE"
    )
    checklist_rows = [
        [
            "Single canonical brain",
            "PASS",
            "Final strategy output is read from analysis/decision.py only.",
        ],
        [
            "PDF calculation isolation",
            "PASS",
            "This report makes no API request and performs no independent strategy calculation.",
        ],
        [
            "Required live feeds",
            required_feeds_value,
            "Quotes, completed candles and option chain must all be LIVE before entry.",
        ],
        [
            "Execution gate",
            snapshot.execution_guard.readiness,
            snapshot.execution_guard.blockers[0]
            if snapshot.execution_guard.blockers
            else "All strategy, timing, persistence and risk gates passed.",
        ],
        [
            "Option-flow maturity",
            f"{snapshot.option_intelligence.confidence:.1f}% | windows {ready_windows}/{CONFIG.execution_required_flow_windows}",
            f"Entry requires at least {CONFIG.execution_min_flow_confidence:.0f}% confidence and all flow windows ready.",
        ],
        [
            "3m / 15m coherence",
            snapshot.price_action.relationship,
            "Directional entry is blocked when the two timeframes are not aligned.",
        ],
        [
            "Signal persistence",
            snapshot.execution_guard.signal_state,
            f"Entry requires {CONFIG.execution_required_confirmations} consecutive fresh confirmations.",
        ],
        [
            "Risk budget",
            f"Rs. {snapshot.risk_profile.risk_budget_rupees:,.2f}",
            "The same risk profile is used by the screen, execution guard and PDF.",
        ],
        [
            "Institutional journal",
            f"{snapshot.institutional_context.observations}/15 sessions",
            "FII/DII is background context only; missing is never treated as zero.",
        ],
        [
            "Live outcome review",
            "PENDING",
            "Compare a later 5-minute and 15-minute PDF with this immutable snapshot.",
        ],
    ]
    story.append(
        _table(
            ["Audit item", "Status / value", "Rule"],
            checklist_rows,
            widths=[58 * mm, 62 * mm, 137 * mm],
        )
    )
    story.append(
        _paragraph(
            "Important: raw Snapshot JSON is intentionally excluded from the PDF. "
            "The same developer JSON remains available only inside the collapsed screen section.",
            styles["Body"],
        )
    )

    story.append(Spacer(1, 3 * mm))
    story.append(
        _callout(
            "END OF AUDIT - This report is read-only and does not prove future performance. "
            "Use it to compare the app's frozen evidence with later market data.",
            _BLUE,
        )
    )

    document.build(
        story,
        onFirstPage=lambda canvas, doc: _page_decor(canvas, doc, snapshot),
        onLaterPages=lambda canvas, doc: _page_decor(canvas, doc, snapshot),
    )
    return buffer.getvalue()



def _quick_page_decor(canvas: Any, document: Any, snapshot: MarketSnapshot) -> None:
    canvas.saveState()
    width, height = _PAGE_SIZE
    canvas.setStrokeColor(_GRID)
    canvas.line(15 * mm, height - 12 * mm, width - 15 * mm, height - 12 * mm)
    canvas.setFont("Helvetica-Bold", 7)
    canvas.setFillColor(_DARK)
    canvas.drawString(15 * mm, height - 9 * mm, "Nifty Seller Lite - Quick Market Report")
    canvas.setFont("Helvetica", 6.5)
    canvas.setFillColor(colors.HexColor("#566273"))
    canvas.drawRightString(
        width - 15 * mm,
        height - 9 * mm,
        f"Snapshot {snapshot.snapshot_id[-12:]} | {snapshot.created_at.strftime('%d-%m-%Y %H:%M:%S IST')}",
    )
    canvas.line(15 * mm, 11 * mm, width - 15 * mm, 11 * mm)
    canvas.drawString(15 * mm, 7 * mm, "Decision-support only. Same canonical One-Brain snapshot; no order placement.")
    canvas.drawRightString(width - 15 * mm, 7 * mm, f"Page {document.page}")
    canvas.restoreState()


def build_quick_market_pdf(snapshot: MarketSnapshot, previous_snapshot: MarketSnapshot | None = None) -> bytes:
    """Build a compact 2-page decision report from the existing snapshot only."""

    styles = _styles()
    buffer = BytesIO()
    document = SimpleDocTemplate(
        buffer,
        pagesize=_PAGE_SIZE,
        rightMargin=15 * mm,
        leftMargin=15 * mm,
        topMargin=17 * mm,
        bottomMargin=15 * mm,
        title=f"Nifty Seller Lite Quick {snapshot.snapshot_id}",
        author="Nifty Seller Lite",
        subject="Quick market decision summary",
        pageCompression=1,
    )
    story: list[Any] = [
        Paragraph("Nifty Seller Lite", styles["Title"]),
        Paragraph("Quick Market Report", styles["Subtitle"]),
    ]
    story.append(
        _table(
            ["NIFTY", "Session", "Expiry", "Snapshot"],
            [[
                snapshot.nifty_quote.get("last_price"),
                snapshot.market_session.label,
                snapshot.expiry or "-",
                snapshot.snapshot_id[-12:],
            ]],
            widths=[50 * mm, 95 * mm, 45 * mm, 60 * mm],
            compact=True,
        )
    )

    operational = _operational_view(snapshot)
    direction = operational["direction"]
    feed_ok, _ = required_live_feed_state(snapshot)
    story.append(_section_title("1. Main AI - Market View"))
    story.append(
        _table(
            ["Market rukh", "Rukh evidence", "Final action", "Decision bharosa"],
            [[
                direction,
                f"{operational['direction_strength']:.1f}/100",
                operational["action"],
                f"{operational['entry_readiness']:.1f}/100",
            ]],
            widths=[62 * mm, 62 * mm, 62 * mm, 64 * mm],
            compact=True,
        )
    )
    story.append(Spacer(1, 2 * mm))
    story.append(
        _callout(
            "AI samajh: " + safe_brain_hinglish_line(snapshot, previous_snapshot),
            _BLUE,
        )
    )
    future = snapshot.metadata.get("future_brain") or {}
    if future:
        story.append(_sub_title("Future Brain - Advisory Only"))
        story.append(_table(
            ["Transition", "5m UP/DOWN/RANGE", "15m UP/DOWN/RANGE", "Advisory"],
            [[
                future.get("transition"),
                f"{future.get('up_5m')} / {future.get('down_5m')} / {future.get('range_5m')}",
                f"{future.get('up_15m')} / {future.get('down_15m')} / {future.get('range_15m')}",
                future.get("final_gate"),
            ]], widths=[60 * mm, 60 * mm, 60 * mm, 70 * mm], compact=True,
        ))

    activity_rows, activity_callouts = _activity_report_rows(snapshot)
    story.append(_sub_title("Activity / Shock Status"))
    story.append(
        _table(
            ["Activity", "Score", "Confirm", "Futures volume", "OI / setup", "Use status"],
            activity_rows,
            widths=[34 * mm, 26 * mm, 27 * mm, 34 * mm, 72 * mm, 60 * mm],
            compact=True,
        )
    )
    for message, color in activity_callouts:
        story.append(_callout(message, color))

    candidate_name, candidate_score, candidate_plan, candidate_selected = best_existing_candidate(snapshot)
    story.append(_sub_title("Abhi ka Plan"))
    if candidate_plan is not None and candidate_plan.available:
        story.append(
            _table(
                ["Action", "Candidate", "Suitability", "Sell", "Hedge", "Quality", "Status"],
                [[
                    _operational_view(snapshot)["action"],
                    candidate_name,
                    f"{candidate_score:.1f}/100",
                    plan_leg_text(candidate_plan.short_legs),
                    plan_leg_text(candidate_plan.hedge_legs),
                    f"{candidate_plan.quality_score:.1f}/100",
                    "ENTRY" if _operational_view(snapshot)["action"] != "WAIT" and candidate_selected else "REFERENCE / WAIT",
                ]],
                widths=[36 * mm, 40 * mm, 36 * mm, 44 * mm, 44 * mm, 36 * mm, 43 * mm],
                compact=True,
            )
        )
    else:
        story.append(_paragraph("Protected strike candidate abhi reliable tarah resolve nahi hua.", styles["Body"]))

    story.append(_sub_title("Aage ka Road Map"))
    levels = [
        snapshot.barrier_map.next_resistance,
        snapshot.barrier_map.nearest_resistance,
        snapshot.barrier_map.nearest_support,
        snapshot.barrier_map.next_support,
    ]
    level_rows = []
    for item in levels:
        if item is None:
            continue
        level_rows.append([
            item.label,
            item.side,
            f"{item.lower:,.0f}-{item.upper:,.0f}",
            f"{item.strength:.0f}/100",
            f"{item.break_pressure:.0f}/100",
            item.state,
            " + ".join(item.sources[:3]),
        ])
    if level_rows:
        story.append(
            _table(
                ["Level", "Side", "Zone", "Na tootne ki majbooti", "Tootne ka pressure", "State", "Kyun"],
                level_rows,
                widths=[20 * mm, 32 * mm, 48 * mm, 31 * mm, 31 * mm, 48 * mm, 70 * mm],
                compact=True,
            )
        )

    reversal = _role_reversal_status(snapshot, previous_snapshot)
    if reversal is not None:
        reversal_text, confirmed = reversal
        story.append(_callout(reversal_text, _GREEN if confirmed else _WARN))

    r = snapshot.barrier_map.trading_range
    inst = snapshot.institutional_context
    news = snapshot.news_context
    vix_daily = snapshot.barrier_map.vix_expected_daily_move_points
    story.append(
        _table(
            ["Probable range", "Range conf.", "Break bias", "India VIX", "FII/DII", "News"],
            [[
                f"{r.lower:,.0f}-{r.upper:,.0f}" if r.lower is not None and r.upper is not None else "-",
                f"{r.confidence:.0f}/100",
                r.breakout_bias,
                f"{snapshot.barrier_map.vix_risk}; daily +/-{vix_daily:.0f} pts" if vix_daily is not None else snapshot.barrier_map.vix_risk,
                f"{inst.state}; {inst.observations}/15" if inst.observations else "MISSING",
                f"{news.bias}/{news.risk_level}" if news.status == "READY" else "UNAVAILABLE; WEIGHT 0%",
            ]],
            widths=[45 * mm, 34 * mm, 42 * mm, 54 * mm, 50 * mm, 48 * mm],
            compact=True,
        )
    )

    story.append(PageBreak())
    story.append(_section_title("2. Main Evidence"))
    op = _operational_view(snapshot)
    if op["simple"]:
        rows = []
        for label, key in (("Trend / Regime", "trend"), ("Options Flow", "options"), ("Participation", "participation"), ("Barrier / Entry", "barrier_entry")):
            block = op["blocks"].get(key) or {}
            detail = (
                f"{block.get('state', '-')} | {float(block.get('score') or 0):.1f}/100"
                if key == "barrier_entry"
                else f"{'READY' if block.get('available', True) else 'UNAVAILABLE — NO VOTE'} | B/D/N {float(block.get('bullish') or 0):.1f}/{float(block.get('bearish') or 0):.1f}/{float(block.get('neutral') or 0):.1f}"
            )
            rows.append([label, f"{float(block.get('weight') or 0):.0f}%", detail])
        story.append(_table(["Simple core block", "Weight", "Evidence"], rows, widths=[70*mm, 35*mm, 142*mm], compact=True))
        story.append(_table(["Regime", "Direction", "Entry", "Action", "Trigger"], [[op["regime"], f"{op['direction']} {op['direction_strength']:.1f}", f"{op['entry_state']} {op['entry_readiness']:.1f}", op["action"], op["trigger"]]], widths=[55*mm, 42*mm, 60*mm, 35*mm, 65*mm], compact=True))
    story.append(_sub_title("Background / diagnostic evidence"))
    matrix = build_compact_evidence_matrix(snapshot, previous_snapshot)
    reference_name, impact_by_module = build_module_impact_audit(snapshot, matrix)
    matrix_rows = []
    for row in matrix:
        matrix_rows.append([
            row["Module"],
            _pct(row.get("Bullish %")),
            _pct(row.get("Bearish %")),
            _pct(row.get("Neutral %")),
            _pct(row.get("Confidence %")),
        ])
    story.append(
        _table(
            ["Module", "Bullish", "Bearish", "Neutral", "Confidence"],
            matrix_rows,
            widths=[82 * mm, 40 * mm, 40 * mm, 40 * mm, 45 * mm],
            compact=True,
        )
    )
    story.append(_sub_title("Legacy module impact audit — diagnostic only"))
    story.append(
        _table(
            ["Module", "Canonical weight / bounded effect"],
            [[row["Module"], impact_by_module.get(str(row["Module"]), "-")] for row in matrix],
            widths=[65 * mm, 182 * mm],
            compact=True,
        )
    )

    story.append(_sub_title("5-15 Minute Conditional Outlook"))
    outlook = snapshot.decision.outlook
    story.append(
        _table(
            ["Bullish path", "Range path", "Bearish path", "Fake-move risk", "Signal", "Invalidation"],
            [[
                f"{outlook.bullish_path_pct:.1f}%",
                f"{outlook.range_path_pct:.1f}%",
                f"{outlook.bearish_path_pct:.1f}%",
                f"{outlook.fake_move_risk:.1f}%",
                _operational_view(snapshot)["action"],
                outlook.invalidation_text,
            ]],
            widths=[38 * mm, 38 * mm, 38 * mm, 44 * mm, 42 * mm, 60 * mm],
            compact=True,
        )
    )

    ready_windows = sum(window.status == "READY" for window in snapshot.option_intelligence.windows)
    safety_rows = [
        ["Market data health", _market_data_health(snapshot)],
        ["Option flow reliability", f"{snapshot.option_intelligence.confidence:.1f}% | windows {ready_windows}/{CONFIG.execution_required_flow_windows}"],
        ["3m / 15m", snapshot.price_action.relationship],
        ["News freshness", f"{news.status} | newest {news.newest_age_minutes:.0f}m" if news.newest_age_minutes is not None else news.status],
        ["FII/DII journal", f"{inst.observations}/15 sessions"],
        ["App / snapshot", f"{CONFIG.version} | {snapshot.snapshot_id}"],
        ["Top-9 coverage", f"{snapshot.heavyweights.covered_weight_pct:.1f}% covered | {snapshot.heavyweights.remaining_weight_pct:.1f}% remaining | {snapshot.heavyweights.market_disagreement}"],
    ]
    story.append(_sub_title("Data Check"))
    story.append(_table(["Check", "Current"], safety_rows, widths=[80 * mm, 170 * mm], compact=True))

    document.build(
        story,
        onFirstPage=lambda canvas, doc: _quick_page_decor(canvas, doc, snapshot),
        onLaterPages=lambda canvas, doc: _quick_page_decor(canvas, doc, snapshot),
    )
    return buffer.getvalue()


def quick_pdf_filename(snapshot: MarketSnapshot) -> str:
    timestamp = snapshot.created_at.strftime("%Y%m%d_%H%M%S")
    short_id = snapshot.snapshot_id[-8:].replace("-", "")
    return f"nifty_seller_lite_quick_{timestamp}_{short_id}.pdf"

def audit_pdf_filename(snapshot: MarketSnapshot) -> str:
    timestamp = snapshot.created_at.strftime("%Y%m%d_%H%M%S")
    short_id = snapshot.snapshot_id[-8:].replace("-", "")
    return f"nifty_seller_lite_audit_{timestamp}_{short_id}.pdf"


def build_support_bundle(
    snapshot: MarketSnapshot,
    previous_snapshot: MarketSnapshot | None = None,
    shadow_entries: list[dict[str, Any]] | None = None,
) -> bytes:
    """Create one credential-free handover ZIP for remote diagnosis and updates."""

    output = BytesIO()
    full_pdf = build_full_audit_pdf(snapshot, previous_snapshot)
    manifest = {
        "bundle_schema": "NSL_SUPPORT_BUNDLE_V1",
        "app_version": CONFIG.version,
        "snapshot_id": snapshot.snapshot_id,
        "previous_snapshot_id": previous_snapshot.snapshot_id if previous_snapshot else None,
        "created_at": snapshot.created_at.isoformat(),
        "market_session": snapshot.market_session.label,
        "market_data_health": _market_data_health(snapshot),
        "contains_credentials": False,
        "broker_screenshots_requested": [
            "NIFTY 15-minute chart",
            "NIFTY 3-minute chart",
            "NIFTY option-chain OI/Volume/Greeks near ATM",
        ],
        "notes": [
            "All CSV candles are the snapshot frames available to the app.",
            "The PDF and JSON are read-only views of the same canonical snapshot.",
            "No Dhan access token, client id, password or Streamlit secret is included.",
            "Auto Shadow Journal is included when available; it contains paper trades only.",
        ],
    }
    frames = {
        "spot_candles_1m.csv": snapshot.candles_1m,
        "spot_candles_3m.csv": snapshot.candles_3m,
        "spot_candles_15m.csv": snapshot.candles_15m,
        "future_candles_1m.csv": snapshot.future_candles_1m,
        "future_candles_3m.csv": snapshot.future_candles_3m,
        "future_candles_15m.csv": snapshot.future_candles_15m,
        "option_chain.csv": snapshot.option_chain,
    }
    with ZipFile(output, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr("README.txt", "Nifty Seller Lite Support Bundle\n\nSend this single ZIP with the requested brokerage screenshots. It contains no credentials.\n")
        archive.writestr("support_manifest.json", json.dumps(manifest, indent=2, ensure_ascii=True))
        archive.writestr("current_snapshot.json", json.dumps(snapshot.public_summary(), indent=2, ensure_ascii=True))
        from services.day_memory import clean
        archive.writestr("recording_diagnostics.json", json.dumps(clean(snapshot.metadata.get("recording_diagnostics", {"available": False, "reason": "Recording report not fetched; live persistence not verified"})), indent=2, ensure_ascii=True))
        if previous_snapshot is not None:
            archive.writestr("previous_snapshot.json", json.dumps(previous_snapshot.public_summary(), indent=2, ensure_ascii=True))
        if shadow_entries is not None:
            safe_shadow = [item for item in shadow_entries if isinstance(item, dict)]
            archive.writestr(
                "auto_shadow_journal.json",
                json.dumps({"schema_version": 1, "entries": safe_shadow}, indent=2, ensure_ascii=True),
            )
            archive.writestr(
                "auto_shadow_journal.csv",
                pd.DataFrame(safe_shadow).to_csv(index=False),
            )
        archive.writestr("complete_diagnostic_report.pdf", full_pdf)
        for name, frame in frames.items():
            safe_frame = frame if frame is not None else pd.DataFrame()
            archive.writestr(name, safe_frame.to_csv(index=False))
    return output.getvalue()


def support_bundle_filename(snapshot: MarketSnapshot) -> str:
    timestamp = snapshot.created_at.strftime("%Y%m%d_%H%M%S")
    short_id = snapshot.snapshot_id[-8:].replace("-", "")
    return f"nifty_seller_lite_support_bundle_{timestamp}_{short_id}.zip"
